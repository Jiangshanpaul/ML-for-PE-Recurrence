# Reported methods and analysis implementation

| Reported component | Implementation | Fixed specifications |
| --- | --- | --- |
| Analysis population and predictor whitelist | `config/evaluation_charter.json`; `code/validate_inputs.py`; `code/evaluate_models.py:load` | Development 161/47; external 550/101; 20 predictors; identifiers, outcomes, duration and supplied predictions excluded |
| Imputation, transformations and encoding | `development_source/helpers/learners.py:preprocessing`; `code/reconstruct_locked_models.py:preprocessing` | Training-partition median/mode; four log(1+x) variables; standardization; fixed binary levels; first category dropped |
| Candidate families and parameter grids | `development_source/advanced_ml/config/experiment.json`; `development_source/advanced_ml/code/run_advanced_ml.py:estimator` | 13 families; declared complexity controls and deterministic family/grid order |
| Nested validation and family selection | `development_source/advanced_ml/code/run_advanced_ml.py:tune`, `select_and_fit`, `development` | Three repeats; five outer folds; three inner folds; inner AUROC tuning; pooled repeat-specific OOF AUROC; secondary log-loss tie break; five-fold final tuning |
| Failure handling | `code/model_components.py:CheckedMLPClassifier`; development `select_and_fit` | Reject nonconverged MLP; exclude invalid inner configurations; try the next valid inner-ranked refit; omit incomplete-family OOF; stop on a failed selected final model |
| Calibrated RBF SVM | Shared `estimator`; fixed-model `estimator` | Whole preprocessing/SVC pipeline inside stratified three-fold sigmoid calibration |
| Bagged MLP and stacking | Development `mlp` and `estimator` | Five bootstrap members, 80% samples; LBFGS; training-only OOF stacking from separately preprocessed base pipelines; no passthrough |
| Fixed-model reconstruction | `code/reconstruct_locked_models.py` | Development only; no parameter search; development probability checksums checked before promotion |
| Training discrimination | `code/evaluate_training.py` | Same participants used to fit the final models; distinct from held-out OOF performance |
| External discrimination and probability error | `code/evaluate_models.py`; `code/binary_metrics.py` | AUROC, AP, Brier and log loss; unchanged models; shared 2000 participant-bootstrap samples |
| Calibration | `code/binary_metrics.py:calibration` | Offset intercept with slope fixed to one; free-intercept calibration slope; 500 resamples; O/E; development OOF quintile groups |
| Score groups and contrasts | `code/evaluate_models.py`; `score_cuts` in configuration | Full-precision development mean-OOF tertiles; Wilson intervals; shared bootstrap draws; infinite sparse ratios retained |
| Decision curves | `code/evaluate_models.py` | Binary-label net benefit; 50 thresholds from 0.01 to 0.50; descriptive; no treatment-effect interpretation |
| Time origin and endpoint | `code/evaluate_time_sensitivity.py:derive_endpoint` | Cessation origin; first recurrence; death before recurrence competing; separate 60-month endpoint; later events censored rather than moved |
| Time-dependent AUROC | `code/survival_metrics.py:horizon_weights`, `weighted_auc_ap`; `code/evaluate_time_sensitivity.py` | Cohort-specific reverse KM; tied clinical events before censoring; death as known control; censoring re-estimated in each of 1000 external resamples |
| Cumulative incidence | `code/survival_metrics.py:aalen_johansen`; `code/evaluate_time_sensitivity.py:aj_summary` | Competing death; 1000 overall and 500 within-group resamples; pointwise intervals; sparse/unsupported estimates identified |
| Subgroups | `code/evaluate_models.py` | Sex, age, BMI, hypertension, diabetes; 1000 within-stratum resamples; descriptive; no formal interaction test |
| Model explanations | `code/explain_histgb.py:exact_treewise_shap`; `code/verify_shap.py` | Exact empirical interventional native-tree coalitions; 161 development background rows; log-odds scale; 1000 resamples; independent traversal/permutation check; TreeExplainer diagnostic only |
| External AUROC precision | `code/sample_size_precision.py` | AUROC 0.75/0.80/0.85; event proportion 0.15/0.18/0.20; target 95% CI width 0.10; reference minimum n=511 |
| Supplementary displays | `code/render_supplementary_tables.py`; `code/render_figures.py` | Tables S1–S10; Figures S1–S5; numerical results read from aggregate source tables |

Internal validation, calibration, overfitting assessment, censoring diagnostics, risk sets, sparse-event limitations and material discrepancies are retained because they inform interpretation. Detailed execution records are local reproducibility outputs rather than numbered supplementary tables. The analysis source contains no manuscript-generation program.
