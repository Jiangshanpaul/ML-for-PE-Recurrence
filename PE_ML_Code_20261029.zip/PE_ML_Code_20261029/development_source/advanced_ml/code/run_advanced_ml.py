"""Development-ranked advanced learner comparison with a locked external top five.

The repeated OOF ranking is exploratory and subject to selection optimism. An
additional adaptive inner-CV family-selection benchmark evaluates a related,
explicitly different selection rule. Apparent training performance is diagnostic.
"""
from __future__ import annotations
import os
for _setting in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ.setdefault(_setting, "1")

import argparse
import hashlib
import importlib.metadata
import json
import platform
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.base import clone
from sklearn.ensemble import BaggingClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from model_components import CheckedMLPClassifier

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT.parent
HELPER_PATH = MAIN / "helpers/learners.py"
COMPONENT_PATH = ROOT / "code/model_components.py"
sys.path.insert(0, str(HELPER_PATH.parent))
import learners as helpers

CFG_PATH = ROOT / "config/experiment.json"
CFG = json.loads(CFG_PATH.read_text(encoding="utf-8"))
SEED = int(CFG["seed"])
# Reuse the reviewed estimator constructors and preprocessing, not old results.
helpers.CFG = CFG
helpers.ROOT = ROOT
helpers.SEED = SEED
metrics, save, dump, log, digest = helpers.metrics, helpers.save, helpers.dump, helpers.log, helpers.digest
METRICS = ["auc", "average_precision", "brier", "log_loss"]


def freeze():
    path = ROOT / "audit/development_charter.json"
    if path.exists():
        preflight()
        return
    dump({"frozen_utc": datetime.now(timezone.utc).isoformat(),
          "config_sha256": digest(CFG_PATH), "analysis_script_sha256": digest(__file__),
          "preprocessing_helper_sha256": digest(HELPER_PATH),
          "model_component_sha256": digest(COMPONENT_PATH),
          "source_hashes": CFG["raw_sha256"], "external_loaded": False,
          "ranking": CFG["ranking_rule"], "failure_rule": CFG["failure_rule"],
          "interpretation": "Top-five OOF ranking is exploratory and selection-optimistic; inner-CV adaptive benchmark estimates a different selection rule",
          "primary_results_replaced": False}, "audit/development_charter.json")


def preflight():
    c = json.loads((ROOT / "audit/development_charter.json").read_text())
    assert digest(CFG_PATH) == c["config_sha256"]
    assert digest(__file__) == c["analysis_script_sha256"]
    assert digest(HELPER_PATH) == c["preprocessing_helper_sha256"]
    assert digest(COMPONENT_PATH) == c["model_component_sha256"]
    assert CFG["raw_sha256"] == c["source_hashes"]
    assert CFG["development_file"] == "data_test.txt"
    assert not set(CFG["features"]) & {"id", "Type", "death", "fu_months", "time", "status", "raw_time", "raw_status", "row_index"}


def read_cohort(role):
    if role != "development":
        raise ValueError("This experiment accepts development data only")
    name = CFG["development_file"]
    path = ROOT / CFG["data_directory"] / name
    assert digest(path) == CFG["raw_sha256"][name]
    d = pd.read_csv(path, sep="\t", float_precision="round_trip")
    d.columns = d.columns.str.strip()
    assert d.id.is_unique and d.age.ge(18).all() and set(d.Type.unique()) == {0, 1}
    assert np.isfinite(d[CFG["features"]].to_numpy(float)).all()
    for c in CFG["categorical"]:
        assert set(d[c].unique()).issubset({1, 2} if c == "gender" else {0, 1})
    assert (d[CFG["log1p"]].min() >= 0).all()

    return d.reset_index(drop=True)


def mlp(seed):
    return CheckedMLPClassifier(hidden_layer_sizes=(8,), alpha=1., solver="lbfgs",
        max_iter=2000, max_fun=50000, tol=1e-5, random_state=seed, early_stopping=False)


def estimator(family, seed):
    if family in CFG["previous_families"]:
        return helpers.estimator(family, seed)
    if family == "lightgbm":
        clf = LGBMClassifier(n_estimators=200, learning_rate=.03, reg_lambda=10.,
            max_depth=3, verbosity=-1, n_jobs=1, random_state=SEED,
            deterministic=True, force_col_wise=True)
    elif family == "mlp":
        clf = mlp(SEED)
    elif family == "bagged_mlp":
        # Preprocessing is fitted on this CV training fold. Bootstrap resamples
        # only that transformed training fold; no out-of-bag inference is made.
        clf = BaggingClassifier(estimator=mlp(SEED), n_estimators=5, max_samples=.8,
            max_features=1., bootstrap=True, n_jobs=1, random_state=SEED)
    elif family == "stacking":
        bases = [
            ("ridge", helpers.estimator("ridge", seed).set_params(classifier__C=.1)),
            ("hist", helpers.estimator("hist_gradient_boosting", seed).set_params(
                classifier__max_leaf_nodes=3, classifier__max_iter=100)),
            ("extra", helpers.estimator("extra_trees", seed).set_params(
                classifier__max_depth=3, classifier__min_samples_leaf=15)),
        ]
        # Every base contains its own pipeline; meta-features use held-out base
        # predictions from training-only CV. No validation data fit the stack.
        return StackingClassifier(estimators=bases,
            final_estimator=LogisticRegression(C=.1, solver="lbfgs", max_iter=10000, tol=1e-7),
            cv=StratifiedKFold(3, shuffle=True, random_state=seed + 70000),
            stack_method="predict_proba", passthrough=False, n_jobs=1)
    else:
        raise ValueError(family)
    return Pipeline([("preprocess", helpers.preprocessing(False)), ("classifier", clf)])


def tune(data, family, seed, nfold):
    base = estimator(family, seed)
    search = GridSearchCV(base, CFG["grids"][family],
        scoring={"auc": "roc_auc", "neg_log_loss": "neg_log_loss"},
        cv=StratifiedKFold(nfold, shuffle=True, random_state=seed), refit=False,
        n_jobs=CFG["parallel_jobs"], return_train_score=False, error_score=np.nan)
    try:
        with warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter("always")
            search.fit(data[CFG["features"]], data.Type.to_numpy(int))
    except ValueError as ex:
        return base, None, [{"model": family, "parameters": "all", "inner_auc": np.nan,
                            "inner_log_loss": np.nan, "valid": False,
                            "warnings": str(ex), "failure": "all_parameter_fits_failed"}]
    cv = search.cv_results_
    warning_text = " | ".join(sorted(set(str(w.message) for w in observed)))
    rows = []
    for i, parameters in enumerate(cv["params"]):
        valid = np.isfinite(cv["mean_test_auc"][i]) and np.isfinite(cv["mean_test_neg_log_loss"][i])
        rows.append({"model": family, "parameters": json.dumps(parameters, sort_keys=True),
                     "inner_auc": float(cv["mean_test_auc"][i]),
                     "inner_log_loss": float(-cv["mean_test_neg_log_loss"][i]),
                     "valid": bool(valid), "warnings": warning_text,
                     "failure": "none" if valid else "One or more inner fits failed; parameter excluded"})
    return base, cv, rows


def select_and_fit(base, cv, data, objective, stage, family, failure_rows):
    if cv is None:
        return None, None, np.nan
    values = cv["mean_test_auc"] if objective == "auc" else cv["mean_test_neg_log_loss"]
    valid = np.isfinite(cv["mean_test_auc"]) & np.isfinite(cv["mean_test_neg_log_loss"])
    order = sorted(np.flatnonzero(valid), key=lambda i: (-values[i], int(i)))
    for index in order:
        try:
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter("always")
                fitted = clone(base).set_params(**cv["params"][index]).fit(data[CFG["features"]], data.Type.to_numpy(int))
            warning_text = " | ".join(sorted(set(str(w.message) for w in observed)))
            if warning_text:
                failure_rows.append({"stage": stage, "model": family, "objective": objective,
                                     "parameters": json.dumps(cv["params"][index], sort_keys=True),
                                     "status": "fit_warning", "message": warning_text})
            return fitted, cv["params"][index], float(values[index] if objective == "auc" else -values[index])
        except (ValueError, FloatingPointError, ArithmeticError) as ex:
            failure_rows.append({"stage": stage, "model": family, "objective": objective,
                                 "parameters": json.dumps(cv["params"][index], sort_keys=True),
                                 "status": "refit_failed_try_next_cv_ranked_parameters", "message": str(ex)})
    return None, None, np.nan


def development():
    preflight()
    d = read_cohort("development")
    all_oof, tuning_rows, fold_rows, selections, partitions, failures, parameter_rows = [], [], [], [], [], [], []
    names = CFG["families"] + ["adaptive_inner_auc_selection", "original_logloss_procedure"]
    for repeat, seed in enumerate(CFG["repeat_seeds"], 1):
        predictions = pd.DataFrame({"repeat": repeat, "row_index": np.arange(len(d)), "Type": d.Type, "fold": -1})
        for name in names:
            predictions[name] = np.nan
        splits = StratifiedKFold(5, shuffle=True, random_state=seed)
        for fold, (it, iv) in enumerate(splits.split(d, d.Type), 1):
            tr, va = d.iloc[it], d.iloc[iv]
            log(f"Advanced repeat {repeat}/3 fold {fold}/5; training {len(tr)} validation {len(va)}")
            scores, original_scores, original_predictions = {}, {}, {}
            for family in CFG["families"]:
                base, cv, rows = tune(tr, family, seed + fold, 3)
                for row in rows:
                    row.update(stage="outer", repeat=repeat, outer_fold=fold)
                tuning_rows.extend(rows)
                model, parameters, score = select_and_fit(base, cv, tr, "auc", f"repeat{repeat}_fold{fold}", family, failures)
                parameter_rows.append({"repeat":repeat,"fold":fold,"model":family,"objective":"auc",
                    "parameters":json.dumps(parameters,sort_keys=True),"inner_score":score,"fit_available":model is not None})
                if model is not None:
                    p = model.predict_proba(va[CFG["features"]])[:, 1]
                    predictions.loc[iv, family] = p
                    scores[family] = score
                    fold_rows.append({"repeat": repeat, "fold": fold, "model": family, "n": len(va),
                                      "events": int(va.Type.sum()), "status": "ok", **metrics(va.Type, p)})
                else:
                    fold_rows.append({"repeat": repeat, "fold": fold, "model": family, "n": len(va),
                                      "events": int(va.Type.sum()), "status": "all_fits_failed"})
                if family in CFG["original_families"]:
                    model_log, params_log, score_log = select_and_fit(base, cv, tr, "log_loss", f"repeat{repeat}_fold{fold}", family, failures)
                    parameter_rows.append({"repeat":repeat,"fold":fold,"model":family,"objective":"log_loss",
                        "parameters":json.dumps(params_log,sort_keys=True),"inner_score":score_log,"fit_available":model_log is not None})
                    if model_log is not None:
                        original_scores[family] = score_log
                        original_predictions[family] = model_log.predict_proba(va[CFG["features"]])[:, 1]
                log(f"  {family}: inner AUROC {score:.4f}" if np.isfinite(score) else f"  {family}: unavailable after declared fit-failure checks")
            assert scores and original_scores, "No eligible family in an outer training partition"
            chosen = max([f for f in CFG["families"] if f in scores], key=lambda f: scores[f])
            original = min([f for f in CFG["original_families"] if f in original_scores], key=lambda f: original_scores[f])
            predictions.loc[iv, "adaptive_inner_auc_selection"] = predictions.loc[iv, chosen]
            predictions.loc[iv, "original_logloss_procedure"] = original_predictions[original]
            predictions.loc[iv, "fold"] = fold
            for name in ["adaptive_inner_auc_selection", "original_logloss_procedure"]:
                fold_rows.append({"repeat": repeat, "fold": fold, "model": name, "n": len(va),
                                  "events": int(va.Type.sum()), "status": "ok", **metrics(va.Type, predictions.loc[iv, name])})
            selections.append({"repeat": repeat, "fold": fold, "auc_family": chosen, "original_logloss_family": original,
                               "auc_inner_score": scores[chosen], "logloss_inner_score": original_scores[original]})
            partitions.append({"repeat": repeat, "fold": fold, "seed": seed,
                               "training_indices": it.tolist(), "validation_indices": iv.tolist()})
            save(predictions, "results/current_repeat_oof_partial_private.csv")
            save(tuning_rows, "tables/hyperparameter_search.csv")
            save(fold_rows, "tables/outer_fold_metrics.csv")
            save(failures, "tables/fitting_warnings_and_failures.csv")
            save(parameter_rows, "tables/outer_selected_parameters.csv")
        assert not predictions[["adaptive_inner_auc_selection", "original_logloss_procedure"]].isna().any().any()
        all_oof.append(predictions)
        save(pd.concat(all_oof, ignore_index=True), "results/repeated_oof_predictions_private.csv")
    oof = pd.concat(all_oof, ignore_index=True)
    dump(partitions, "results/repeated_cv_partitions_private.json")
    save(selections, "tables/outer_selected_families.csv")
    repeat_rows = []
    for repeat, part in oof.groupby("repeat"):
        for family in names:
            eligible = part[family].notna().all()
            values = metrics(part.Type, part[family]) if eligible else dict.fromkeys(METRICS, np.nan)
            for metric, estimate in values.items():
                repeat_rows.append({"repeat": int(repeat), "model": family, "metric": metric, "estimate": estimate,
                                    "n": len(d), "events": int(d.Type.sum()), "status": "ok" if eligible else "Incomplete OOF; no partial-sample estimate"})
    repeat_table = pd.DataFrame(repeat_rows)
    save(repeat_table, "tables/repeat_performance.csv")
    summary = repeat_table.groupby(["model", "metric"], sort=False).estimate.agg(["mean", "min", "max", "std", "count"]).reset_index()
    summary = summary.rename(columns={"count": "valid_repeats"})
    summary["repeats"] = 3
    summary["range_type"] = "Observed repeat range, not a confidence interval"
    summary.loc[summary.valid_repeats < 3, ["mean", "min", "max", "std"]] = np.nan
    save(summary, "tables/internal_repeated_summary.csv")
    ranking = []
    for order, family in enumerate(CFG["families"]):
        auc = summary[(summary.model == family) & (summary.metric == "auc")].iloc[0]
        ll = summary[(summary.model == family) & (summary.metric == "log_loss")].iloc[0]
        ranking.append({"model": family, "internal_mean_auc": auc["mean"], "internal_mean_log_loss": ll["mean"],
                        "complete_oof": int(auc.valid_repeats) == 3, "tie_order": order})
    ranking = pd.DataFrame(ranking).sort_values(["internal_mean_auc", "internal_mean_log_loss", "tie_order"],
        ascending=[False, True, True], na_position="last").reset_index(drop=True)
    ranking["rank"] = np.arange(1, len(ranking)+1)
    ranking["top5"] = (ranking["rank"] <= 5) & ranking.complete_oof
    ranking["preferred"] = ranking["rank"] == 1
    top5 = ranking.loc[ranking.top5, "model"].tolist()
    assert len(top5) == 5, "Fewer than five families completed honest OOF evaluation"
    save(ranking, "tables/development_top5_ranking.csv")

    # All final tuning and apparent-performance checks remain development-only.
    final_models, final_parameters, final_scores, apparent_rows = {}, {}, {}, []
    training_predictions = pd.DataFrame({"row_index":np.arange(len(d)),"Type":d.Type})
    for family in CFG["families"]:
        log(f"Advanced final development tuning: {family}")
        base, cv, rows = tune(d, family, SEED + 100, 5)
        for row in rows:
            row.update(stage="final", repeat=0, outer_fold=0)
        tuning_rows.extend(rows)
        model, parameters, score = select_and_fit(base, cv, d, "auc", "final", family, failures)
        if model is None:
            failures.append({"stage": "final", "model": family, "objective": "auc", "parameters": "all", "status": "family_failed", "message": "No full-development fit passed declared checks"})
            continue
        final_models[family], final_parameters[family], final_scores[family] = model, parameters, score
        training_predictions[family] = model.predict_proba(d[CFG["features"]])[:, 1]
        values = metrics(d.Type, training_predictions[family])
        for metric, estimate in values.items():
            internal = float(summary[(summary.model == family) & (summary.metric == metric)]["mean"].iloc[0])
            apparent_rows.append({"model": family, "metric": metric, "estimate": estimate, "n": len(d),
                                  "events": int(d.Type.sum()), "internal_repeat_mean": internal,
                                  "apparent_minus_internal": estimate - internal,
                                  "interpretation": "Apparent full-development performance, not internal validation or a selection criterion"})
        joblib.dump(model, ROOT / "models" / f"{family}.joblib")
    assert all(f in final_models for f in top5), "A top-five final fit failed; do not silently substitute a different family"
    save(apparent_rows, "tables/training_apparent_performance.csv")
    save(training_predictions, "results/training_apparent_predictions_private.csv")
    save(tuning_rows, "tables/hyperparameter_search.csv")
    save(failures, "tables/fitting_warnings_and_failures.csv")
    mean_oof = oof.groupby("row_index")[CFG["families"]].mean()
    cuts = {f: np.unique(np.quantile(mean_oof[f], [.2,.4,.6,.8])).tolist() for f in top5}
    final_lock = {
        "ordered_top5": top5, "preferred_family": top5[0], "all_family_parameters": final_parameters,
        "all_family_final_cv_auc": final_scores,
        "calibration_cuts": cuts,
        "calibration_cut_source": "Quintiles of each patient's mean across three conditional-family development OOF probabilities; transferred unchanged",
        "ranking_rule": CFG["ranking_rule"], "ranking_optimism": CFG["ranking_optimism"],
        "adaptive_benchmark_interpretation": CFG["adaptive_benchmark_interpretation"],
        "primary_results_replaced": False, "external_loaded_at_lock": False,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "config_sha256": digest(CFG_PATH), "analysis_script_sha256": digest(__file__),
        "preprocessing_helper_sha256": digest(HELPER_PATH), "raw_sha256": CFG["raw_sha256"],
        "model_component_sha256": digest(COMPONENT_PATH),
    }
    dump(final_lock, "results/top5_model_lock.json")
    versions = {p: importlib.metadata.version(p) for p in ["numpy", "pandas", "scipy", "scikit-learn", "xgboost", "catboost", "lightgbm", "joblib", "matplotlib"]}
    (ROOT / "requirements-lock.txt").write_text("\n".join(f"{p}=={v}" for p,v in versions.items())+"\n")
    (ROOT / "session_info.txt").write_text(sys.version+"\n"+platform.platform()+"\n"+json.dumps(versions,indent=2)+"\n")
    dump({"status": "passed", "development_n": len(d), "development_events": int(d.Type.sum()),
          "families": len(CFG["families"]), "outer_partitions": len(partitions), "oof_rows": len(oof),
          "no_external_data_loaded": True, "top5_locked": top5,
          "full_development_apparent_scores_not_used_for_ranking": True,
          "fitting_warnings_and_failures_rows": len(failures)}, "audit/development_execution.json")
    log("TOP FIVE LOCKED BEFORE EXTERNAL READ: " + ", ".join(top5))
    print(ranking.to_string(index=False), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--develop', action='store_true', required=True,
                        help='Run the development-only repeated nested experiment')
    parser.parse_args()
    for folder in ['audit','logs','results','tables','models']:
        (ROOT/folder).mkdir(parents=True, exist_ok=True)
    freeze()
    development()

if __name__ == '__main__':
    main()
