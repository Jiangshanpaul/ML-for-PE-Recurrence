"""Shared preprocessing and learner constructors for development-only validation."""
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, SplineTransformer, StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

# The development runner injects its verified configuration before construction.
ROOT = Path(__file__).resolve().parents[1]
CFG = {}
SEED = 20261012


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(value, path):
    destination = ROOT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")

def save(rows, path):
    destination = ROOT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(destination, index=False, float_format="%.17g", encoding="utf-8-sig")

def log(message):
    text = f"{datetime.now(timezone.utc).isoformat()} {message}"
    print(text, flush=True)
    with (ROOT / "logs/experiment.log").open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")

def preprocessing(spline=False):
    cats = list(CFG["categorical"])
    logs = list(CFG["log1p"])
    continuous = [c for c in CFG["features"] if c not in cats + logs]
    def numeric_steps(logarithmic):
        steps = [("impute", SimpleImputer(strategy="median"))]
        if logarithmic:
            steps.append(("log", FunctionTransformer(np.log1p, feature_names_out="one-to-one")))
        if spline:
            steps.append(("spline", SplineTransformer(n_knots=3, degree=3, knots="quantile", include_bias=False, extrapolation="linear")))
        steps.append(("scale", StandardScaler()))
        return Pipeline(steps)
    levels = [[1, 2] if c == "gender" else [0, 1] for c in cats]
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(categories=levels, drop="first", handle_unknown="error", sparse_output=False)),
    ])
    return ColumnTransformer([
        ("numeric", numeric_steps(False), continuous),
        ("log", numeric_steps(True), logs),
        ("categorical", categorical, cats),
    ], remainder="drop")

def estimator(family, seed):
    prep = preprocessing(family == "spline_logistic")
    if family in ("ridge", "spline_logistic"):
        classifier = LogisticRegression(penalty="l2", solver="lbfgs", max_iter=10000, tol=1e-7)
    elif family == "elastic_net":
        classifier = LogisticRegression(penalty="elasticnet", solver="saga", max_iter=10000, tol=1e-5, random_state=SEED)
    elif family == "random_forest":
        classifier = RandomForestClassifier(n_estimators=200, n_jobs=1, random_state=SEED, max_features=.7)
    elif family == "hist_gradient_boosting":
        classifier = HistGradientBoostingClassifier(learning_rate=.04, min_samples_leaf=25, l2_regularization=10,
            early_stopping=False, random_state=SEED)
    elif family == "xgboost":
        classifier = XGBClassifier(learning_rate=.04, min_child_weight=10, reg_lambda=10, reg_alpha=.1,
            subsample=.8, colsample_bytree=.8, objective="binary:logistic", eval_metric="logloss",
            tree_method="hist", n_jobs=1, random_state=SEED)
    elif family == "extra_trees":
        classifier = ExtraTreesClassifier(n_estimators=300, max_features=.7, n_jobs=1, random_state=SEED)
    elif family == "svm_rbf":
        classifier = SVC(kernel="rbf", probability=False, random_state=SEED)
    elif family == "catboost":
        classifier = CatBoostClassifier(learning_rate=.03, l2_leaf_reg=10, loss_function="Logloss",
            eval_metric="AUC", thread_count=1, random_seed=SEED, verbose=False, allow_writing_files=False)
    else:
        raise ValueError(family)
    pipeline = Pipeline([("preprocess", prep), ("classifier", classifier)])
    if family == "svm_rbf":
        # The WHOLE preprocessing + SVC pipeline is inside each calibration
        # split, so imputation/scaling do not see calibration-fold observations.
        return CalibratedClassifierCV(pipeline, method="sigmoid",
            cv=StratifiedKFold(3, shuffle=True, random_state=seed + 50000), ensemble=True, n_jobs=1)
    return pipeline

def metrics(y, probability):
    probability = np.asarray(probability, float)
    assert np.isfinite(probability).all() and ((probability >= 0) & (probability <= 1)).all()
    return {"auc": float(roc_auc_score(y, probability)),
            "average_precision": float(average_precision_score(y, probability)),
            "brier": float(brier_score_loss(y, probability)),
            "log_loss": float(log_loss(y, probability))}
