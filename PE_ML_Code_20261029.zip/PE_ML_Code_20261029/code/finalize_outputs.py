"""Collect aggregate numerical results and software versions after analysis."""
from pathlib import Path
from importlib.metadata import version
import hashlib
import json
import platform
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    frames = []
    for path in sorted((ROOT / 'tables/supplement').glob('*.csv')):
        table = pd.read_csv(path)
        if 'estimate' not in table and 'mean_absolute_shap' not in table:
            continue
        table.insert(0, 'source_table', path.relative_to(ROOT).as_posix())
        table.insert(1, 'source_row', range(1, len(table) + 1))
        frames.append(table)
    assert frames
    target = ROOT / 'results/results_long.csv'
    pd.concat(frames, ignore_index=True).to_csv(target, index=False, float_format='%.17g')
    packages = ['numpy', 'pandas', 'scipy', 'scikit-learn', 'joblib', 'matplotlib',
                'lightgbm', 'catboost', 'xgboost', 'Pillow', 'shap', 'numba', 'llvmlite', 'slicer']
    info = [sys.version, platform.platform()] + [p + '==' + version(p) for p in packages]
    (ROOT / 'session_info.txt').write_text('\n'.join(info) + '\n', encoding='utf-8')
    files = list((ROOT / 'code').glob('*.py')) + list((ROOT / 'config').glob('*.json'))
    files += list((ROOT / 'tables/supplement').glob('*.csv')) + list((ROOT / 'figure_data').glob('*.csv'))
    hashes = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    (ROOT / 'audit/analysis_output_hashes.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8')
    print(f'Collected {len(frames)} aggregate tables and {len(hashes)} source/output checksums.')


if __name__ == '__main__':
    main()
