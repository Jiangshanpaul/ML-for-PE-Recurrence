"""Assess external AUROC precision for a fixed cohort without reading patient data.

Method: Newcombe approximation reproduced as equation 11 in Riley et al.,
Stat Med 2021;40:4230-4251, doi:10.1002/sim.9025.
This assessment is separate from recruitment planning and does not establish
model-development adequacy, calibration precision or power for paired contrasts.
"""
from pathlib import Path
from statistics import NormalDist
import argparse
import csv
import json
import math


def auc_standard_error(n, auc, event_proportion):
    if n < 2 or not 0 < auc < 1 or not 0 < event_proportion < 1:
        raise ValueError('n >= 2 and probabilities strictly between zero and one are required')
    c, phi = auc, event_proportion
    return math.sqrt(c * (1-c) * (1 + (n/2-1)*(1-c)/(2-c)
                     + (n/2-1)*c/(1+c)) / (n*n*phi*(1-phi)))


def interval_width(n, auc, event_proportion, confidence=0.95):
    z = NormalDist().inv_cdf((1+confidence)/2)
    return 2*z*auc_standard_error(n, auc, event_proportion)


def minimum_n(auc, event_proportion, target_width=0.10, confidence=0.95):
    if not 0 < target_width < 1 or not 0 < confidence < 1:
        raise ValueError('target_width and confidence must be strictly between zero and one')
    lo, hi = 2, 2
    while interval_width(hi, auc, event_proportion, confidence) > target_width:
        hi *= 2
    while lo < hi:
        mid = (lo+hi)//2
        if interval_width(mid, auc, event_proportion, confidence) <= target_width:
            hi = mid
        else:
            lo = mid+1
    return lo


def assessment(available_n=550):
    rows=[]
    for auc in (0.75,0.80,0.85):
        for phi in (0.15,0.18,0.20):
            required=minimum_n(auc,phi)
            rows.append(dict(assumed_auroc=auc,event_proportion=phi,
                target_ci_width=0.10,required_n=required,available_n=available_n,
                expected_ci_width=interval_width(available_n,auc,phi),
                meets_reference_precision=available_n>=required))
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args()
    rows=assessment()
    record=dict(method='Newcombe AUROC standard error; Riley et al. 2021, equation 11',
        doi='10.1002/sim.9025',assessment_date='2026-10-26',
        purpose='Precision assessment of an available external cohort',
        recruitment_sample_size_calculation=False,patient_data_read=False,
        existing_results_recomputed=False,reference_auc=0.80,reference_event_proportion=0.18,
        confidence=0.95,reference_target_width=0.10,scenarios=rows)
    if args.output_dir:
        args.output_dir.mkdir(parents=True,exist_ok=True)
        (args.output_dir/'sample_size_precision.json').write_text(json.dumps(record,indent=2)+'\n')
        with (args.output_dir/'Table_S10_external_sample_size_precision.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
