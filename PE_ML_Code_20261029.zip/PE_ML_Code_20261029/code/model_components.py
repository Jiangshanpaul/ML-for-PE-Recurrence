"""Stable serializable estimator components for the advanced learner experiment."""
import warnings
from sklearn.exceptions import ConvergenceWarning
from sklearn.neural_network import MLPClassifier


class CheckedMLPClassifier(MLPClassifier):
    """Reject a parameter fit when the declared optimizer does not converge."""
    def fit(self, X, y, **fit_params):
        with warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter("always")
            super().fit(X, y, **fit_params)
        failures = [str(w.message) for w in observed if issubclass(w.category, ConvergenceWarning)]
        if failures or self.n_iter_ >= self.max_iter:
            raise ValueError("MLP convergence failure: " + " | ".join(failures))
        for warning in observed:
            if not issubclass(warning.category, ConvergenceWarning):
                warnings.warn(str(warning.message), warning.category)
        return self
