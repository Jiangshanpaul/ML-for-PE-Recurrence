"""Reproduce the unchanged development experiment without external data access."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'config/evaluation_charter.json').read_text())

def main():
    source=(ROOT/CFG['data_directory']/CFG['development_file']).resolve()
    assert hashlib.sha256(source.read_bytes()).hexdigest()==CFG['raw_sha256'][source.name]
    with tempfile.TemporaryDirectory(prefix='pe_development_reproduction_') as tmp:
        workspace=Path(tmp)
        target=workspace/'PE_reanalysis_20261017'
        shutil.copytree(ROOT/'development_source',target)
        (workspace/'ML_PE1').mkdir()
        shutil.copy2(source,workspace/'ML_PE1/data_test.txt')
        # No external file is supplied in the isolated reproduction workspace.
        logfile=ROOT/'logs/internal_reproduction.log';logfile.parent.mkdir(exist_ok=True)
        with logfile.open('w',encoding='utf-8') as out:
            result=subprocess.run([sys.executable,str(target/'advanced_ml/code/run_advanced_ml.py'),'--develop'],
                                  cwd=target,stdout=out,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError('Development reproduction failed; inspect logs/internal_reproduction.log')
        module=target/'advanced_ml'
        baseline=pd.read_csv(ROOT/'tables/supplement/development_internal_summary.csv')
        fresh=pd.read_csv(module/'tables/internal_repeated_summary.csv')
        keys=['model','metric'];a=baseline.sort_values(keys).reset_index(drop=True);b=fresh.sort_values(keys).reset_index(drop=True)
        assert a[keys].equals(b[keys])
        numeric=a.select_dtypes(include='number').columns
        np.testing.assert_allclose(a[numeric],b[numeric],atol=1e-10,rtol=0,equal_nan=True)
        locked=json.loads((ROOT/'config/original_top5_model_lock.json').read_text())
        current=json.loads((module/'results/top5_model_lock.json').read_text())
        for field in ['ordered_top5','preferred_family','all_family_parameters','calibration_cuts']:
            assert current[field]==locked[field],field
        for src,dst in [('results/repeated_oof_predictions_private.csv','results/development_oof_private.csv'),
                        ('results/training_apparent_predictions_private.csv','results/development_apparent_private.csv')]:
            (ROOT/dst).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(module/src,ROOT/dst)
        for fresh_name, output_name in [
            ('internal_repeated_summary','development_internal_summary'),
            ('repeat_performance','development_repeat_performance'),
            ('development_top5_ranking','development_ranking'),
            ('training_apparent_performance','development_apparent')]:
            shutil.copy2(module/'tables'/(fresh_name+'.csv'),
                         ROOT/'tables/supplement'/(output_name+'.csv'))
        search=pd.read_csv(module/'tables/hyperparameter_search.csv',float_precision='round_trip')
        invalid=search.loc[search.valid.astype(str).str.lower().eq('false')].copy()
        invalid.to_csv(ROOT/'tables/supplement/development_invalid_inner_parameters.csv',
                       index=False,float_format='%.17g',encoding='utf-8-sig')
        shutil.copy2(module/'tables/fitting_warnings_and_failures.csv',
                     ROOT/'tables/supplement/development_fitting_failures.csv')
        report=dict(status='passed',external_file_available=False,development_source_sha256=CFG['raw_sha256'][source.name],
            internal_metrics_reproduced=True,top5_and_fixed_parameters_reproduced=True,
            prediction_rows_exported_privately=True,
            invalid_inner_search_records_exported=len(invalid))
        (ROOT/'audit/internal_reproduction.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Development-only experiment reproduced in an isolated workspace.')

if __name__=='__main__':main()
