"""Audit the final eligible source files without modifying source observations."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main():
    cfg = json.loads((ROOT / 'config/evaluation_charter.json').read_text(encoding='utf-8'))
    cohorts, summaries, fields = {}, [], []
    for role in ['development', 'external']:
        path = (ROOT / cfg['data_directory'] / cfg[role + '_file']).resolve()
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        assert checksum == cfg['raw_sha256'][path.name]
        d = pd.read_csv(path, sep='\t', float_precision='round_trip')
        assert (len(d), int(d.Type.sum())) == (cfg[role + '_n'], cfg[role + '_events'])
        assert d.id.is_unique and d.age.ge(18).all()
        assert set(d.Type.unique()) <= {0, 1} and set(d.death.unique()) <= {0, 1}
        assert d.fu_months.gt(0).all() and np.isfinite(d.fu_months).all()
        assert np.isfinite(d[cfg['features']].to_numpy(float)).all()
        for c in cfg['categorical']:
            assert set(d[c].unique()) <= ({1, 2} if c == 'gender' else {0, 1})
        cohorts[role] = d
        summaries.append(dict(cohort=role, n=len(d), events=int(d.Type.sum()),
            deaths=int(d.death.sum()), death_before_recurrence=int(((d.Type == 0) & (d.death == 1)).sum()),
            missing_predictor_cells=int(d[cfg['features']].isna().sum().sum()),
            unique_local_identifiers=bool(d.id.is_unique),
            followup_median_months=float(d.fu_months.median()),
            followup_max_months=float(d.fu_months.max()),
            followup_above_60=int((d.fu_months > 60).sum()),
            followup_above_120=int((d.fu_months > 120).sum()),

            source_sha256=checksum))
        for field in cfg['features'] + ['Type', 'death', 'fu_months']:
            values = d[field]
            fields.append(dict(cohort=role, variable=field, n=len(d), missing=int(values.isna().sum()),
                minimum=float(values.min()), maximum=float(values.max()), median=float(values.median())))
    keys = cfg['features']
    a = set(map(tuple, cohorts['development'][keys].to_numpy()))
    b = set(map(tuple, cohorts['external'][keys].to_numpy()))
    assert not a.intersection(b), 'Identical cross-cohort predictor rows require review'
    report = dict(status='passed_structural_checks',
        population='Final eligible cohorts only', cohorts=summaries,
        identical_cross_cohort_predictor_rows=0,
        linkage_limit='Local identifiers and feature-row checks do not establish global person-level independence.',
        sources_modified=False,
        endpoint_definitions=dict(roles='Shenzhen development; other three hospitals external',
            eligibility='Prior VTE excluded; investigator confirmed uniform review of remaining participants',
            time_origin='Anticoagulation cessation after at least three months',
            time_endpoint='First recurrence, otherwise competing death or last event-free follow-up',
            death_order='Type=1 takes precedence because recurrence preceded later death',
            predictor_timing='Acute first PE', gender='1 female; 2 male'),
)
    (ROOT / 'audit').mkdir(exist_ok=True)
    (ROOT / 'audit/current_data_qc.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    pd.DataFrame(summaries).to_csv(ROOT / 'audit/current_cohort_summary.csv', index=False)
    pd.DataFrame(fields).to_csv(ROOT / 'audit/current_variable_summary.csv', index=False)
    print(json.dumps(dict(status=report['status'], cohorts=summaries), indent=2))


if __name__ == '__main__':
    main()
