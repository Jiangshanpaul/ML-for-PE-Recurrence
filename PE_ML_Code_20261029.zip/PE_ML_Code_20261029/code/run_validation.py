"""Reproduce the eligibility-corrected evaluation and scientific displays."""
from pathlib import Path
import argparse, json, subprocess, sys
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full',action='store_true',help='Reproduce development OOF and fixed models before evaluating')
    parser.add_argument('--evaluate',action='store_true',help='Use existing locked models and development OOF files')
    args=parser.parse_args()
    if args.full==args.evaluate:parser.error('Choose one of --full or --evaluate')
    stages=['validate_inputs.py']
    if args.full:
        stages+=['reproduce_internal.py','reconstruct_locked_models.py']
    stages+=['evaluate_training.py','evaluate_models.py','evaluate_time_sensitivity.py','verify_results.py',
             'explain_histgb.py','verify_shap.py','render_figures.py','sample_size_precision.py','render_supplementary_tables.py',
             'finalize_outputs.py']
    for directory in ['logs','audit','results','tables/supplement','figure_data','figures/main','figures/supplement']:
        (ROOT/directory).mkdir(parents=True,exist_ok=True)
    runs=[]
    for stage in stages:
        log=ROOT/'logs'/('pipeline_'+Path(stage).stem+'.log')
        with log.open('w',encoding='utf-8') as output:
            command=[sys.executable,str(ROOT/'code'/stage)]
            if stage=='sample_size_precision.py':
                command+=['--output-dir',str(ROOT/'tables/supplement')]
            result=subprocess.run(command,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
        runs.append(dict(script=stage,exit_code=result.returncode,completed_utc=datetime.now(timezone.utc).isoformat()))
        (ROOT/'audit/pipeline_execution.json').write_text(json.dumps(runs,indent=2)+'\n')
        if result.returncode:raise RuntimeError(stage+' failed; review '+str(log))
        print(stage+' completed',flush=True)
    print('Requested analysis and display stages completed.')

if __name__=='__main__':main()
