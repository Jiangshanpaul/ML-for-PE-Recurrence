"""Explain the locked HistGB model with exact empirical interventional Shapley values.

No model fitting, hyperparameter search, recalibration, or outcome-based feature
selection is performed. The external cohort contributes explanation targets only.
All individual SHAP values are private; published figures use aggregate data.
"""
import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(_key, '1')

from pathlib import Path
from datetime import datetime, timezone
from importlib.metadata import version
import hashlib
import json
import sys

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import spearmanr
import shap

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT/'config/evaluation_charter.json').read_text(encoding='utf-8-sig'))
SCFG = json.loads((ROOT/'config/shap_config.json').read_text(encoding='utf-8-sig'))
BLUE, ORANGE, DARK, GRID = '#0072B2', '#D55E00', '#172F3B', '#DDE6EA'
LABELS = {
    'age': 'Age', 'gender': 'Sex', 'bmi': 'Body mass index', 'pulse': 'Pulse',
    'smoking': 'Smoking', 'alcohol': 'Alcohol use', 'hypertension': 'Hypertension',
    'hyperlipidemia': 'Hyperlipidaemia', 'diabetes': 'Diabetes',
    'chronic_lung_disease': 'Chronic lung disease', 'wbc': 'White blood cell count',
    'hemoglobin': 'Haemoglobin', 'platelete': 'Platelet count', 'alb': 'Albumin',
    'cre': 'Creatinine', 'glucose': 'Glucose', 'triglyceride': 'Triglycerides',
    'total_cholesterol': 'Total cholesterol', 'hdl': 'HDL cholesterol',
    'ldl': 'LDL cholesterol'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(data, relative):
    path = ROOT/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(data).to_csv(path, index=False, float_format='%.17g', encoding='utf-8-sig')


def load_source(role):
    path = (ROOT/CFG['data_directory']/CFG[role+'_file']).resolve()
    assert sha(path) == CFG['raw_sha256'][path.name], 'Input data checksum mismatch'
    data = pd.read_csv(path, sep='\t', float_precision='round_trip')
    assert len(data) == CFG[role+'_n']
    assert data.id.is_unique
    assert not set(CFG['features']) & {'id', 'Type', 'death', 'fu_months'}
    assert all(not c.startswith('pred_') for c in CFG['features'])
    data = data.copy()

    return data, path


def feature_mapping(preprocess):
    """Map transformed columns without deriving labels from fragile substrings."""
    rows = []
    for block_name, transformer, source_columns in preprocess.transformers_:
        if block_name == 'remainder':
            continue
        output_columns = transformer.get_feature_names_out(source_columns)
        if block_name == 'categorical':
            encoder = transformer.named_steps['encode']
            assert encoder.drop == 'first'
            assert all(len(levels) == 2 for levels in encoder.categories_)
        assert len(output_columns) == len(source_columns), 'Expected one-to-one clinical feature mapping'
        for source, output in zip(source_columns, output_columns):
            rows.append(dict(transformed_index=len(rows), transformed_name=f'{block_name}__{output}',
                             feature=source, label=LABELS[source], preprocessing_block=block_name))
    mapping = pd.DataFrame(rows)
    assert len(mapping) == len(CFG['features']) == 20
    assert mapping.feature.is_unique
    assert set(mapping.feature) == set(CFG['features'])
    assert mapping.transformed_name.tolist() == preprocess.get_feature_names_out().tolist()
    return mapping


def development_percentile(reference, values):
    """Midrank empirical percentile; ties receive their shared midpoint."""
    ordered = np.sort(np.asarray(reference, float))
    left = np.searchsorted(ordered, values, side='left')
    right = np.searchsorted(ordered, values, side='right')
    return (left+right)/(2*len(ordered))*100


def exact_treewise_shap(classifier, background, targets):
    """Exact empirical interventional Shapley values for <=2-feature trees.

    Shapley linearity permits adding the values of individual trees. The dummy
    axiom removes features absent from a tree. With two used features a and b,
    phi_a = .5*(v(a)-v(empty)) + .5*(v(a,b)-v(b)); the expression for b is symmetric.
    All coalition functions are evaluated by sklearn's original native tree
    predictor. This preserves exact threshold behaviour of the locked model.
    """
    assert not np.any(classifier.is_categorical_)
    known, index_map = classifier._bin_mapper.make_known_categories_bitsets()
    n, dimension = targets.shape
    values = np.zeros((n,dimension),float)
    base = float(np.asarray(classifier._baseline_prediction).squeeze())
    mixed = np.tile(background[None,:,:],(n,1,1))
    exact_tree_checks = []
    for stage in classifier._predictors:
        assert len(stage) == 1
        tree = stage[0]
        used = np.unique(tree.nodes['feature_idx'][~tree.nodes['is_leaf'].astype(bool)]).astype(int)
        assert len(used) <= 2, 'Exact small-tree enumerator requires at most two distinct splitting features'
        assert not tree.nodes['is_categorical'].any()
        empty = float(tree.predict(background,known,index_map,1).mean())
        full = tree.predict(targets,known,index_map,1)
        base += empty
        if len(used) == 0:
            np.testing.assert_allclose(full,empty,atol=1e-12,rtol=0)
        elif len(used) == 1:
            values[:,used[0]] += full-empty
        else:
            coalition = {}
            for feature in used:
                mixed[:,:,feature] = targets[:,feature,None]
                coalition[feature] = tree.predict(mixed.reshape(-1,dimension),known,index_map,1).reshape(n,-1).mean(axis=1)
                mixed[:,:,feature] = background[None,:,feature]
            a,b = used
            phi_a = .5*(coalition[a]-empty+full-coalition[b])
            phi_b = .5*(coalition[b]-empty+full-coalition[a])
            np.testing.assert_allclose(phi_a+phi_b,full-empty,atol=1e-12,rtol=0)
            values[:,a] += phi_a
            values[:,b] += phi_b
        exact_tree_checks.append(int(len(used)))
    np.testing.assert_array_equal(mixed,np.tile(background[None,:,:],(n,1,1)))
    np.testing.assert_allclose(base,classifier.decision_function(background).mean(),atol=1e-12,rtol=0)
    np.testing.assert_allclose(base+values.sum(axis=1),classifier.decision_function(targets),atol=1e-12,rtol=0)
    return values,base,exact_tree_checks


def single_precision_tree_diagnostic(classifier, background, targets, expected):
    """Diagnose the float Node fields in SHAP 0.48's independent C++ algorithm.

    This deliberately reduced-precision traversal is diagnostic only. It never
    modifies the estimator and never contributes to the final SHAP values.
    """
    def traverse(tree, matrix):
        active = np.zeros(len(matrix),dtype=int)
        for _ in range(int(tree.nodes['depth'].max())+1):
            nonleaf = ~tree.nodes['is_leaf'][active].astype(bool)
            if not nonleaf.any():
                break
            rows = np.flatnonzero(nonleaf)
            nodes = tree.nodes[active[rows]]
            threshold = nodes['num_threshold'].astype(np.float32).astype(float)
            left = matrix[rows,nodes['feature_idx']] <= threshold
            active[rows] = np.where(left,nodes['left'],nodes['right'])
        assert tree.nodes['is_leaf'][active].all()
        return tree.nodes['value'][active].astype(np.float32).astype(float)
    rounded_targets = np.zeros(len(targets),float)
    rounded_background = 0.
    for stage in classifier._predictors:
        rounded_targets += traverse(stage[0],targets)
        rounded_background += traverse(stage[0],background).mean()
    return expected+rounded_targets-rounded_background


def global_importance(values, features, cohort):
    rng = np.random.default_rng(SCFG['seed'] + (cohort == 'external'))
    absolute = np.abs(values)
    count = rng.multinomial(len(values), np.full(len(values), 1/len(values)),
                            size=SCFG['global_bootstrap_replicates'])
    samples = count@absolute/len(values)
    limits = np.quantile(samples, [.025, .975], axis=0)
    mean = absolute.mean(axis=0)
    total = mean.sum()
    return pd.DataFrame([dict(cohort=cohort, n=len(values), feature=f, label=LABELS[f],
                             mean_absolute_shap=mean[j], lower=limits[0, j], upper=limits[1, j],
                             percent_total_absolute_shap=100*mean[j]/total,
                             mean_signed_shap=values[:, j].mean()) for j, f in enumerate(features)])


def distribution_bins(values, ranks, features, chosen):
    """Aggregate the external attribution distribution; each cell has >=5 records."""
    rows = []
    minimum = SCFG['distribution_minimum_cell']
    for f in chosen:
        j = features.index(f)
        group = np.minimum((ranks[:, j]//(100/3)).astype(int), 2)
        for g in np.unique(group):
            ix = np.flatnonzero(group == g)
            # Quantile-size chunks are deterministic and preserve all observations.
            ix = ix[np.argsort(values[ix, j], kind='stable')]
            if len(ix) < minimum:
                raise ValueError(f'Sparse feature-value group for {f}; revise aggregation, not patient data')
            chunks = np.array_split(ix, max(1, min(16, len(ix)//minimum)))
            for number, chunk in enumerate(chunks):
                rows.append(dict(feature=f, label=LABELS[f], value_tertile=int(g),
                    cell=number, n=len(chunk), shap_mean=values[chunk, j].mean(),
                    shap_min=values[chunk, j].min(), shap_max=values[chunk, j].max(),
                    feature_development_percentile=ranks[chunk, j].mean()))
    frame = pd.DataFrame(rows)
    assert frame.n.min() >= minimum
    assert (frame.groupby('feature').n.sum() == len(values)).all()
    return frame


def dependence_bins(values, ranks, raw, features, chosen, cohort):
    rows = []
    for f in chosen:
        j = features.index(f)
        # Quantile bins are specified on the development empirical scale.
        category = np.minimum((ranks[:, j]//(100/SCFG['dependence_bins'])).astype(int),
                              SCFG['dependence_bins']-1)
        for g in np.unique(category):
            ix = category == g
            if ix.sum() < SCFG['distribution_minimum_cell']:
                continue
            q = np.quantile(values[ix, j], [.25, .5, .75])
            rows.append(dict(cohort=cohort, feature=f, label=LABELS[f], bin=int(g), n=int(ix.sum()),
                feature_development_percentile=np.median(ranks[ix, j]),
                feature_source_median=float(raw.loc[ix, f].median()),
                shap_q25=q[0], shap_median=q[1], shap_q75=q[2],
                source_min=float(raw.loc[ix, f].min()), source_max=float(raw.loc[ix, f].max())))
    return pd.DataFrame(rows)


def plot(global_table, distribution, dependence, chosen, selected, summary):
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':8, 'axes.titlesize':9,
        'axes.titleweight':'bold', 'axes.labelsize':8, 'axes.spines.top':False,
        'axes.spines.right':False, 'axes.edgecolor':'#8B9DA5', 'axes.labelcolor':DARK,
        'text.color':DARK, 'xtick.labelsize':7.2, 'ytick.labelsize':7.2,
        'grid.color':GRID, 'grid.linewidth':.6, 'legend.frameon':False,
        'legend.fontsize':7.0, 'pdf.fonttype':42, 'svg.fonttype':'none',
        'figure.facecolor':'white', 'savefig.facecolor':'white'})
    fig = plt.figure(figsize=(180/25.4, 245/25.4))
    grid = fig.add_gridspec(3, 2, height_ratios=[1.42, 1, 1],
                           left=.21, right=.97, bottom=.09, top=.885,
                           wspace=.42, hspace=.63)
    ax_a, ax_b = fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])
    ypos = np.arange(len(chosen))[::-1]
    for cohort, shift, colour, label in [('development',.16,BLUE,'Development (n = 161)'),
                                        ('external',-.16,ORANGE,'External (n = 550)')]:
        g = global_table[global_table.cohort.eq(cohort)].set_index('feature').loc[chosen]
        ax_a.barh(ypos+shift, g.mean_absolute_shap, height=.27, color=colour, label=label)
        ax_a.errorbar(g.mean_absolute_shap, ypos+shift,
                     xerr=[g.mean_absolute_shap-g.lower,g.upper-g.mean_absolute_shap],
                     fmt='none', ecolor=colour, lw=.7, capsize=1.4)
    ax_a.set_yticks(ypos, [LABELS[f] for f in chosen])
    ax_a.set_xlabel('Mean absolute SHAP value\n(log-odds scale)')
    ax_a.set_xlim(left=0)
    ax_a.set_title('A  Contributions across cohorts', loc='left', pad=28)
    handles, legend_labels = ax_a.get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc='upper left', bbox_to_anchor=(.20,.965), ncol=2, fontsize=7.1)
    ax_a.grid(axis='x', alpha=.45)
    ax_a.set_axisbelow(True)

    cmap = LinearSegmentedColormap.from_list('feature_value', [BLUE, '#E5E5E5', ORANGE])
    for y, f in zip(ypos, chosen):
        rows = distribution[distribution.feature.eq(f)]
        ax_b.scatter(rows.shap_mean, y+(rows.value_tertile-1)*.20,
            c=rows.feature_development_percentile, cmap=cmap, norm=Normalize(0,100),
            s=5+rows.n*.70, alpha=.82, linewidths=0)
    ax_b.axvline(0, color='#637580', lw=.8)
    ax_b.set_yticks(ypos, [])
    ax_b.set_ylim(ax_a.get_ylim())
    ax_b.set_title('B  External SHAP distribution', loc='left', pad=28)
    ax_b.set_xlabel('SHAP contribution to log odds')
    ax_b.grid(axis='y', alpha=.4)
    ax_b.set_axisbelow(True)
    cbax = ax_b.inset_axes([.12, 1.01, .75, .025])
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=Normalize(0,100),cmap=cmap), cax=cbax,
                      orientation='horizontal')
    bar.set_ticks([0,100], labels=['Lower feature value','Higher feature value'])
    cbax.tick_params(labelsize=6.2, length=0, pad=1)
    bar.outline.set_visible(False)

    for k,f in enumerate(selected):
        ax = fig.add_subplot(grid[1+k//2, k%2])
        for cohort, colour, label in [('development',BLUE,'Development'),('external',ORANGE,'External')]:
            d = dependence[dependence.feature.eq(f)&dependence.cohort.eq(cohort)].sort_values('bin')
            ax.fill_between(d.feature_development_percentile, d.shap_q25, d.shap_q75,
                            color=colour, alpha=.12, linewidth=0)
            ax.plot(d.feature_development_percentile, d.shap_median, color=colour,
                    marker='o', markersize=3, lw=1.1, label=label)
        ax.axhline(0, color='#637580', lw=.7, ls='--')
        ax.set_xlim(0,100)
        ax.set_xticks([0,25,50,75,100])
        ax.set_xlabel('Feature percentile in development cohort')
        ax.set_ylabel('SHAP contribution (log odds)')
        ax.set_title(f'{chr(67+k)}  {LABELS[f]}', loc='left', pad=10)
        ax.grid(alpha=.35)
    for suffix in ['pdf','svg','png']:
        path = ROOT/f'figures/supplement/Figure_S5_HistGB_SHAP.{suffix}'
        path.parent.mkdir(parents=True,exist_ok=True)
        fig.savefig(path,dpi=300)
    plt.close(fig)


def main():
    development, development_path = load_source('development')
    external, external_path = load_source('external')
    model_path = ROOT/'models'/f"{SCFG['model']}.joblib"
    model_hash = sha(model_path)
    if model_hash != CFG['original_model_sha256'][SCFG['model']]:
        receipt = json.loads((ROOT/'audit/model_reconstruction.json').read_text())
        assert receipt['status'] == 'passed'
        assert receipt['models'][SCFG['model']]['sha256'] == model_hash
    pipeline = joblib.load(model_path)
    assert list(pipeline.classes_) == [0,1]
    prep = pipeline.named_steps['preprocess']
    classifier = pipeline.named_steps['classifier']
    mapping = feature_mapping(prep)
    transformed_features = mapping.feature.tolist()
    feature_order = CFG['features']
    reorder = [transformed_features.index(f) for f in feature_order]
    background = np.asarray(prep.transform(development[feature_order]), dtype=float)
    assert background.shape == (161,20)
    # Explicit max_samples prevents the default Independent masker from taking 100 rows.
    masker = shap.maskers.Independent(background, max_samples=len(background))
    explainer = shap.TreeExplainer(classifier, data=masker,
        feature_perturbation=SCFG['feature_perturbation'], model_output=SCFG['model_output'])
    np.testing.assert_array_equal(explainer.data, background)
    assert len(explainer.data) == len(development)
    expected = float(np.asarray(explainer.expected_value).squeeze())
    global_tables, checks, stored = [], {}, {}
    for role, raw in [('development',development),('external',external)]:
        x = np.asarray(prep.transform(raw[feature_order]),dtype=float)
        # Library output is a diagnostic comparison only. Its threshold-boundary
        # discrepancies are not accepted: final values use exact coalition sums.
        explanation = explainer(x,check_additivity=False)
        library_values = np.asarray(explanation.values,dtype=float)
        transformed_values, exact_expected, tree_checks = exact_treewise_shap(classifier,background,x)
        assert abs(exact_expected-expected) < 1e-12
        assert transformed_values.shape == x.shape
        values = transformed_values[:,reorder]
        logits = np.asarray(classifier.decision_function(x)).ravel()
        rounded_diagnostic = single_precision_tree_diagnostic(classifier,background,x,expected)
        library_reconstructed = expected+library_values.sum(axis=1)
        np.testing.assert_allclose(library_reconstructed,rounded_diagnostic,atol=1e-7,rtol=0)
        probability = pipeline.predict_proba(raw[feature_order])[:,1]
        reconstruction = expected + values.sum(axis=1)
        raw_error = float(np.max(np.abs(reconstruction-logits)))
        probability_error = float(np.max(np.abs(expit(reconstruction)-probability)))
        assert raw_error <= SCFG['additivity_absolute_tolerance']
        assert probability_error <= SCFG['additivity_absolute_tolerance']
        np.testing.assert_allclose(explanation.base_values, expected, atol=1e-12, rtol=0)
        if role == 'external':
            recorded = pd.read_csv(ROOT/'results/external_predictions_private.csv',float_precision='round_trip')
            np.testing.assert_array_equal(recorded.id.to_numpy(), raw.id.to_numpy())
            np.testing.assert_allclose(probability,recorded[SCFG['model']],atol=1e-12,rtol=0)
        ranks = np.column_stack([development_percentile(development[f],raw[f]) for f in feature_order])
        stored[role] = dict(values=values,ranks=ranks,raw=raw)
        table = global_importance(values,feature_order,role)
        global_tables.append(table)
        private = pd.DataFrame({'cohort':role,'row_index':np.arange(len(raw)), 'id':raw.id,
            'base_log_odds':expected,'model_log_odds':logits,'predicted_probability':probability,
            **{f'shap_{f}':values[:,j] for j,f in enumerate(feature_order)}})
        save(private,f'results/shap_{role}_private.csv')
        save(pd.DataFrame(x,columns=mapping.transformed_name),f'results/shap_{role}_transformed_private.csv')
        save(pd.DataFrame({'cohort':role,'row_index':np.arange(len(raw)),'id':raw.id,
                          'native_model_log_odds':logits,'exact_shap_reconstructed_log_odds':reconstruction,
                          'library_reconstructed_log_odds':library_reconstructed,
                          'float32_threshold_diagnostic_log_odds':rounded_diagnostic,
                          'library_additivity_error':library_reconstructed-logits}),
             f'results/shap_{role}_library_diagnostics_private.csv')
        checks[role] = dict(n=len(raw), features=x.shape[1], maximum_raw_additivity_error=raw_error,
                           maximum_probability_reconstruction_error=probability_error,
                           mean_model_probability=float(probability.mean()),
                           mean_model_log_odds=float(logits.mean()),
                           exact_tree_coalitions_checked=len(tree_checks),
                           maximum_distinct_features_in_any_tree=max(tree_checks),
                           library_maximum_additivity_error=float(np.max(np.abs(expected+library_values.sum(axis=1)-logits))),
                           library_rows_failing_additivity=int(np.sum(np.abs(expected+library_values.sum(axis=1)-logits)>1e-6)),
                           library_vs_float32_threshold_diagnostic_max_error=float(np.max(np.abs(library_reconstructed-rounded_diagnostic))),
                           maximum_library_feature_attribution_difference=float(np.max(np.abs(library_values-transformed_values))))
    global_table = pd.concat(global_tables,ignore_index=True)
    dev_imp = global_table[global_table.cohort.eq('development')].copy()
    # Stable sort preserves configured clinical order for exact ties.
    rank = dev_imp.sort_values('mean_absolute_shap',ascending=False,kind='stable').feature.tolist()
    rank_map = {f:i+1 for i,f in enumerate(rank)}
    global_table['development_rank'] = global_table.feature.map(rank_map)
    global_table = global_table.sort_values(['development_rank','cohort'])
    chosen = rank[:SCFG['main_display_feature_count']]
    selected = rank[:SCFG['dependence_feature_count']]
    distribution = distribution_bins(stored['external']['values'],stored['external']['ranks'],
                                     feature_order,chosen)
    dependence = pd.concat([dependence_bins(s['values'],s['ranks'],s['raw'],feature_order,selected,role)
                            for role,s in stored.items()],ignore_index=True)
    save(mapping,'tables/supplement/shap_feature_mapping.csv')
    save(global_table,'tables/supplement/shap_global_importance.csv')
    save(global_table,'figure_data/Figure_S5_SHAP_global_importance.csv')
    save(distribution,'figure_data/Figure_S5_SHAP_external_distribution.csv')
    save(dependence,'figure_data/Figure_S5_SHAP_dependence.csv')
    save(dependence,'tables/supplement/shap_dependence_summary.csv')
    display = []
    for feature in rank:
        row = {'Development rank':rank_map[feature],'Predictor':LABELS[feature]}
        for role in ['development','external']:
            result = global_table[global_table.feature.eq(feature)&global_table.cohort.eq(role)].iloc[0]
            row[f'{role.capitalize()} mean absolute SHAP (95% interval)'] = f'{result.mean_absolute_shap:.3f} ({result.lower:.3f}, {result.upper:.3f})'
            row[f'{role.capitalize()} share, %'] = f'{result.percent_total_absolute_shap:.1f}'
        display.append(row)
    display_frame = pd.DataFrame(display)
    save(display_frame,'tables/supplement/shap_global_importance_display.csv')
    html = '<!doctype html><meta charset="utf-8"><style>body{font:14px Arial;margin:36px;color:#172F3B}table{border-collapse:collapse}th,td{padding:7px 10px;border-bottom:1px solid #dce5e9;text-align:left}th{background:#edf4f8}p{max-width:1100px}</style><h1>SHAP global importance of all 20 model predictors</h1><p>Development: 161 participants; external validation: 550 participants. Contributions use the log-odds scale and all development participants as the fixed background. Rows follow development importance.</p>'
    html += display_frame.to_html(index=False,border=0)
    html += '<p>Intervals are descriptive participant-bootstrap percentile intervals conditional on the fixed fitted model and reference background; they exclude uncertainty from model development. Share is the percentage of the summed mean absolute contributions. Zero means that this fitted tree ensemble assigns no contribution to that predictor. SHAP explains model predictions and does not establish causal or independent clinical effects.</p>'
    (ROOT/'tables/supplement/shap_global_importance_display.html').write_text(html,encoding='utf-8')
    dev_vector = global_table[global_table.cohort.eq('development')].set_index('feature').loc[feature_order].mean_absolute_shap
    ext_vector = global_table[global_table.cohort.eq('external')].set_index('feature').loc[feature_order].mean_absolute_shap
    summary = dict(analysis_id=SCFG['analysis_id'],model=SCFG['model'],
        expected_log_odds=expected,expit_expected_log_odds=float(expit(expected)),
        background_n=len(background),development_n=len(development),external_n=len(external),
        development_feature_order=rank,dependence_features=selected,
        development_external_importance_spearman=float(spearmanr(dev_vector,ext_vector).statistic),
        top_feature_importance=global_table[global_table.feature.isin(rank[:5])].to_dict('records'),
        interpretation=SCFG['interpretation'],
        baseline_note='The sigmoid of mean background log odds is not mean background predicted probability.')
    (ROOT/'results/shap_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    plot(global_table,distribution,dependence,chosen,selected,summary)
    audit = dict(status='passed',created_utc=datetime.now(timezone.utc).isoformat(),
        python=sys.version,package_versions={p:version(p) for p in ['shap','numpy','scipy','scikit-learn','pandas','numba']},
        model_sha256=model_hash,development_sha256=sha(development_path),external_sha256=sha(external_path),
        code_sha256=sha(__file__),shap_config_sha256=sha(ROOT/'config/shap_config.json'),
        input_data_unchanged=True,model_file_unchanged=sha(model_path)==model_hash,
        background_exactly_all_development_rows=True,background_n=len(explainer.data),
        external_data_used_in_background=False,model_fitting_performed=False,
        outcome_used_for_explanation=False,feature_order_basis='development mean absolute SHAP',
        exact_method=SCFG['calculation'],library_cross_check=SCFG['library_cross_check'],
        transformation_mapping_one_to_one=True,checks=checks,
        public_distribution_minimum_cell=int(distribution.n.min()),
        public_plotting_data_are_aggregate=True)
    (ROOT/'audit/shap_additivity.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({'status':'passed','top5':rank[:5],'base_log_odds':expected,'checks':checks},indent=2))


if __name__ == '__main__':
    main()
