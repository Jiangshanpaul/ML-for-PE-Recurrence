"""Independently verify exact interventional Shapley values for the locked trees.

This audit traverses native node arrays with NumPy, rather than calling the
explanation implementation or the native prediction method for coalition values.
It enumerates feature permutations and averages marginal contributions. Clinical
outcomes are not used for selecting targets or explaining the model.
"""
from pathlib import Path
from itertools import permutations
from datetime import datetime, timezone
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from scipy.special import expit

ROOT = Path(__file__).resolve().parents[1]


def checksum(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def traverse(tree, matrix):
    """Apply original double-precision numerical thresholds and missing routing."""
    nodes = tree.nodes
    assert not np.any(nodes['is_categorical'])
    result = np.empty(len(matrix))
    pending = [(0, np.arange(len(matrix)))]
    while pending:
        node_number, row = pending.pop()
        if not len(row):
            continue
        node = nodes[node_number]
        if node['is_leaf']:
            result[row] = node['value']
            continue
        values = matrix[row, int(node['feature_idx'])]
        go_left = np.where(np.isnan(values), bool(node['missing_go_to_left']),
                           values <= node['num_threshold'])
        pending.append((int(node['left']), row[go_left]))
        pending.append((int(node['right']), row[~go_left]))
    return result


def enumerate_permutations(tree, background, targets):
    used = np.unique(tree.nodes['feature_idx'][~tree.nodes['is_leaf'].astype(bool)]).astype(int)
    assert len(used) <= 2
    values = np.zeros_like(targets)
    base = traverse(tree, background).mean()
    orders = list(permutations(used))
    for order in orders:
        mixtures = np.repeat(background[None, :, :], len(targets), axis=0)
        previous = np.full(len(targets), base)
        for feature in order:
            mixtures[:, :, feature] = targets[:, feature, None]
            updated = traverse(tree, mixtures.reshape(-1, background.shape[1])).reshape(len(targets), -1).mean(axis=1)
            values[:, feature] += (updated - previous) / len(orders)
            previous = updated
    return base, values


def node_representatives(tree, background):
    """Return an observed background row that reaches every splitting node."""
    result = {}
    pending = [(0, np.arange(len(background)))]
    while pending:
        node_number, rows = pending.pop()
        node = tree.nodes[node_number]
        if node['is_leaf']:
            continue
        assert len(rows), 'Every fitted splitting node must be represented in development'
        result[node_number] = background[rows[0]]
        values = background[rows, int(node['feature_idx'])]
        left = np.where(np.isnan(values), bool(node['missing_go_to_left']), values <= node['num_threshold'])
        pending.extend([(int(node['left']), rows[left]), (int(node['right']), rows[~left])])
    return result


def main():
    cfg = json.loads((ROOT/'config/evaluation_charter.json').read_text(encoding='utf-8-sig'))
    path = ROOT/'models/hist_gradient_boosting.joblib'
    pipeline = joblib.load(path)
    model = pipeline.named_steps['classifier']
    prep = pipeline.named_steps['preprocess']
    mapping = pd.read_csv(ROOT/'tables/supplement/shap_feature_mapping.csv')
    assert mapping.transformed_name.tolist() == prep.get_feature_names_out().tolist()
    transformed_features = mapping.feature.tolist()
    assert len(set(transformed_features)) == len(cfg['features']) == 20
    reorder = [transformed_features.index(f) for f in cfg['features']]
    records, matrices, stored = {}, {}, {}
    for role in ['development', 'external']:
        source = ROOT/cfg['data_directory']/cfg[role+'_file']
        assert checksum(source) == cfg['raw_sha256'][source.name]
        raw = pd.read_csv(source, sep='\t', float_precision='round_trip')

        assert len(raw) == cfg[role+'_n']
        matrices[role] = np.asarray(prep.transform(raw[cfg['features']]), float)
        stored[role] = pd.read_csv(ROOT/f'results/shap_{role}_private.csv', float_precision='round_trip')
        np.testing.assert_array_equal(stored[role].id, raw.id)
        all_values = stored[role][['shap_'+f for f in cfg['features']]].to_numpy()
        probabilities = pipeline.predict_proba(raw[cfg['features']])[:, 1]
        np.testing.assert_allclose(expit(stored[role].base_log_odds + all_values.sum(axis=1)), probabilities, rtol=0, atol=1e-12)
        importance = pd.read_csv(ROOT/'tables/supplement/shap_global_importance.csv', float_precision='round_trip')
        expected = importance.loc[importance.cohort.eq(role)].set_index('feature').loc[cfg['features']]
        np.testing.assert_allclose(np.abs(all_values).mean(axis=0), expected.mean_absolute_shap, atol=1e-12, rtol=0)
        records[role] = {'n': len(raw), 'all_participant_probability_reconstruction': 'passed', 'global_importance_reconciliation': 'passed'}
    background = matrices['development']
    assert background.shape == (161, 20)
    targets = []
    selected = {}
    for role in ['development', 'external']:
        # Stable selection by row position only, independent of events or scores.
        selected[role] = np.linspace(0, len(matrices[role])-1, 12, dtype=int)
        targets.append(matrices[role][selected[role]])
    targets = np.vstack(targets)
    baseline = float(np.asarray(model._baseline_prediction).squeeze())
    exact = np.zeros_like(targets)
    known, index_map = model._bin_mapper.make_known_categories_bitsets()
    tree_prediction_error = 0.
    boundary_checks = 0
    original_targets = np.vstack([background, matrices['external']])
    manual_logits = np.full(len(original_targets), baseline)
    for stage in model._predictors:
        assert len(stage) == 1
        tree = stage[0]
        manual = traverse(tree, original_targets)
        native = tree.predict(original_targets, known, index_map, 1)
        tree_prediction_error = max(tree_prediction_error, float(np.abs(manual-native).max()))
        manual_logits += manual
        base, contributions = enumerate_permutations(tree, background, targets)
        baseline += base
        exact += contributions
        for node_number, representative in node_representatives(tree, background).items():
            node = tree.nodes[node_number]
            probe = np.repeat(representative[None, :], 3, axis=0)
            threshold = float(node['num_threshold'])
            probe[:, int(node['feature_idx'])] = [np.nextafter(threshold, -np.inf), threshold, np.nextafter(threshold, np.inf)]
            np.testing.assert_allclose(traverse(tree, probe), tree.predict(probe, known, index_map, 1), atol=0, rtol=0)
            boundary_checks += len(probe)
    np.testing.assert_allclose(manual_logits, model.decision_function(original_targets), atol=1e-12, rtol=0)
    np.testing.assert_allclose(baseline, model.decision_function(background).mean(), atol=1e-12, rtol=0)
    expected = np.vstack([stored[role].iloc[selected[role]][['shap_'+f for f in cfg['features']]].to_numpy() for role in ['development', 'external']])
    maximum_error = float(np.max(np.abs(exact[:, reorder]-expected)))
    np.testing.assert_allclose(exact[:, reorder], expected, atol=1e-12, rtol=0)
    np.testing.assert_allclose(baseline + exact.sum(axis=1), model.decision_function(targets), atol=1e-12, rtol=0)
    record = dict(status='passed', created_utc=datetime.now(timezone.utc).isoformat(),
        independent_method='Manual double-precision tree traversal and exhaustive feature-permutation averaging',
        model_sha256=checksum(path), audit_code_sha256=checksum(__file__),
        explanation_code_sha256=checksum(ROOT/'code/explain_histgb.py'),
        background_n=161, external_background_n=0, outcome_based_selection=False,
        targets_with_independent_permutation_enumeration=len(targets),
        participants_with_independent_tree_prediction=len(original_targets),
        trees=len(model._predictors), threshold_boundary_prediction_checks=boundary_checks,
        maximum_tree_prediction_error=tree_prediction_error,
        maximum_independent_feature_attribution_error=maximum_error,
        all_cohort_checks=records,
        scientific_review='The dummy-player property reduces each tree to its used predictors; Shapley linearity sums tree values. Missing features are jointly sampled from complete development background rows, matching empirical interventional SHAP. Fixed-model uncertainty does not cover fitting, selection or correlated-feature assumptions.')
    (ROOT/'audit/shap_independent_review.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
