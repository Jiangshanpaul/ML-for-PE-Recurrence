"""Render aggregate supplementary result tables as CSV and HTML.

This script reads locked analysis tables only. It performs no fitting, selection,
or manuscript/Word generation. Dense source CSVs remain complete; the decision
curve display explicitly uses fixed thresholds 0.05, 0.10, 0.20 and 0.30.
"""
from pathlib import Path
import json, html, hashlib, re
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'tables/supplement'
DEST=ROOT/'tables/supplement_display'
DEST.mkdir(exist_ok=True)

labels={'hist_gradient_boosting':'HistGB','ridge':'AUC-tuned ridge','lightgbm':'LightGBM','bagged_mlp':'Bagged neural network','svm_rbf':'Calibrated RBF SVM','locked_primary':'Original primary ridge','compact_primary':'Compact ridge','elastic_net':'Elastic-net logistic','random_forest':'Random forest','xgboost':'XGBoost','extra_trees':'Extra trees','catboost':'CatBoost','mlp':'Neural network','spline_logistic':'Spline logistic','stacking':'Stacking','adaptive_inner_auc_selection':'Adaptive inner-CV AUC procedure','original_logloss_procedure':'Original log-loss procedure','treat_all':'Treat all','treat_none':'Treat none'}
registry=[];source_hashes={};started=False

def read(name):
 p=SRC/(name+'.csv');source_hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
 return pd.read_csv(p,float_precision='round_trip')

def val(x,d=3):return 'Not estimable' if pd.isna(x) else f'{x:.{d}f}'
def ci(r,d=3,scale=1):
 if pd.isna(r['estimate']):return 'Not estimable'
 if pd.isna(r.get('lower',np.nan)):return val(r['estimate']*scale,d)
 return f"{r['estimate']*scale:.{d}f} ({r['lower']*scale:.{d}f}, {r['upper']*scale:.{d}f})"
def meanrange(r):return f"{r['mean']:.3f} [{r['min']:.3f}, {r['max']:.3f}]"
def one(df,model,metric):return df[df.model.eq(model)&df.metric.eq(metric)].iloc[0]

def display(stem,heading,headers,rows,widths,footnote):
    """Export one aggregate display panel without document-generation dependencies."""
    frame=pd.DataFrame(rows,columns=headers)
    frame=frame.map(lambda value: re.sub(r'(?<!\d)-0\.(0+)(?!\d)',r'0.\1',value) if isinstance(value,str) else value)
    frame.to_csv(DEST/(stem+'.csv'),index=False,encoding='utf-8-sig')
    css='body{font-family:Arial;color:#172f3b;margin:32px}h1{font-size:21px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:8px;border-bottom:1px solid #dde6ea}th{background:#edf3f6;text-align:left}p{font-size:13px;line-height:1.5}'
    (DEST/(stem+'.html')).write_text('<!doctype html><meta charset="utf-8"><style>'+css+'</style><h1>'+html.escape(heading)+'</h1>'+frame.to_html(index=False,escape=True)+'<p>'+html.escape(footnote)+'</p>',encoding='utf-8')
    registry.append(dict(stem=stem,title=heading,rows=len(frame),columns=headers,note=footnote))

ranking=read('development_ranking').sort_values('rank');internal=read('development_internal_summary');apparent=read('development_apparent')
rows=[]
for _,r in ranking.iterrows():
 a=one(internal,r.model,'auc');b=one(internal,r.model,'brier');l=one(internal,r.model,'log_loss')
 rows.append([str(int(r['rank'])),labels[r.model],val(one(apparent,r.model,'auc').estimate),meanrange(a),meanrange(b),meanrange(l),'Yes' if r.top5 else 'No'])
for model in ['adaptive_inner_auc_selection','original_logloss_procedure']:
 rows.append(['—',labels[model],'—',meanrange(one(internal,model,'auc')),meanrange(one(internal,model,'brier')),meanrange(one(internal,model,'log_loss')),'Procedure'])
display('Table_S1_development','Table S1. Complete development comparison',
 ['Rank','Family / procedure','Training AUC','Internal AUC, mean [range]','Internal Brier, mean [range]','Internal log loss, mean [range]','External candidate'],rows,[750,2800,1400,2450,2450,2450,1524],
 'Development n=161, including 47 recorded recurrences. Training AUC evaluates the final model on these same participants used for fitting. Internal estimates are the mean and observed range of three repeat-specific nested OOF evaluations (five outer / three inner folds). Repeat ranges are not confidence intervals. Families were ranked on mean OOF AUC; ranking adds selection optimism. The two procedure rows evaluate different rules and are not extra candidate models. Full repeat-specific metrics are in development_repeat_performance.csv.')
perf=read('external_performance');order=ranking[ranking.top5].model.tolist()+['locked_primary','compact_primary']
for letter,metrics,heads in [('A',['auc','average_precision','brier','log_loss'],['AUROC','Average precision','Brier score','Log loss']),('B',['mean_predicted','observed_expected','calibration_intercept','calibration_slope'],['Mean predicted probability','Observed/expected','Calibration intercept','Calibration slope'])]:
 rows=[[labels[m]]+[ci(one(perf,m,k),3 if k in ['auc','average_precision','brier','log_loss','mean_predicted'] else 2) for k in metrics] for m in order]
 display('Table_S2'+letter+'_external','Table S2'+letter+'. Complete external performance',['Model']+[h+' (95% CI)' for h in heads],rows,[2900,2656,2656,2656,2656],
 'Final external n=550, including 101 recorded recurrences (18.36%). Intervals condition on frozen models and use 2,000 participant bootstrap resamples; calibration regression uses 500. Ideal intercept=0, slope=1 and observed/expected=1. The prevalence interval is '+ci(one(perf,order[0],'prevalence'))+'. No external recalibration was applied. Complete machine-readable results are in external_performance.csv.')
cal=read('external_calibration');rows=[]
for m in order[:5]:
 for _,r in cal[cal.model.eq(m)].iterrows():
  rows.append([labels[m],str(int(r.group)),str(int(r.n)),str(int(r.events)),val(r.mean_predicted),f'{r.observed:.3f} ({r.lower:.3f}, {r.upper:.3f})'])
display('Table_S3A_calibration','Table S3A. Grouped external calibration',['Model','Group','n','Events','Mean predicted','Recorded fraction (95% CI)'],rows,[3150,1000,1000,1000,2400,2974],
 'Calibration groups use development OOF quintile boundaries transferred unchanged. Recorded-fraction intervals use the Wilson method. Original group assignments and complete coordinates are in external_calibration.csv.')
dca=read('external_decision_curve');thresholds=[.05,.10,.20,.30];rows=[]
for m in order[:5]+['locked_primary','treat_all','treat_none']:
 rows.append([labels[m]]+[val(dca[dca.model.eq(m)&np.isclose(dca.threshold,t)].net_benefit.iloc[0]) for t in thresholds])
display('Table_S3B_decision_curve','Table S3B. Descriptive decision-curve display subset',['Model']+[f'Net benefit at threshold {t:.2f}' for t in thresholds],rows,[3100,2681,2681,2681,2681],
 'Display subset at fixed illustrative probability thresholds 0.05, 0.10, 0.20 and 0.30; all thresholds 0.01–0.50 remain in external_decision_curve.csv. These thresholds are not anticoagulation recommendations. The binary outcome has unequal observation periods, and net benefit is descriptive without an established clinical benefit–harm trade-off.')
paired=read('external_paired_comparison')
for k,comp in enumerate(['locked_primary','compact_primary']):
 rows=[[labels[m]]+[ci(one(paired[paired.comparator.eq(comp)],m,key),4 if key=='brier' and m=='hist_gradient_boosting' and comp=='locked_primary' else 3) for key in ['auc','average_precision','brier','log_loss']] for m in order[:5]]
 display('Table_S4'+chr(65+k)+'_paired','Table S4'+chr(65+k)+'. Paired differences versus '+labels[comp].lower(),['Model','ΔAUROC (95% CI)','ΔAverage precision (95% CI)','ΔBrier (95% CI)','ΔLog loss (95% CI)'],rows,[2900,2656,2656,2656,2656],
 'Each estimate is candidate minus comparator in the same 550 external participants. Common participant bootstrap resamples generate paired intervals. Positive discrimination differences and negative error differences favour the candidate. The comparisons are exploratory and not multiplicity-adjusted. Both comparator series are fully retained in external_paired_comparison.csv.')
groups=read('histgb_score_groups');contrasts=read('histgb_group_contrasts')
rows=[[r.label,str(int(r.n)),str(int(r.events)),f'{100*r.observed:.1f} ({100*r.lower:.1f}, {100*r.upper:.1f})',f'{100*r.mean_predicted:.1f}'] for _,r in groups.iterrows()]
display('Table_S5A_groups','Table S5A. HistGB score-group recurrence estimates',['Group','n','Events','Recorded recurrence, % (95% CI)','Mean prediction, %'],rows,[2400,1500,1500,4824,3600],
 'Development OOF tertile cut points: approximately 0.192 and 0.359; assignments use full precision. Group fractions use all recorded outcomes and Wilson intervals. These scores do not define a common risk horizon or validated treatment category.')
rows=[]
for _,r in contrasts.iterrows():
 isdiff=r.metric=='risk_difference_high_minus_low'
 rows.append(['Higher minus lower fraction, percentage points' if isdiff else 'Higher/lower recorded-fraction ratio',ci(r,1 if isdiff else 2,100 if isdiff else 1),str(int(r.valid_bootstrap)),str(int(r.infinite_bootstrap))])
display('Table_S5B_contrasts','Table S5B. Descriptive score-group contrasts',['Contrast','Estimate (95% CI)','Resamples used','Resamples with infinite ratio'],rows,[5200,3824,2000,2800],
 'Contrasts use binary outcomes over individual follow-up. The ratio is sparse-event-sensitive: resamples with zero lower-group events yield an infinite ratio; the percentile interval is interpreted in that context. This is not a causal contrast or a common-horizon risk ratio. Complete data are in histgb_group_contrasts.csv.')
time=read('time_auc_sensitivity');rows=[]
for m in order[:5]:
 for h in [12,36,60]:
  d=time[time.cohort.eq('Development')&time.model.eq(m)&time.horizon_months.eq(h)].iloc[0];e=time[time.cohort.eq('External')&time.model.eq(m)&time.horizon_months.eq(h)].iloc[0]
  rows.append([labels[m],str(h),f'{d.estimate:.3f} [{d.repeat_minimum:.3f}, {d.repeat_maximum:.3f}]',ci(e),str(int(e.events))])
display('Table_S6A_time_AUC','Table S6A. Time-specific discrimination',['Model','Months','Development OOF AUC, mean [range]','External AUROC (95% CI)','External VTE events'],rows,[3100,1000,3500,3500,1924],
 'Cumulative/dynamic AUC uses cohort-specific inverse-probability-of-censoring weights. Controls include competing deaths. Internal values average three separately evaluated repeated OOF estimates; external CIs use 1,000 participant bootstrap resamples. Full repeat values are retained in time_auc_development_repeats.csv.')
diagnostics=read('time_diagnostics');rows=[]
for _,r in diagnostics.iterrows():rows.append([r.cohort,str(int(r.horizon_months)),str(int(r.vte_by_horizon)),str(int(r.death_by_horizon)),str(int(r.at_risk_at_horizon)),str(int(r.censored_before_horizon)),val(r.maximum_weight,2),val(r.effective_sample_size,1)])
display('Table_S6B_censoring','Table S6B. Censoring diagnostics',['Cohort','Months','VTE events','Competing deaths','At risk','Censored earlier','Maximum weight','IPCW effective n'],rows,[2100,1000,1500,1900,1500,1900,1900,2024],
 'Risk sets count participants immediately before the horizon. Clinical events are processed before censoring at tied times. Effective sample size measures weight concentration and differs from the observed risk set. Full censoring-survival values and tie definitions are in time_diagnostics.csv.')
risk=read('aj_at_risk');rows=[]
for (cohort,stratum),g in risk.groupby(['cohort','stratum'],sort=False):rows.append([cohort,stratum]+[str(int(g[g.month.eq(t)].n_at_risk.iloc[0])) for t in [0,12,24,36,48,60]])
display('Table_S6C_risk_sets','Table S6C. Numbers at risk immediately before each time',['Cohort','Stratum']+[f'{t} months' for t in [0,12,24,36,48,60]],rows,[2300,2300,1537,1537,1537,1537,1537,1539],
 'Risk sets support the Aalen–Johansen curves and retain the original event-time ordering. The final score groups are development-defined. Events exactly at a horizon occur after the immediately preceding risk-set count.')
aj=read('aj_horizon_summary');rows=[]
for _,r in aj.iterrows():rows.append([r.cohort,r.stratum,str(int(r.horizon_months)),str(int(r.n)),str(int(r.events)),str(int(r.competing_deaths)),ci(r,1,100),str(int(r.n_at_risk))])
display('Table_S7_AJ','Table S7. Aalen–Johansen cumulative incidence',['Cohort','Stratum','Months','n','VTE events','Competing deaths','VTE incidence, % (95% CI)','At risk'],rows,[1800,2000,900,900,1300,1800,3524,1600],
 'Cumulative incidence accounts for competing death and censoring; derived endpoints are censored at month 60. Overall intervals use 1,000 bootstrap resamples; score-group intervals use 500. Zero-event intervals are suppressed; the lower-score group has only one event by month 60, making its percentile interval unstable. Pointwise intervals are not simultaneous confidence bands.')
subgroups=read('histgb_subgroups');rows=[]
for g in subgroups.group.unique():
 a=subgroups[subgroups.group.eq(g)&subgroups.metric.eq('auc')].iloc[0];b=subgroups[subgroups.group.eq(g)&subgroups.metric.eq('brier')].iloc[0]
 rows.append([g.replace('>=','≥'),str(int(a.n)),str(int(a.events)),ci(a),ci(b),str(int(a.valid_bootstrap))+'/1000'])
display('Table_S8_subgroups','Table S8. Exploratory subgroup performance',['Group','n','Events','AUROC (95% CI)','Brier (95% CI)','Valid AUROC resamples'],rows,[2600,1000,1000,3400,3400,2124],
 'The identical frozen HistGB model is applied in all strata. Diabetes contains eight events, and two resamples lacked outcome variation. No formal interaction test is represented; overlap of intervals is not evidence of equivalent performance.')
importance=read('shap_global_importance');mapping=read('shap_feature_mapping');rows=[]
for f in importance.sort_values('development_rank').feature.drop_duplicates():
 d=importance[importance.feature.eq(f)&importance.cohort.eq('development')].iloc[0];e=importance[importance.feature.eq(f)&importance.cohort.eq('external')].iloc[0]
 rows.append([str(int(d.development_rank)),d.label,f'{d.mean_absolute_shap:.3f} ({d.lower:.3f}, {d.upper:.3f})',f'{e.mean_absolute_shap:.3f} ({e.lower:.3f}, {e.upper:.3f})',mapping[mapping.feature.eq(f)].preprocessing_block.iloc[0]])
display('Table_S9A_SHAP_importance','Table S9A. Complete SHAP importance and transformation mapping',['Rank','Predictor','Development mean |SHAP| (95% CI)','External mean |SHAP| (95% CI)','Preprocessing block'],rows,[700,3000,3500,3500,2224],
 'All 20 predictors in development-importance order. SHAP values are exact interventional contributions to log odds with all 161 development participants as fixed background. Intervals use 1,000 participant resamples conditional on this model and reference distribution. Zero contribution means unused by this fitted ensemble. The complete one-to-one transformed-column names are retained in shap_feature_mapping.csv.')
dep=read('shap_dependence_summary');rows=[]
for f in ['age','pulse','glucose','bmi']:
 for b in sorted(dep[dep.feature.eq(f)].bin.unique()):
  ds=dep[dep.feature.eq(f)&dep.bin.eq(b)].set_index('cohort');d=ds.loc['development'];e=ds.loc['external']
  rows.append([d.label,str(int(b)+1),str(int(d.n)),f'{d.shap_median:.3f} [{d.shap_q25:.3f}, {d.shap_q75:.3f}]',str(int(e.n)),f'{e.shap_median:.3f} [{e.shap_q25:.3f}, {e.shap_q75:.3f}]'])
for k in range(2):
 display('Table_S9'+chr(66+k)+'_SHAP_dependence','Table S9'+chr(66+k)+'. Binned SHAP dependence summaries',['Predictor','Percentile bin','Development n','Development median [IQR]','External n','External median [IQR]'],rows[k*16:(k+1)*16],[2400,1300,1600,3462,1600,3462],
 'Eight bins use empirical development percentiles. Within-bin values are median [interquartile range] of log-odds contributions, not confidence intervals. The four displayed features were selected by development importance; no outcome informed ranking. Full percentile coordinates and source-value summaries remain in shap_dependence_summary.csv. These are model descriptions, not causal effects.')



from sample_size_precision import assessment
precision=assessment()
rows=[[f"{r['assumed_auroc']:.2f}",f"{r['event_proportion']:.2f}",str(r['required_n']),str(r['available_n']),f"{r['expected_ci_width']:.3f}",'Yes' if r['meets_reference_precision'] else 'No'] for r in precision]
display('Table_S10_external_sample_size_precision','Table S10. External AUROC sample size precision assessment',
 ['Assumed AUROC','Event proportion','Required n','Available n','Expected CI width','Precision criterion met'],rows,[2000]*6,
 'The target is a two-sided 95% interval width at most 0.100, using Newcombe’s approximation. The reference scenario assumes AUROC 0.80 and event proportion 0.18, requiring 511 patients. This assessment concerns discrimination precision for the available external cohort; it does not determine recruitment, development adequacy, calibration precision or power for paired comparisons.')

(DEST/'table_metadata.json').write_text(json.dumps(registry,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
receipt=dict(status='passed',panels=len(registry),source_sha256=source_hashes,
             code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             model_fitting_performed=False,external_selection_performed=False)
(ROOT/'audit/supplementary_display_rendering.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(f'Rendered {len(registry)} supplementary table panels.')
