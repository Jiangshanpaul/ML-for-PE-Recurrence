"""Reconstruct fixed models using unchanged development data only.

This optional reproducibility path verifies predictions against historical
development fits before saving objects. It performs no tuning or reselection
and never reads external patients or external performance.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(key,'1')
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json
import joblib
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, FunctionTransformer, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, BaggingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from lightgbm import LGBMClassifier
from model_components import CheckedMLPClassifier

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'config/evaluation_charter.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def preprocessing(features):
    cats=[c for c in features if c in CFG['categorical']]
    logs=[c for c in features if c in CFG['log1p']]
    cont=[c for c in features if c not in cats+logs]
    numeric=Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())])
    logarithmic=Pipeline([('impute',SimpleImputer(strategy='median')),
        ('log',FunctionTransformer(np.log1p,feature_names_out='one-to-one')),('scale',StandardScaler())])
    categorical=Pipeline([('impute',SimpleImputer(strategy='most_frequent')),
        ('encode',OneHotEncoder(categories=[[1,2] if c=='gender' else [0,1] for c in cats],
                               drop='first',handle_unknown='error',sparse_output=False))])
    return ColumnTransformer([('numeric',numeric,cont),('log',logarithmic,logs),('categorical',categorical,cats)],remainder='drop')

def estimator(name):
    seed=CFG['seed'];features=CFG['compact_features'] if name=='compact_primary' else CFG['features']
    if name in ['ridge','locked_primary','compact_primary']:
        clf=LogisticRegression(C=.01 if name=='ridge' else .1,penalty='l2',solver='lbfgs',max_iter=10000,tol=1e-7)
    elif name=='hist_gradient_boosting':
        clf=HistGradientBoostingClassifier(learning_rate=.04,min_samples_leaf=25,l2_regularization=10,
            early_stopping=False,random_state=seed)
    elif name=='lightgbm':
        clf=LGBMClassifier(n_estimators=200,learning_rate=.03,reg_lambda=10,max_depth=3,verbosity=-1,
            n_jobs=1,random_state=seed,deterministic=True,force_col_wise=True)
    elif name=='bagged_mlp':
        mlp=CheckedMLPClassifier(hidden_layer_sizes=(8,),alpha=1.,solver='lbfgs',max_iter=2000,
            max_fun=50000,tol=1e-5,random_state=seed,early_stopping=False)
        clf=BaggingClassifier(estimator=mlp,n_estimators=5,max_samples=.8,max_features=1.,
            bootstrap=True,n_jobs=1,random_state=seed)
    elif name=='svm_rbf':
        clf=SVC(kernel='rbf',probability=False,random_state=seed)
    else:raise ValueError(name)
    model=Pipeline([('preprocess',preprocessing(features)),('classifier',clf)])
    if name=='svm_rbf':
        model=CalibratedClassifierCV(model,method='sigmoid',
            cv=StratifiedKFold(3,shuffle=True,random_state=seed+100+50000),ensemble=True,n_jobs=1)
    if name in CFG['top5_models']:
        params=CFG['fixed_parameters'][name].copy()
        key='classifier__estimator__hidden_layer_sizes'
        if key in params:params[key]=tuple(params[key])
        model.set_params(**params)
    return model

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only',action='store_true',help='Verify reconstruction without replacing original model artifacts')
    args=parser.parse_args()
    source=(ROOT/CFG['data_directory']/CFG['development_file']).resolve()
    assert sha(source)==CFG['raw_sha256'][source.name]
    d=pd.read_csv(source,sep='\t',float_precision='round_trip')

    reference=json.loads((ROOT/'config/development_prediction_checksums.json').read_text())
    assert len(d)==reference['n'] and int(d.Type.sum())==reference['events']
    hashes={}
    staged=ROOT/'models_reconstructed';staged.mkdir(exist_ok=True)
    for name in CFG['top5_models']+['locked_primary','compact_primary']:
        model=estimator(name);model.fit(d[CFG['features']],d.Type.to_numpy(int))
        p=model.predict_proba(d[CFG['features']])[:,1]
        signature=hashlib.sha256(np.round(p,12).astype('<f8').tobytes()).hexdigest()
        assert signature==reference['models'][name], 'Reconstructed model differs from locked development predictions'
        path=staged/f'{name}.joblib';joblib.dump(model,path)
        hashes[name]=dict(sha256=sha(path),development_probability_checksum=signature,checked_decimal_places=12)
    # Promote only after every reconstruction has passed its development check.
    (ROOT/'models').mkdir(exist_ok=True)
    if not args.check_only:
        for name in hashes:(ROOT/'models'/f'{name}.joblib').write_bytes((staged/f'{name}.joblib').read_bytes())
    report=dict(status='passed',created_utc=datetime.now(timezone.utc).isoformat(),
        models=hashes,development_file=source.name,development_sha256=sha(source),
        external_data_read=False,hyperparameter_search=False,model_ranking_changed=False,model_files_promoted=not args.check_only,
        note='Fixed model reconstruction for reproducibility; all development probabilities match the original fits')
    (ROOT/'audit/model_reconstruction.json').write_text(json.dumps(report,indent=2)+'\n')
    print('All seven fixed models reconstructed from development data and verified.')

if __name__=='__main__':main()
