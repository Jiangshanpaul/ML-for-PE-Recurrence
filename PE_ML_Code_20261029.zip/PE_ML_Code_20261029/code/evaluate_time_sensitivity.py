"""Time-based sensitivity analyses of frozen binary recurrence scores.

The binary scores are used only for discrimination at a stated horizon. They
are not cumulative-incidence predictions, so no time-specific calibration,
Brier score, or probability-based decision curve is computed. Source follow-up
and binary outcome values are never changed. A separate endpoint administratively
censors follow-up at 60 months and treats death before recurrent VTE as a
competing event. Score strata use previously fixed development OOF cut points.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

from survival_metrics import (
    UnsupportedCensoringError, aalen_johansen, censoring_km,
    horizon_weights, step_at, weighted_auc_ap,
)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def derive_endpoint(frame, cap):
    """Return new arrays; recurrence takes precedence over subsequent death."""
    raw_time = frame["fu_months"].to_numpy(float)
    recurrence = frame["Type"].to_numpy(int)
    death = frame["death"].to_numpy(int)
    if not np.isfinite(raw_time).all() or np.any(raw_time <= 0):
        raise ValueError("Observed follow-up must contain strictly positive finite months")
    if not np.isin(recurrence, [0, 1]).all() or not np.isin(death, [0, 1]).all():
        raise ValueError("Type and death must be binary")
    raw_status = np.where(recurrence == 1, 1, np.where(death == 1, 2, 0))
    time = np.minimum(raw_time, cap)
    status = np.where(raw_time <= cap, raw_status, 0)
    return raw_time, raw_status, time, status


def validate_predictions(frame, predictions, models):
    if not np.array_equal(predictions["row_index"], np.arange(len(frame))):
        raise ValueError("Prediction row order does not match the current source file")
    if not np.array_equal(predictions["Type"], frame["Type"]):
        raise ValueError("Prediction outcomes differ from the current source file")
    if "id" in predictions and not np.array_equal(predictions["id"], frame["id"]):
        raise ValueError("Prediction identifiers differ from the current source file")
    values = predictions[models].to_numpy(float)
    if not np.isfinite(values).all() or np.any((values < 0) | (values > 1)):
        raise ValueError("Frozen binary scores must be complete probabilities in [0, 1]")


def external_auc(time, status, scores, models, horizons, n_bootstrap, seed):
    """Participant bootstrap with censoring reestimated in each resample.

    A single set of participant indices is used across all models/horizons.
    These intervals condition on the frozen models and exclude development
    fitting and model-selection uncertainty.
    """
    point, diagnostics = {}, []
    for horizon in horizons:
        weights = horizon_weights(time, status, horizon)
        diagnostics.append(dict(cohort="External", horizon_months=horizon,
                                **weights.diagnostics))
        for j, model in enumerate(models):
            point[horizon, model] = weighted_auc_ap(
                weights.outcome, scores[:, j], weights.weight)["auc"]
    draws = {(h, model): np.full(n_bootstrap, np.nan)
             for h in horizons for model in models}
    failures = {str(h): {} for h in horizons}
    rng = np.random.default_rng(seed)
    for b in range(n_bootstrap):
        ix = rng.integers(0, len(time), len(time))
        for horizon in horizons:
            try:
                weights = horizon_weights(time[ix], status[ix], horizon)
            except UnsupportedCensoringError as error:
                key = str(error)
                failures[str(horizon)][key] = failures[str(horizon)].get(key, 0) + 1
                continue
            for j, model in enumerate(models):
                draws[horizon, model][b] = weighted_auc_ap(
                    weights.outcome, scores[ix, j], weights.weight)["auc"]
    rows = []
    for horizon in horizons:
        for model in models:
            values = draws[horizon, model]
            valid = values[np.isfinite(values)]
            ci = np.quantile(valid, [.025, .975]) if len(valid) >= 20 else [np.nan, np.nan]
            rows.append(dict(
                cohort="External", model=model, horizon_months=horizon,
                metric="IPCW cumulative/dynamic AUC", estimate=point[horizon, model],
                lower=ci[0], upper=ci[1], n=len(time),
                events=int(np.sum((status == 1) & (time <= horizon))),
                repeat_minimum=np.nan, repeat_maximum=np.nan,
                valid_bootstrap=len(valid), requested_bootstrap=n_bootstrap,
                interval_type="95% participant percentile bootstrap",
                score_source="Locked full-development model; revised external patients",
                interpretation="Binary score ranking only; not horizon-specific risk prediction"))
    return rows, diagnostics, failures


def development_auc(time, status, oof, models, horizons):
    rows, diagnostics = [], []
    for horizon in horizons:
        weights = horizon_weights(time, status, horizon)
        diagnostics.append(dict(cohort="Development", horizon_months=horizon,
                                **weights.diagnostics))
        for repeat, part in oof.groupby("repeat", sort=True):
            part = part.sort_values("row_index")
            for model in models:
                auc = weighted_auc_ap(weights.outcome, part[model], weights.weight)["auc"]
                rows.append(dict(cohort="Development", model=model, repeat=int(repeat),
                                 horizon_months=horizon, estimate=auc))
    details = pd.DataFrame(rows)
    summary = []
    for (model, horizon), part in details.groupby(["model", "horizon_months"], sort=False):
        summary.append(dict(
            cohort="Development", model=model, horizon_months=horizon,
            metric="Mean repeated OOF IPCW cumulative/dynamic AUC",
            estimate=part["estimate"].mean(), lower=np.nan, upper=np.nan,
            n=len(time), events=int(np.sum((status == 1) & (time <= horizon))),
            repeat_minimum=part["estimate"].min(), repeat_maximum=part["estimate"].max(),
            valid_bootstrap=0, requested_bootstrap=0,
            interval_type="Repeat minimum/maximum is descriptive, not a confidence interval",
            score_source="Conditional-family outer OOF scores; AUC evaluated separately in each repeat",
            interpretation="Exploratory selected-family performance; selection optimism remains"))
    return summary, details, diagnostics


def aj_summary(time, status, cohort, stratum, horizons, cap, n_bootstrap, seed):
    """AJ curves with pointwise percentile bands and explicit censoring support.

    Bootstrap samples are drawn within the fixed stratum. Curves use a common
    grid of observed event times and integer months. Censoring exactly at the
    horizon occurs after clinical-event evaluation. Bands are pointwise and do
    not account for selection of the model or the score cut points.
    """
    aj = aalen_johansen(time, status)
    grid = np.unique(np.r_[0., np.arange(0, cap + 1, 1), time[status != 0], horizons])
    grid = grid[grid <= cap]
    estimates = step_at(aj.time, aj.cif_vte, grid)
    death_estimates = step_at(aj.time, aj.cif_death, grid)
    support = censoring_km(time, status).at(grid, side="left") > 0
    estimates[~support] = np.nan
    death_estimates[~support] = np.nan
    draws = np.full((n_bootstrap, len(grid)), np.nan)
    rng = np.random.default_rng(seed)
    for b in range(n_bootstrap):
        ix = rng.integers(0, len(time), len(time))
        draw_aj = aalen_johansen(time[ix], status[ix])
        draw_support = censoring_km(time[ix], status[ix]).at(grid, side="left") > 0
        draws[b] = step_at(draw_aj.time, draw_aj.cif_vte, grid)
        draws[b, ~draw_support] = np.nan
    valid = np.isfinite(draws).sum(axis=0)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        limits = np.nanquantile(draws, [.025, .975], axis=0)
    event_count = np.array([np.sum((status == 1) & (time <= h)) for h in grid])
    # With no observed events a nonparametric bootstrap interval is degenerate.
    # Suppress it instead of presenting a zero upper confidence limit.
    no_information = (event_count == 0) & (grid > 0)
    limits[:, no_information | (valid < 20) | ~support] = np.nan
    curve_rows, horizon_rows = [], []
    for j, h in enumerate(grid):
        curve_rows.append(dict(
            cohort=cohort, stratum=stratum, month=h,
            cif_vte=estimates[j], lower=limits[0, j], upper=limits[1, j],
            cif_death=death_estimates[j], n=len(time),
            vte_by_month=event_count[j],
            death_by_month=int(np.sum((status == 2) & (time <= h))),
            n_at_risk=int(np.sum(time >= h)),
            valid_bootstrap=valid[j], requested_bootstrap=n_bootstrap,
            censoring_supported=bool(support[j]),
            interval_method="Pointwise participant percentile bootstrap within fixed stratum"))
    for h in horizons:
        j = int(np.flatnonzero(grid == h)[0])
        try:
            weights = horizon_weights(time, status, h)
            censoring_status = "Supported"
            ess = weights.diagnostics["effective_sample_size"]
        except UnsupportedCensoringError as error:
            censoring_status, ess = str(error), np.nan
        horizon_rows.append(dict(
            cohort=cohort, stratum=stratum, horizon_months=h, n=len(time),
            events=int(event_count[j]),
            competing_deaths=int(np.sum((status == 2) & (time <= h))),
            censored_before_horizon=int(np.sum((status == 0) & (time < h))),
            n_at_risk=int(np.sum(time >= h)), estimate=estimates[j],
            lower=limits[0, j], upper=limits[1, j],
            valid_bootstrap=valid[j], requested_bootstrap=n_bootstrap,
            effective_sample_size=ess, status=censoring_status,
            interval_status=("No VTE: degenerate bootstrap interval suppressed" if event_count[j] == 0
                             else "Sparse events: percentile interval may be unstable" if event_count[j] < 10
                             else "Pointwise 95% percentile interval")))
    risk_rows = [dict(cohort=cohort, stratum=stratum, month=float(h),
                      n_at_risk=int(np.sum(time >= h)), n=len(time))
                 for h in [0, 12, 24, 36, 48, 60] if h <= cap]
    return curve_rows, horizon_rows, risk_rows


def independent_numerical_checks(frame, predictions, charter, tables):
    """Check external estimates against separate numerical implementations."""
    from sklearn.metrics import roc_auc_score

    time = frame["fu_months"].to_numpy(float)
    status = np.where(frame["Type"] == 1, 1, np.where(frame["death"] == 1, 2, 0))
    results = tables["time_auc_sensitivity.csv"]
    aj_results = tables["aj_horizon_summary.csv"]
    group = np.searchsorted(charter["score_cuts"], predictions[charter["preferred_family"]], side="left")
    checks = {}
    for h in charter["horizons"]:
        weights = horizon_weights(time, status, h)
        for model in charter["top5_models"]:
            independent = roc_auc_score(weights.outcome, predictions[model], sample_weight=weights.weight)
            match = (results["cohort"] == "External") & (results["model"] == model) & (results["horizon_months"] == h)
            reported = results.loc[match, "estimate"].item()
            checks[f"weighted_sklearn_auc_{model}_{h}"] = bool(np.isclose(independent, reported, atol=1e-12))
        for name, mask in [("All", np.ones(len(frame), bool)), ("Lower score", group == 0),
                           ("Middle score", group == 1), ("Higher score", group == 2)]:
            tt, ss = time[mask], status[mask]
            survival, cif = 1., 0.
            for tau in sorted(np.unique(tt[(tt <= h) & (ss != 0)])):
                risk = np.sum(tt >= tau)
                recurrence = np.sum((tt == tau) & (ss == 1))
                deaths = np.sum((tt == tau) & (ss == 2))
                cif += survival * recurrence / risk
                survival *= 1. - (recurrence + deaths) / risk
            match = (aj_results["cohort"] == "External") & (aj_results["stratum"] == name) & (aj_results["horizon_months"] == h)
            row = aj_results.loc[match].iloc[0]
            checks[f"independent_aj_{name}_{h}"] = bool(np.isclose(cif, row["estimate"], atol=1e-12))
            checks[f"uncapped_at_risk_{name}_{h}"] = bool(np.sum(tt >= h) == row["n_at_risk"])
    for (cohort, stratum), part in tables["aj_curves.csv"].groupby(["cohort", "stratum"]):
        checks[f"curve_monotone_{cohort}_{stratum}"] = bool(np.all(np.diff(part["cif_vte"].dropna()) >= -1e-12))
        checks[f"curve_horizon_{cohort}_{stratum}"] = bool(part["month"].max() == 60 and part["month"].min() == 0)
        valid = part["lower"].notna() & part["upper"].notna()
        checks[f"curve_ordered_intervals_{cohort}_{stratum}"] = bool(np.all(part.loc[valid, "lower"] <= part.loc[valid, "upper"]))
    if not all(checks.values()):
        raise ArithmeticError("Independent time-analysis numerical checks failed")
    return dict(status="passed", checks_count=len(checks), checks=checks,
                method="External weighted AUC checked against scikit-learn; AJ rederived from independent scalar event-time risk-set calculation on uncapped raw times; risk counts direct raw counts; curve checks")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--auc-bootstrap", type=int, default=1000)
    parser.add_argument("--aj-bootstrap", type=int, default=1000)
    parser.add_argument("--stratum-bootstrap", type=int, default=500)
    args = parser.parse_args()
    if min(args.auc_bootstrap, args.aj_bootstrap, args.stratum_bootstrap) < 100:
        parser.error("At least 100 bootstrap replicates are required")
    root = args.root.resolve()
    charter_path = root / "config/evaluation_charter.json"
    charter = json.loads(charter_path.read_text(encoding="utf-8"))
    data_dir = (root / charter["data_directory"]).resolve()
    paths = {"Development": data_dir / charter["development_file"],
             "External": data_dir / charter["external_file"]}
    original_hashes = {k: sha256(path) for k, path in paths.items()}
    for cohort, path in paths.items():
        if original_hashes[cohort] != charter["raw_sha256"][path.name]:
            raise ValueError(f"Raw {cohort} source has changed since the charter was frozen")
    frames = {cohort: pd.read_csv(path, sep="\t") for cohort, path in paths.items()}
    horizons = [float(x) for x in charter["horizons"]]
    cap = float(charter["administrative_censor_month"])
    if max(horizons) > cap:
        raise ValueError("Evaluation horizons must not exceed the administrative cap")
    models, seed = charter["top5_models"], int(charter["seed"])
    cuts = np.asarray(charter["score_cuts"], float)
    if cuts.shape != (2,) or not np.all(np.diff(cuts) > 0):
        raise ValueError("Three descriptive score strata require two increasing locked cuts")
    external_path = root / "results/external_predictions_private.csv"
    oof_path = root / "results/development_oof_private.csv"
    external = pd.read_csv(external_path)
    oof = pd.read_csv(oof_path)
    validate_predictions(frames["External"], external, models)
    if sorted(oof["repeat"].unique()) != [1, 2, 3]:
        raise ValueError("Expected the original three repeats of development OOF predictions")
    for _, part in oof.groupby("repeat", sort=True):
        validate_predictions(frames["Development"], part.sort_values("row_index"), models)
    endpoint, audit_cohorts = {}, {}
    for cohort, frame in frames.items():
        raw_time, raw_status, time, status = derive_endpoint(frame, cap)
        endpoint[cohort] = (time, status)
        for h in horizons:
            original_aj = aalen_johansen(raw_time, raw_status).at(h)
            derived_aj = aalen_johansen(time, status).at(h)
            if not np.isclose(original_aj["cif_vte"], derived_aj["cif_vte"], atol=1e-12):
                raise ArithmeticError("Administrative censoring changed pre-horizon incidence")
            raw_w = horizon_weights(raw_time, raw_status, h)
            new_w = horizon_weights(time, status, h)
            if not np.allclose(raw_w.weight, new_w.weight, atol=1e-12):
                raise ArithmeticError("Administrative censoring changed pre-horizon weights")
        audit_cohorts[cohort] = dict(
            n=len(frame), recorded_recurrences=int(frame["Type"].sum()),
            observed_time_max=float(raw_time.max()), records_beyond_cap=int(np.sum(raw_time > cap)),
            recurrent_vte_by_cap=int(np.sum(status == 1)),
            competing_death_by_cap=int(np.sum(status == 2)),
            administrative_or_other_censors=int(np.sum(status == 0)),
            at_risk_at_cap=int(np.sum(time >= cap)),
            raw_and_capped_aj_ipcw_equal_at_all_horizons=True)
    summary, repeat_rows, diagnostics = development_auc(
        *endpoint["Development"], oof, models, horizons)
    ext_rows, ext_diagnostics, auc_failures = external_auc(
        *endpoint["External"], external[models].to_numpy(float), models,
        horizons, args.auc_bootstrap, seed + 7000)
    summary += ext_rows
    diagnostics += ext_diagnostics
    curves, horizon_rows, risks = [], [], []
    for offset, cohort in enumerate(["Development", "External"]):
        c, h, r = aj_summary(*endpoint[cohort], cohort, "All", horizons, cap,
                             args.aj_bootstrap, seed + 7100 + offset)
        curves += c
        horizon_rows += h
        risks += r
    group = np.searchsorted(cuts, external[charter["preferred_family"]], side="left")
    for number, name in enumerate(["Lower score", "Middle score", "Higher score"]):
        ix = group == number
        if not ix.any():
            raise ValueError(f"No external participants in the fixed {name} stratum")
        time, status = endpoint["External"]
        c, h, r = aj_summary(time[ix], status[ix], "External", name, horizons, cap,
                             args.stratum_bootstrap, seed + 7200 + number)
        curves += c
        horizon_rows += h
        risks += r
    out = root / "tables/supplement"
    out.mkdir(parents=True, exist_ok=True)
    tables = {
        "time_auc_sensitivity.csv": pd.DataFrame(summary),
        "time_auc_development_repeats.csv": repeat_rows,
        "time_diagnostics.csv": pd.DataFrame(diagnostics),
        "aj_curves.csv": pd.DataFrame(curves),
        "aj_horizon_summary.csv": pd.DataFrame(horizon_rows),
        "aj_at_risk.csv": pd.DataFrame(risks),
    }
    for name, frame in tables.items():
        frame.to_csv(out / name, index=False, float_format="%.17g")
    if original_hashes != {k: sha256(path) for k, path in paths.items()}:
        raise RuntimeError("Raw sources changed during the analysis")
    audit = dict(
        status="passed", completed_utc=datetime.now(timezone.utc).isoformat(),
        source_hashes=original_hashes, charter_sha256=sha256(charter_path),
        external_predictions_sha256=sha256(external_path),
        development_oof_sha256=sha256(oof_path),
        analysis_script_sha256=sha256(Path(__file__)),
        metric_library_sha256=sha256(root / "code/survival_metrics.py"),
        cohorts=audit_cohorts, horizons=horizons, administrative_censor_month=cap,
        score_cutpoints=cuts.tolist(), score_cut_source=charter["score_cut_source"],
        bootstrap=dict(auc=args.auc_bootstrap, overall_aj=args.aj_bootstrap,
                       stratum_aj=args.stratum_bootstrap, seed=seed,
                       auc_unsupported_samples=auc_failures),
        methods={
            "primary_score_target": charter["primary_target"],
            "time_sensitivity": "Binary score ranking only; no horizon probability interpretation",
            "auc": "IPCW cumulative/dynamic AUC; cases recurrent VTE by horizon; controls competing death by horizon or event-free through horizon",
            "death_order": "Type=1 takes precedence; recorded death after recurrence is not a competing first event",
            "ties": "Clinical events before censoring at the same time; censoring exactly at horizon remains known event-free",
            "censoring": "Marginal reverse Kaplan-Meier within evaluation cohort and reestimated in every bootstrap sample; independent censoring assumed",
            "development": "AUC separately evaluated in each repeat then averaged; repeat range is not a confidence interval; model-family selection optimism remains",
            "external_interval": "Percentile participant bootstrap, fixed fitted predictions, excludes fitting and model-selection uncertainty",
            "aj": "Aalen-Johansen cumulative incidence; death before recurrence is a competing event; pointwise percentile bootstrap, no simultaneous-band claim",
            "groups": "Fixed development OOF score tertile cutpoints transferred unchanged; grouping is descriptive, not a fixed-horizon treatment threshold",
            "sparse_aj": "Zero-event bootstrap intervals suppressed; fewer than ten events flagged; unsupported censoring tails suppressed",
            "raw_preservation": "Source Type and fu_months preserved; only derived endpoint administratively censored at 60 months",
        },
        output_rows={name: len(frame) for name, frame in tables.items()},
        output_sha256={name: sha256(out / name) for name in tables},
    )
    audit_dir = root / "audit"
    audit_dir.mkdir(exist_ok=True)
    independent = independent_numerical_checks(frames["External"], external, charter, tables)
    (audit_dir / "time_sensitivity_independent.json").write_text(json.dumps(independent, indent=2) + "\n", encoding="utf-8")
    (audit_dir / "time_sensitivity.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(status="passed", output_rows=audit["output_rows"], cohorts=audit_cohorts), indent=2))


if __name__ == "__main__":
    main()
