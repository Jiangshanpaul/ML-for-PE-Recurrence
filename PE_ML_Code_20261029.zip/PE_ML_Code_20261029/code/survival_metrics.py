"""Competing-risk evaluation kernels for FIRST recurrent VTE before death.

Status: 0 right censoring, 1 first VTE, 2 death before first VTE. Time must be
positive, exact elapsed months from the same prediction origin to that status.
No model is fitted here. Aalen-Johansen and reverse KM are empirical evaluation
estimators. The submitted time analysis evaluates locked binary scores for discrimination only.

Horizon cases are VTE by h; controls include death by h AND event-free through h.
Evaluation is after clinical events at h but before censoring at h: censoring
EXACTLY at h remains known event-free. Events use 1/G(T-); event-free through h
uses 1/G(h-). Censoring strictly before h has zero contribution. G is reestimated
in each evaluation bootstrap sample, not
passed to a prediction model. Independent censoring (possibly conditional in a
future extended estimator) is required. No left truncation or interval censoring.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


class UnsupportedCensoringError(ValueError):
    """A required inverse censoring probability has no positive support."""


def _data(time, status):
    time = np.asarray(time, dtype=float)
    status_raw = np.asarray(status)
    if time.ndim != 1 or status_raw.ndim != 1 or len(time) != len(status_raw) or not len(time):
        raise ValueError("time and status must be nonempty aligned one-dimensional arrays")
    if not np.isfinite(time).all() or (time <= 0).any():
        raise ValueError("Exact elapsed times must be finite and strictly positive; do not impute time zero")
    if not np.isin(status_raw, [0, 1, 2]).all():
        raise ValueError("status must be 0=censor, 1=first VTE, 2=death before VTE")
    return time, status_raw.astype(int)


def _horizon(horizon):
    h = float(horizon)
    if not np.isfinite(h) or h <= 0:
        raise ValueError("horizon must be finite positive months")
    return h




def _event_table(time, status):
    time, status = _data(time, status)
    knots, index, total = np.unique(time, return_inverse=True, return_counts=True)
    d1 = np.bincount(index, weights=(status == 1), minlength=len(knots)).astype(int)
    d2 = np.bincount(index, weights=(status == 2), minlength=len(knots)).astype(int)
    dc = total - d1 - d2
    risk = len(time) - np.r_[0, np.cumsum(total[:-1])]
    return knots, risk, d1, d2, dc


def step_at(knots, values, query, *, side="right", initial=0.0):
    """Right-continuous value at t, or left limit with side='left'."""
    knots, values = np.asarray(knots, float), np.asarray(values, float)
    q = np.asarray(query, float)
    if side not in ["right", "left"]:
        raise ValueError("side must be right or left")
    if knots.ndim != 1 or values.shape != knots.shape or (np.diff(knots) <= 0).any():
        raise ValueError("Step function needs strictly increasing aligned knots")
    ix = np.searchsorted(knots, q, side=side) - 1
    out = np.full(q.shape, initial, dtype=float)
    ok = ix >= 0
    out[ok] = values[ix[ok]]
    return float(out) if q.ndim == 0 else out


@dataclass(frozen=True)
class AalenJohansen:
    time: np.ndarray
    at_risk: np.ndarray
    vte_events: np.ndarray
    death_events: np.ndarray
    censored: np.ndarray
    event_free: np.ndarray
    cif_vte: np.ndarray
    cif_death: np.ndarray
    n: int

    def at(self, horizon, *, side="right"):
        h = _horizon(horizon)
        return {"horizon": h,
                "cif_vte": step_at(self.time, self.cif_vte, h, side=side),
                "cif_death": step_at(self.time, self.cif_death, h, side=side),
                "event_free": step_at(self.time, self.event_free, h, side=side, initial=1.0)}


def aalen_johansen(time, status):
    """Empirical two-cause CIF; all tied event increments use the SAME S(t-)."""
    time, status = _data(time, status)
    knots, risk, d1, d2, dc = _event_table(time, status)
    survival, f1, f2 = 1.0, 0.0, 0.0
    s_values, f1_values, f2_values = [], [], []
    for y, one, two in zip(risk, d1, d2):
        before = survival
        f1 += before * one / y
        f2 += before * two / y
        survival = before * (1 - (one + two) / y)
        s_values.append(survival)
        f1_values.append(f1)
        f2_values.append(f2)
    result = AalenJohansen(knots, risk, d1, d2, dc, np.asarray(s_values),
                          np.asarray(f1_values), np.asarray(f2_values), len(time))
    if not np.allclose(result.event_free + result.cif_vte + result.cif_death, 1, atol=1e-12):
        raise ArithmeticError("Aalen-Johansen state probabilities do not conserve mass")
    return result


@dataclass(frozen=True)
class CensoringKM:
    time: np.ndarray
    survival: np.ndarray
    at_risk: np.ndarray
    censoring_risk: np.ndarray
    censored: np.ndarray
    n: int
    tie_convention: str = "Clinical events before censoring at the same observed time"

    def at(self, query, *, side="right"):
        """G(t), or G(t-) with side='left'; scalar or vector query."""
        return step_at(self.time, self.survival, query, side=side, initial=1.0)


def censoring_km(time, status):
    """Reverse KM for censoring, with event-before-censor ordering for ties.

    At a tied time the clinical events have exited before the censoring jump,
    so the censoring hazard denominator is Y-dVTE-dDeath. This convention makes
    1/G(event-) weights compatible with AJ's risk set including everyone at t.
    Using ordinary Y for tied censoring would violate the IPCW/AJ identity.
    """
    time, status = _data(time, status)
    knots, risk, d1, d2, dc = _event_table(time, status)
    censor_risk = risk - d1 - d2
    g, values = 1.0, []
    for denominator, censor_count in zip(censor_risk, dc):
        if censor_count:
            if denominator <= 0 or censor_count > denominator:
                raise ArithmeticError("Invalid reverse-KM censoring risk set")
            g *= 1 - censor_count / denominator
        values.append(g)
    return CensoringKM(knots, np.asarray(values), risk, censor_risk, dc, len(time))


@dataclass(frozen=True)
class HorizonWeights:
    outcome: np.ndarray
    weight: np.ndarray
    case: np.ndarray
    control: np.ndarray
    unknown: np.ndarray
    horizon: float
    censoring: CensoringKM
    diagnostics: dict[str, Any]


def horizon_weights(time, status, horizon, *, censoring=None, minimum_g=0.0):
    """IPCW for CIF target with competing events included as known controls.

    Evaluate after clinical events at h, before censoring at h. A record with
    status=0 and time=h is known event-free through the horizon and has weight
    1/G(h-), as do records with time>h. Censors strictly before h are unknown.

    minimum_g=0 rejects only nonpositive support. A larger threshold may be
    specified as an analysis-support rule; weights are NEVER capped.
    Optional censoring must be an explicitly estimated CensoringKM object. The
    default estimates it in this evaluation cohort (not in development data).
    """
    time, status = _data(time, status)
    h = _horizon(horizon)
    if minimum_g < 0 or minimum_g >= 1:
        raise ValueError("minimum_g must lie in [0,1)")
    km = censoring_km(time, status) if censoring is None else censoring
    if not isinstance(km, CensoringKM):
        raise TypeError("censoring must be a CensoringKM object")
    observed_event = (time <= h) & (status != 0)
    later = time > h
    censored_at_horizon = (time == h) & (status == 0)
    known_event_free = later | censored_at_horizon
    unknown = (time < h) & (status == 0)
    case = (time <= h) & (status == 1)
    control = ((time <= h) & (status == 2)) | known_event_free
    outcome = case.astype(int)
    weight = np.zeros(len(time))
    g_event = km.at(time[observed_event], side="left")
    g_horizon = float(km.at(h, side="left"))
    required = np.r_[g_event, [g_horizon] if known_event_free.any() else []]
    if required.size and (required <= minimum_g).any():
        raise UnsupportedCensoringError("Required censoring survival is not above the declared support threshold")
    # If all remaining participants were censored, a flat AJ tail is unsupported.
    if not known_event_free.any() and g_horizon <= minimum_g and unknown.any():
        raise UnsupportedCensoringError("Horizon lies at or beyond exhausted censoring support")
    weight[observed_event] = 1 / g_event
    if known_event_free.any():
        weight[known_event_free] = 1 / g_horizon
    if not (case | control | unknown).all() or np.any(case & control):
        raise ArithmeticError("Horizon classes do not partition the cohort")
    if weight.sum() <= 0:
        raise UnsupportedCensoringError("No evaluable observations remain at this horizon")
    diagnostics = dict(n=len(time), vte_by_horizon=int(case.sum()),
        death_by_horizon=int(np.sum((time <= h) & (status == 2))),
        event_free_beyond_horizon=int(later.sum()),
        censored_at_horizon_known_event_free=int(censored_at_horizon.sum()),
        known_event_free_through_horizon=int(known_event_free.sum()),
        censored_before_horizon=int(unknown.sum()),
        at_risk_at_horizon=int(np.sum(time >= h)), g_horizon_left=g_horizon,
        g_horizon=g_horizon,
        g_horizon_after_censoring=float(km.at(h)),
        minimum_required_g=float(required.min()) if required.size else np.nan,
        maximum_weight=float(weight.max()), sum_weights=float(weight.sum()),
        effective_sample_size=float(weight.sum() ** 2 / np.sum(weight ** 2)),
        weighted_cases=float(weight[case].sum()), weighted_controls=float(weight[control].sum()),
        censoring_source="Evaluation cohort" if censoring is None else "Explicit supplied censoring estimator",
        tie_convention=km.tie_convention,
        evaluation_order="Clinical events at horizon, then evaluate, then censor at horizon",
        control_definition="Death before first VTE by horizon OR event-free through horizon, including censoring exactly at horizon")
    return HorizonWeights(outcome, weight, case, control, unknown, h, km, diagnostics)


def weighted_auc_ap(outcome, prediction, weight):
    """Weighted empirical AUROC and average precision, handling exact tied scores."""
    y, p, w = np.asarray(outcome, int), np.asarray(prediction, float), np.asarray(weight, float)
    if y.ndim != 1 or p.shape != y.shape or w.shape != y.shape or not len(y):
        raise ValueError("Outcome, predictions, weights must be aligned nonempty vectors")
    if not np.isin(y, [0, 1]).all() or not np.isfinite(p).all() or not np.isfinite(w).all() or (w < 0).any():
        raise ValueError("Invalid weighted binary data")
    cases, controls = float(np.sum(w * y)), float(np.sum(w * (1 - y)))
    if cases <= 0 or controls <= 0:
        return {"auc": np.nan, "average_precision": np.nan,
                "discrimination_status": "Not identifiable without both weighted cases and controls"}
    order = np.argsort(p, kind="stable")
    starts = np.r_[0, np.flatnonzero(np.diff(p[order]) != 0) + 1]
    event_weight = np.add.reduceat((w * y)[order], starts)
    control_weight = np.add.reduceat((w * (1 - y))[order], starts)
    auc = float(np.sum(event_weight * (np.cumsum(control_weight) - .5 * control_weight)) / (cases * controls))
    descending_case, descending_control = event_weight[::-1], control_weight[::-1]
    cumulative_cases = np.cumsum(descending_case)
    cumulative_total = cumulative_cases + np.cumsum(descending_control)
    precision = np.divide(cumulative_cases, cumulative_total, out=np.zeros_like(cumulative_cases), where=cumulative_total > 0)
    ap = float(np.sum(descending_case * precision) / cases)
    return {"auc": auc, "average_precision": ap, "discrimination_status": "ok"}
