"""Independent numerical verification of frozen-model validation results.

Uses scikit-learn weighted discrimination metrics and separate Newton score
solvers for calibration diagnostics. No prediction model is fitted or changed.
"""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

for setting in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
    os.environ.setdefault(setting, "1")

import joblib
import numpy as np
import pandas as pd
from scipy.special import expit, logit
from scipy.stats import norm
from sklearn.metrics import average_precision_score, roc_auc_score
import model_components

ROOT = Path(__file__).resolve().parents[1]
CHECKS = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(name, condition, detail=None):
    CHECKS.append({"check": name, "passed": bool(condition), "detail": detail})
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def close(name, actual, expected, tolerance=1e-10):
    a, b = np.asarray(actual, float), np.asarray(expected, float)
    ok = np.allclose(a, b, rtol=0, atol=tolerance, equal_nan=True)
    finite = np.isfinite(a) & np.isfinite(b)
    difference = float(np.max(np.abs(a[finite] - b[finite]))) if finite.any() else 0.
    check(name, ok, {"maximum_absolute_difference": difference, "tolerance": tolerance})


def independent_calibration(y, probability, weights):
    """Solve logistic score equations with direct Newton/IRLS iterations."""
    w = np.asarray(weights, float)
    active = w > 0
    yy, ww = np.asarray(y, float)[active], w[active]
    x = logit(np.clip(np.asarray(probability, float)[active], 1e-12, 1 - 1e-12))
    if len(np.unique(yy)) < 2:
        return np.array([np.nan, np.nan])
    intercept = 0.
    for _ in range(100):
        p = expit(x + intercept)
        score = np.dot(ww, yy - p)
        info = np.dot(ww, p * (1 - p))
        delta = score / info
        intercept += np.clip(delta, -2, 2)
        if abs(delta) < 1e-12:
            break
    design = np.column_stack((np.ones(len(x)), x))
    beta = np.array([0., 1.])
    for _ in range(100):
        p = expit(design @ beta)
        score = design.T @ (ww * (yy - p))
        info = (design.T * (ww * p * (1 - p))) @ design
        step = np.linalg.solve(info, score)
        beta += step / max(1., np.abs(step).max() / 2.)
        if np.abs(step).max() < 1e-12:
            break
    assert np.abs(design.T @ (ww * (yy - expit(design @ beta)))).max() < 1e-7
    return np.array([intercept, beta[1]])


def independent_metrics(y, probability, weights):
    n = weights.sum()
    expected = float(np.dot(weights, probability) / n)
    observed = float(np.dot(weights, y) / n)
    p = np.clip(probability, 1e-12, 1 - 1e-12)
    return {
        "auc": roc_auc_score(y, probability, sample_weight=weights),
        "average_precision": average_precision_score(y, probability, sample_weight=weights),
        "brier": float(np.average((y - probability) ** 2, weights=weights)),
        "log_loss": float(np.average(-(y * np.log(p) + (1 - y) * np.log1p(-p)), weights=weights)),
        "mean_predicted": expected, "prevalence": observed,
        "observed_expected": observed / expected,
    }


def wilson_independent(events, n):
    z = norm.isf(.025)
    denominator = n + z * z
    midpoint = (events + z * z / 2) / denominator
    error = z * np.sqrt(events * (n - events) / n + z * z / 4) / denominator
    return np.array([midpoint - error, midpoint + error])


def main():
    cfg = json.loads((ROOT / "config/evaluation_charter.json").read_text(encoding="utf-8"))
    supp = ROOT / "tables/supplement"
    data_dir = (ROOT / cfg["data_directory"]).resolve()
    external = pd.read_csv(data_dir / cfg["external_file"], sep="\t", float_precision="round_trip")
    development = pd.read_csv(data_dir / cfg["development_file"], sep="\t", float_precision="round_trip")
    models = cfg["top5_models"] + ["locked_primary", "compact_primary"]
    feature_forbidden = {"id", "Type", "death", "fu_months"}
    check("Predictor whitelist excludes identifiers, outcomes, time and prior predictions",
          not set(cfg["features"]) & feature_forbidden and not any(x.startswith("pred_") for x in cfg["features"]))
    check("Development remains161 participants47 events", (len(development), development.Type.sum()) == (161, 47))
    check("External now550 participants101 events", (len(external), external.Type.sum()) == (550, 101))
    for role in ["development", "external"]:
        filename = cfg[role + "_file"]
        check(role + " source checksum", sha(data_dir / filename) == cfg["raw_sha256"][filename])
    predictions = pd.read_csv(ROOT / "results/external_predictions_private.csv", float_precision="round_trip")
    close("Current prediction rows preserve source IDs", predictions.id, external.id)
    close("Current prediction outcomes match current source", predictions.Type, external.Type)
    y = external.Type.to_numpy(int)
    new_data = external[cfg["features"]].copy()

    reconstruction_path = ROOT / "audit/model_reconstruction.json"
    reconstruction = json.loads(reconstruction_path.read_text(encoding="utf-8")) if reconstruction_path.exists() else None
    checksum_path = ROOT / "config/development_prediction_checksums.json"
    model_checksums = json.loads(checksum_path.read_text(encoding="utf-8")) if checksum_path.exists() else None
    artifact_verification = {}
    for family in models:
        model_path = ROOT / "models" / (family + ".joblib")
        original_hash = sha(model_path) == cfg["original_model_sha256"][family]
        if original_hash:
            check(family + " frozen model hash", True)
            artifact_verification[family] = "original_frozen_artifact"
        else:
            check(family + " reconstruction receipt verified",
                  reconstruction is not None and reconstruction["status"] == "passed" and
                  reconstruction["models"][family]["sha256"] == sha(model_path) and
                  reconstruction["development_sha256"] == cfg["raw_sha256"][cfg["development_file"]] and
                  reconstruction["external_data_read"] is False and reconstruction["hyperparameter_search"] is False)
            artifact_verification[family] = "development_only_reconstruction_verified"
        model = joblib.load(model_path)
        index = int(np.flatnonzero(np.asarray(model.classes_) == 1)[0])
        if not original_hash:
            check(family + " original development checksum available", model_checksums is not None)
            development_x = development[cfg["features"]].copy()

            devp = model.predict_proba(development_x)[:, index]
            signature = hashlib.sha256(np.round(devp, 12).astype("<f8").tobytes()).hexdigest()
            check(family + " reconstructed development predictions match original checksum",
                  signature == model_checksums["models"][family])
        probability = model.predict_proba(new_data)[:, index]
        close(family + " fresh prediction vs saved current", probability, predictions[family], 1e-12)
        if family in cfg["top5_models"]:
            column = dict(zip(cfg["top5_models"], ["pred_histgb", "pred_ridge_auc", "pred_lightgbm", "pred_bagged_mlp", "pred_svm_rbf"]))[family]
            close(family + " fresh prediction vs appended source column", probability, external[column], 1e-12)
    exported = pd.read_csv(ROOT / "results/data_train_eligible_with_predictions_private.txt", sep="\t", float_precision="round_trip")
    check("Derived probability export retains full source schema", list(exported.columns) == list(external.columns))
    close("Derived probability export preserves all original columns and current probabilities", exported, external, 1e-12)

    oof = pd.read_csv(ROOT / "results/development_oof_private.csv", float_precision="round_trip")
    mean_oof = oof.groupby("row_index")[cfg["top5_models"]].mean().sort_index()
    check("Development OOF has3 complete repeats", set(oof.repeat) == {1, 2, 3} and len(oof) == 483 and len(mean_oof) == 161)
    close("Score-group cuts equal development-only mean-OOF tertiles", cfg["score_cuts"], np.quantile(mean_oof.hist_gradient_boosting, [1/3, 2/3]), 1e-12)
    for family in cfg["top5_models"]:
        close(family + " calibration cuts equal development-only mean-OOF quintiles",
              cfg["calibration_cuts"][family], np.quantile(mean_oof[family], [.2, .4, .6, .8]), 1e-12)

    perf = pd.read_csv(supp / "external_performance.csv", float_precision="round_trip")
    paired = pd.read_csv(supp / "external_paired_comparison.csv", float_precision="round_trip")
    rng = np.random.default_rng(cfg["seed"])
    n = len(y)
    counts = rng.multinomial(n, np.full(n, 1 / n), size=cfg["bootstrap_replicates"])
    all_boots, all_points = {}, {}
    for family in models:
        probability = predictions[family].to_numpy()
        point = independent_metrics(y, probability, np.ones(n, int))
        cal = independent_calibration(y, probability, np.ones(n, int))
        point.update(calibration_intercept=cal[0], calibration_slope=cal[1])
        boot = pd.DataFrame([independent_metrics(y, probability, w) for w in counts])
        bootstrap_calibration = np.array([independent_calibration(y, probability, w)
                                         for w in counts[:cfg["calibration_bootstrap_replicates"]]])
        boot["calibration_intercept"] = np.nan
        boot["calibration_slope"] = np.nan
        boot.loc[:len(bootstrap_calibration)-1, ["calibration_intercept", "calibration_slope"]] = bootstrap_calibration
        all_boots[family], all_points[family] = boot, point
        rows = perf.loc[perf.model == family].set_index("metric")
        for metric, estimate in point.items():
            tolerance = 2e-6 if metric.startswith("calibration_") else 1e-10
            close(family + " " + metric + " point", rows.loc[metric, "estimate"], estimate, tolerance)
            finite = boot[metric].dropna().to_numpy()
            close(family + " " + metric + " bootstrap interval", rows.loc[metric, ["lower", "upper"]],
                  np.quantile(finite, [.025, .975]), tolerance)
            check(family + " " + metric + " bootstrap denominator", int(rows.loc[metric, "valid_bootstrap"]) == len(finite))
        print(f"Audited model {family}", flush=True)
    for row in paired.itertuples():
        a = all_boots[row.model][row.metric] - all_boots[row.comparator][row.metric]
        estimate = all_points[row.model][row.metric] - all_points[row.comparator][row.metric]
        close(f"Paired {row.model}-{row.comparator} {row.metric}", [row.estimate, row.lower, row.upper],
              [estimate, *np.quantile(a, [.025, .975])])

    grouped = pd.read_csv(supp / "external_calibration.csv", float_precision="round_trip")
    for family in cfg["top5_models"]:
        p = predictions[family].to_numpy()
        labels = np.searchsorted(cfg["calibration_cuts"][family], p, side="left") + 1
        for row in grouped.loc[grouped.model == family].itertuples():
            mask = labels == row.group
            check(f"{family} calibration group{row.group} counts", (row.n, row.events) == (mask.sum(), y[mask].sum()))
            close(f"{family} calibration group{row.group} means and WilsonCI", [row.mean_predicted, row.observed, row.lower, row.upper],
                  [p[mask].mean(), y[mask].mean(), *wilson_independent(y[mask].sum(), mask.sum())])
    group_table = pd.read_csv(supp / "histgb_score_groups.csv", float_precision="round_trip")
    histgb = predictions.hist_gradient_boosting.to_numpy()
    labels = np.searchsorted(cfg["score_cuts"], histgb, side="left") + 1
    group_rates = []
    for row in group_table.itertuples():
        mask = labels == row.group
        check(f"HistGB score group{row.group} counts", (row.n, row.events) == (mask.sum(), y[mask].sum()))
        close(f"HistGB score group{row.group} point andWilsonCI", [row.observed, row.lower, row.upper],
              [y[mask].mean(), *wilson_independent(y[mask].sum(), mask.sum())])
        group_rates.append((counts[:, mask] @ y[mask]) / counts[:, mask].sum(axis=1))
    contrasts = pd.read_csv(supp / "histgb_group_contrasts.csv", float_precision="round_trip").set_index("metric")
    rd = group_rates[2] - group_rates[0]
    close("HistGB high-low recorded-recurrence difference CI", contrasts.loc["risk_difference_high_minus_low", ["lower", "upper"]], np.quantile(rd, [.025, .975]))
    rr = np.divide(group_rates[2], group_rates[0], out=np.full(len(counts), np.inf), where=group_rates[0] > 0)
    ratio_row = contrasts.loc["risk_ratio_high_over_low"]
    correct_rr_interval = np.quantile(rr, [.025, .975])
    rr_ci_correct = bool(np.allclose(ratio_row[["lower", "upper"]].to_numpy(float), correct_rr_interval, atol=1e-10, rtol=0))

    decisions = pd.read_csv(supp / "external_decision_curve.csv", float_precision="round_trip")
    for row in decisions.itertuples():
        p = np.ones(n) if row.model == "treat_all" else np.zeros(n) if row.model == "treat_none" else predictions[row.model].to_numpy()
        contribution = (p >= row.threshold) * (y - (1 - y) * row.threshold / (1 - row.threshold))
        close(f"DCA {row.model} at{row.threshold:.2f}", [row.net_benefit, row.lower, row.upper],
              [contribution.mean(), *np.quantile(counts @ contribution / n, [.025, .975])])
    subgroup = pd.read_csv(supp / "histgb_subgroups.csv", float_precision="round_trip")
    for variable, cut, names in [("gender", 1, ["Female", "Male"]), ("age", 65, ["Age <65", "Age >=65"]),
                                  ("bmi", 25, ["BMI <25", "BMI >=25"]), ("hypertension", 0, ["No hypertension", "Hypertension"]),
                                  ("diabetes", 0, ["No diabetes", "Diabetes"])]:
        mask = external[variable].eq(cut).to_numpy() if variable in ["gender", "hypertension", "diabetes"] else external[variable].lt(cut).to_numpy()
        for name, part in zip(names, [mask, ~mask]):
            yy, pp = y[part], histgb[part]
            nn = len(yy)
            wc = rng.multinomial(nn, np.full(nn, 1 / nn), size=cfg["subgroup_bootstrap_replicates"])
            rows = subgroup.loc[(subgroup.variable == variable) & (subgroup.group == name)].set_index("metric")
            auc = roc_auc_score(yy, pp)
            brier = np.mean((yy - pp) ** 2)
            auc_draws = np.array([roc_auc_score(yy, pp, sample_weight=w)
                                  if 0 < np.dot(w, yy) < nn else np.nan for w in wc])
            brier_draws = (wc @ ((yy - pp) ** 2)) / nn
            close(f"Subgroup {name} AUC", rows.loc["auc", ["estimate", "lower", "upper"]], [auc, *np.nanquantile(auc_draws, [.025, .975])])
            check(f"Subgroup {name} AUC valid bootstrap", rows.loc["auc", "valid_bootstrap"] == np.isfinite(auc_draws).sum())
            close(f"Subgroup {name} Brier", rows.loc["brier", ["estimate", "lower", "upper"]], [brier, *np.quantile(brier_draws, [.025, .975])])
            check(f"Subgroup {name} denominators", bool((rows.n == nn).all() and (rows.events == yy.sum()).all()))

    code = (ROOT / "code/evaluate_models.py").read_text(encoding="utf-8")
    check("Evaluation code contains no prediction-estimator fitting", ".fit(" not in code)
    check("Evaluation code contains no resampling or parameter search", all(word not in code for word in ["SMOTE", "GridSearchCV", "RandomizedSearchCV"]))
    check("Sparse ratio interval retains infinite resamples", rr_ci_correct)
    report = {"status": "passed" if rr_ci_correct else "passed_core_metrics_with_ratio_interval_correction_needed",
              "created_utc": datetime.now(timezone.utc).isoformat(), "independent_checks": len(CHECKS),
              "passed_checks": sum(c["passed"] for c in CHECKS), "failed_checks": sum(not c["passed"] for c in CHECKS),
              "methods": "Independent weighted sklearn ROC/AP, direct weighted losses, Newton/IRLS calibration score equations, Wilson algebra, same documented participant bootstrap draws; no prediction-model fitting.",
              "source_hashes": {name: sha(data_dir / name) for name in cfg["raw_sha256"]},
              "analysis_population": "Final eligible development and external cohorts only",
              "model_artifact_verification": artifact_verification,
              "script_sha256": sha(__file__), "evaluation_script_sha256": sha(ROOT / "code/evaluate_models.py"),
              "charter_sha256": sha(ROOT / "config/evaluation_charter.json"),
              "risk_ratio_review": {"infinite_resamples": int(np.isinf(rr).sum()), "total_resamples": len(rr),
                                    "correct_percentile_lower": float(correct_rr_interval[0]), "correct_percentile_upper": float(correct_rr_interval[1]),
                                    "reported_interval_matches_full_distribution": rr_ci_correct},
              "checks": CHECKS}
    (ROOT / "audit/independent_revision_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ["status", "independent_checks", "passed_checks", "risk_ratio_review"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
