"""Binary performance and calibration kernels for fixed-model evaluation."""
import warnings
import numpy as np
from scipy.optimize import brentq, minimize
from scipy.special import expit, logit
from scipy.stats import norm
EPS=1e-12

def wilson(events, n):
    if n <= 0:
        return np.nan, np.nan
    z = norm.ppf(.975)
    p = events / n
    denominator = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denominator
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return float(centre - half), float(centre + half)


def logistic_diagnostic_fit(design, y, weights=None):
    """Unpenalized diagnostic likelihood, observed Hessian, explicit failure flags."""
    x = np.asarray(design, float)
    y = np.asarray(y, float)
    w = np.ones(len(y)) if weights is None else np.asarray(weights, float)
    keep = w > 0
    x, y, w = x[keep], y[keep], w[keep]
    if len(np.unique(y)) < 2:
        return None, None, "single_outcome_class"
    if np.linalg.matrix_rank(x) != x.shape[1]:
        return None, None, "rank_deficient_design"
    total = w.sum()

    def objective(beta):
        eta = x @ beta
        return float(np.sum(w * (np.logaddexp(0, eta) - y * eta)) / total)

    def gradient(beta):
        return x.T @ (w * (expit(x @ beta) - y)) / total

    def hessian(beta):
        prob = expit(x @ beta)
        return (x.T * (w * prob * (1 - prob))) @ x / total

    with warnings.catch_warnings(record=True):
        fit = minimize(objective, np.zeros(x.shape[1]), jac=gradient, hess=hessian,
                       method="trust-exact", options={"gtol": 1e-9, "maxiter": 200})
    if not np.isfinite(fit.x).all():
        return None, None, "nonfinite_coefficients"
    if np.max(np.abs(gradient(fit.x))) > 1e-7:
        return None, None, "nonconverged_score"
    information = hessian(fit.x) * total
    eigenvalues = np.linalg.eigvalsh(information)
    if eigenvalues.min() < 1e-7 or eigenvalues.max() / eigenvalues.min() > 1e10 or np.max(np.abs(fit.x)) > 40:
        return None, None, "separation_or_ill_conditioned_information"
    covariance = np.linalg.inv(information)
    status = "ok" if fit.success else "stationary_score_verified_despite_optimizer_message"
    return fit.x, covariance, status


def calibration(y, p, weights=None):
    y, p = np.asarray(y, int), np.asarray(p, float)
    w = np.ones(len(y)) if weights is None else np.asarray(weights, float)
    keep = w > 0
    y, p, w = y[keep], p[keep], w[keep]
    if len(np.unique(y)) < 2:
        return np.nan, np.nan, "single_outcome_class"
    if np.all((p == 0) | (p == 1)) and np.array_equal(p, y):
        return np.nan, np.nan, "perfect_boundary_predictions_calibration_not_identifiable"
    x = logit(np.clip(p, EPS, 1 - EPS))
    intercept = float(brentq(lambda a: np.sum(w * (y - expit(x + a))), -100, 100))
    scale = float(np.sqrt(np.average((x - np.average(x, weights=w)) ** 2, weights=w)))
    if scale < 1e-10:
        return intercept, np.nan, "constant_predictions_slope_not_identifiable"
    if x[y == 0].max() <= x[y == 1].min() or x[y == 1].max() <= x[y == 0].min():
        return intercept, np.nan, "separated_calibration_slope_not_identifiable"
    z = (x - np.average(x, weights=w)) / scale
    coefficients, _, status = logistic_diagnostic_fit(np.column_stack([np.ones(len(z)), z]), y, w)
    slope = np.nan if coefficients is None else float(coefficients[1] / scale)
    return intercept, slope, status


def bootstrap_metrics(y, p, counts):
    """Exact weighted AUROC/AP with ties; other metrics are patient contributions."""
    y, p = np.asarray(y, int), np.asarray(p, float)
    n = counts.sum(axis=1)
    order = np.argsort(p, kind="stable")
    starts = np.r_[0, np.flatnonzero(np.diff(p[order]) != 0) + 1]
    cases = np.add.reduceat((counts * y)[..., order], starts, axis=1)
    controls = np.add.reduceat((counts * (1 - y))[..., order], starts, axis=1)
    events, nonevents = cases.sum(axis=1), controls.sum(axis=1)
    denominator = events * nonevents
    auc_numerator = np.sum(cases * (np.cumsum(controls, axis=1) - .5 * controls), axis=1)
    auc = np.divide(auc_numerator, denominator, out=np.full(len(counts), np.nan), where=denominator > 0)
    descending_cases, descending_controls = cases[:, ::-1], controls[:, ::-1]
    cum_cases = np.cumsum(descending_cases, axis=1)
    cum_total = cum_cases + np.cumsum(descending_controls, axis=1)
    precision = np.divide(cum_cases, cum_total, out=np.zeros_like(cum_cases, dtype=float), where=cum_total > 0)
    ap = np.divide(np.sum(descending_cases * precision, axis=1), events,
                   out=np.full(len(counts), np.nan), where=events > 0)
    ap[denominator == 0] = np.nan
    clipped = np.clip(p, EPS, 1 - EPS)
    prediction_mean = counts @ p / n
    prevalence = events / n
    return {"auc": auc, "average_precision": ap,
            "brier": counts @ ((y - p) ** 2) / n,
            "log_loss": counts @ (-(y * np.log(clipped) + (1 - y) * np.log1p(-clipped))) / n,
            "mean_predicted": prediction_mean, "prevalence": prevalence,
            "observed_expected": np.divide(prevalence, prediction_mean,
                out=np.full(len(counts), np.nan), where=prediction_mean > 0)}


def point_metrics(y, p):
    values = {name: float(value[0]) for name, value in bootstrap_metrics(y, p, np.ones((1, len(y)), int)).items()}
    a, b, status = calibration(y, p)
    values.update(calibration_intercept=a, calibration_slope=b)
    return values, status


def interval(values):
    v = np.asarray(values, float)
    v = v[np.isfinite(v)]
    if len(v) < 20:
        return np.nan, np.nan, len(v)
    lower, upper = np.quantile(v, [.025, .975])
    return float(lower), float(upper), len(v)


def generate_counts(n, replicates, rng):
    return rng.multinomial(n, np.full(n, 1 / n), size=replicates)
