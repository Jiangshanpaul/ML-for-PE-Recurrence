"""Describe training discrimination of the seven frozen prediction models.

Predictions are evaluated in the same development participants used for fitting.
These estimates describe training fit and do not replace the separately retained
repeated nested out-of-fold evaluation. No estimator is fitted by this script.
"""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from evaluate_models import ROOT, CFG, load, save, sha
import model_components


def main():
    development, source = load('development')
    assert (len(development), int(development.Type.sum())) == (
        CFG['development_n'], CFG['development_events'])
    predictors = development.copy()

    models = CFG['top5_models'] + ['locked_primary', 'compact_primary']
    reference = pd.read_csv(ROOT / 'results/development_apparent_private.csv',
                            float_precision='round_trip')
    np.testing.assert_array_equal(reference.Type, development.Type)
    predictions = pd.DataFrame({'row_index': np.arange(len(development)),
                                'Type': development.Type.to_numpy(int)})
    rows, audit = [], {}
    for name in models:
        path = ROOT / 'models' / (name + '.joblib')
        model_hash = sha(path)
        if model_hash != CFG['original_model_sha256'][name]:
            receipt = json.loads((ROOT / 'audit/model_reconstruction.json').read_text())
            assert receipt['status'] == 'passed'
            assert receipt['models'][name]['sha256'] == model_hash
        estimator = joblib.load(path)
        positive = np.flatnonzero(np.asarray(estimator.classes_) == 1)
        assert len(positive) == 1
        probability = estimator.predict_proba(predictors[CFG['features']])[:, positive[0]]
        assert np.isfinite(probability).all()
        assert ((probability >= 0) & (probability <= 1)).all()
        difference = None
        if name in reference:
            difference = float(np.max(np.abs(probability - reference[name])))
            np.testing.assert_allclose(probability, reference[name], atol=1e-12, rtol=0)
        predictions[name] = probability
        rows.append(dict(model=name, metric='auc',
            estimate=float(roc_auc_score(development.Type, probability)),
            n=len(development), events=int(development.Type.sum()),
            evaluation='Training: predictions in participants used to fit the model',
            interpretation='Descriptive fit; not held-out validation or a model-selection criterion'))
        audit[name] = dict(sha256=model_hash, maximum_difference_from_original_training=difference)
    save(rows, 'tables/supplement/development_training.csv')
    save(predictions, 'results/development_training_private.csv')
    report = dict(status='passed', source_sha256=sha(source), n=len(development),
        events=int(development.Type.sum()), model_fit_performed=False,
        model_reselection=False, models=audit,
        definition='Evaluation in the original fitted development sample; separate nested OOF retained')
    (ROOT / 'audit/training_evaluation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(pd.DataFrame(rows)[['model', 'estimate', 'n', 'events']].to_string(index=False))


if __name__ == '__main__':
    main()
