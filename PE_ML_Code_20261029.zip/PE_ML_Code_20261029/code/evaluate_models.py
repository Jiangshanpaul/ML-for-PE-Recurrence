"""Evaluate previously locked models after an investigator-adjudicated exclusion.

No prediction model is fitted, retuned, selected or recalibrated here. Diagnostic
calibration estimates do not modify the predictions. Input prediction columns
are used only for reconciliation, never as predictors.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(key,'1')
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, log_loss
from binary_metrics import bootstrap_metrics, generate_counts, interval, calibration, wilson
import model_components

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'config/evaluation_charter.json').read_text(encoding='utf-8'))
NAMES={'hist_gradient_boosting':'HistGB','ridge':'AUROC-tuned ridge','lightgbm':'LightGBM',
       'bagged_mlp':'Bagged MLP','svm_rbf':'Calibrated RBF SVM',
       'locked_primary':'Original primary ridge','compact_primary':'Compact ridge'}
SOURCE_COLUMNS=dict(zip(CFG['top5_models'],['pred_histgb','pred_ridge_auc','pred_lightgbm','pred_bagged_mlp','pred_svm_rbf']))

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(rows,path):
    target=ROOT/path;target.parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(target,index=False,float_format='%.17g',encoding='utf-8-sig')
def load(role):
    path=(ROOT/CFG['data_directory']/CFG[role+'_file']).resolve()
    assert sha(path)==CFG['raw_sha256'][path.name], 'Source checksum mismatch'
    d=pd.read_csv(path,sep='\t',float_precision='round_trip')
    assert d.id.is_unique and d.age.ge(18).all()
    assert set(d.Type.unique())=={0,1} and set(d.death.unique()).issubset({0,1})
    assert d.fu_months.gt(0).all() and np.isfinite(d[CFG['features']].to_numpy(float)).all()
    assert not any(c.startswith('pred_') for c in CFG['features'])
    assert not set(CFG['features']) & {'id','Type','death','fu_months'}
    for c in CFG['categorical']:
        assert set(d[c].unique()).issubset({1,2} if c=='gender' else {0,1})
    return d,path

def main():
    dev,devpath=load('development');ext,extpath=load('external')
    assert (len(dev),int(dev.Type.sum()))==(CFG['development_n'],CFG['development_events'])
    assert (len(ext),int(ext.Type.sum()))==(CFG['external_n'],CFG['external_events'])
    input_hash=sha(extpath)
    fitdata=ext.copy()
    y=ext.Type.to_numpy(int);n=len(y);events=int(y.sum())
    models=CFG['top5_models']+['locked_primary','compact_primary']
    model_audit={};prob={}
    for model in models:
        path=ROOT/'models'/f'{model}.joblib'
        # Original fitted objects or a separately verified development-only reconstruction.
        reconstruction=ROOT/'audit/model_reconstruction.json'
        expected=CFG['original_model_sha256'][model]
        if sha(path)!=expected:
            assert reconstruction.exists(), 'Unrecognized fitted model artifact'
            receipt=json.loads(reconstruction.read_text())
            assert receipt['status']=='passed' and receipt['models'][model]['sha256']==sha(path)
        estimator=joblib.load(path)
        positive=np.flatnonzero(np.asarray(estimator.classes_)==1);assert len(positive)==1
        prob[model]=estimator.predict_proba(fitdata[CFG['features']])[:,positive[0]]
        assert np.isfinite(prob[model]).all() and ((prob[model]>=0)&(prob[model]<=1)).all()
        difference=None
        if model in SOURCE_COLUMNS and SOURCE_COLUMNS[model] in ext:
            difference=float(np.max(np.abs(prob[model]-ext[SOURCE_COLUMNS[model]].to_numpy())))
            np.testing.assert_allclose(prob[model],ext[SOURCE_COLUMNS[model]],atol=1e-12,rtol=0)
        model_audit[model]=dict(sha256=sha(path),maximum_difference_from_supplied_probability=difference)
    save(pd.DataFrame({'row_index':np.arange(n),'id':ext.id,'Type':y,**prob}),'results/external_predictions_private.csv')
    # Preserve the investigator's source and refresh only the derived copy's prediction columns.
    lines=extpath.read_bytes().splitlines(keepends=True)
    header=lines[0].decode('utf-8-sig').rstrip('\r\n').split('\t')
    retained_positions=[j for j,c in enumerate(header) if c not in SOURCE_COLUMNS.values()]
    output=[]
    for i,line in enumerate(lines):
        body=line.rstrip(b'\r\n');ending=line[len(body):]
        parts=body.split(b'\t')
        suffix=list(SOURCE_COLUMNS.values()) if i==0 else [format(prob[m][i-1],'.17g') for m in CFG['top5_models']]
        output.append(b'\t'.join([parts[j] for j in retained_positions]+[s.encode('ascii') for s in suffix])+ending)
    prediction_file=ROOT/'results/data_train_eligible_with_predictions_private.txt'
    prediction_file.write_bytes(b''.join(output))

    rng=np.random.default_rng(CFG['seed'])
    counts=generate_counts(n,CFG['bootstrap_replicates'],rng)
    unit=np.ones((1,n),int)
    points={m:bootstrap_metrics(y,p,unit) for m,p in prob.items()}
    boots={m:bootstrap_metrics(y,p,counts) for m,p in prob.items()}
    performance=[];paired=[];calibrations=[];decisions=[]
    for model,p in prob.items():
        for metric in ['auc','average_precision','brier','log_loss','mean_predicted','prevalence','observed_expected']:
            lo,hi,valid=interval(boots[model][metric])
            performance.append(dict(model=model,metric=metric,estimate=float(points[model][metric][0]),lower=lo,upper=hi,
                n=n,events=events,valid_bootstrap=valid,requested_bootstrap=len(counts)))
        ci,cs,status=calibration(y,p)
        draws=np.asarray([calibration(y,p,c)[:2] for c in counts[:CFG['calibration_bootstrap_replicates']]])
        for j,(metric,value) in enumerate([('calibration_intercept',ci),('calibration_slope',cs)]):
            lo,hi,valid=interval(draws[:,j])
            performance.append(dict(model=model,metric=metric,estimate=value,lower=lo,upper=hi,n=n,events=events,
                valid_bootstrap=valid,requested_bootstrap=CFG['calibration_bootstrap_replicates'],calibration_status=status))
        for comparator in ['locked_primary','compact_primary']:
            if model in CFG['top5_models']:
                for metric in ['auc','average_precision','brier','log_loss']:
                    lo,hi,valid=interval(boots[model][metric]-boots[comparator][metric])
                    paired.append(dict(model=model,comparator=comparator,metric=metric,
                        estimate=float(points[model][metric][0]-points[comparator][metric][0]),lower=lo,upper=hi,
                        valid_bootstrap=valid,n=n,events=events))
        if model in CFG['top5_models']:
            cuts=CFG['calibration_cuts'][model];group=np.digitize(p,cuts,right=True)
            for j in range(len(cuts)+1):
                ix=group==j;nn=int(ix.sum());ee=int(y[ix].sum());lo,hi=wilson(ee,nn)
                calibrations.append(dict(model=model,group=j+1,n=nn,events=ee,mean_predicted=float(p[ix].mean()) if nn else np.nan,
                    observed=ee/nn if nn else np.nan,lower=lo,upper=hi,cut_source='Original development OOF quintiles'))
        # Cross-check every basic metric against independent library functions.
        for metric,value in [('auc',roc_auc_score(y,p)),('average_precision',average_precision_score(y,p)),
                             ('brier',brier_score_loss(y,p)),('log_loss',log_loss(y,p))]:
            assert abs(value-points[model][metric][0])<1e-12
    for threshold in np.linspace(.01,.5,50):
        utility=y-(1-y)*threshold/(1-threshold)
        for model,p in {**prob,'treat_all':np.ones(n),'treat_none':np.zeros(n)}.items():
            contribution=(p>=threshold)*utility
            lo,hi,valid=interval(counts@contribution/n)
            decisions.append(dict(model=model,threshold=threshold,net_benefit=contribution.mean(),lower=lo,upper=hi,n=n,events=events))
    save(performance,'tables/supplement/external_performance.csv')
    save(paired,'tables/supplement/external_paired_comparison.csv')
    save(calibrations,'tables/supplement/external_calibration.csv')
    save(decisions,'tables/supplement/external_decision_curve.csv')

    groups=np.digitize(prob['hist_gradient_boosting'],CFG['score_cuts'],right=True)
    group_rows=[];group_draws=[]
    for group,label in enumerate(['Low','Intermediate','High']):
        ix=groups==group;nn=int(ix.sum());ee=int(y[ix].sum());lo,hi=wilson(ee,nn)
        group_rows.append(dict(group=group+1,label=label,n=nn,events=ee,observed=ee/nn,lower=lo,upper=hi,
            mean_predicted=float(prob['hist_gradient_boosting'][ix].mean()),cut_source=CFG['score_cut_source']))
        den=counts[:,ix].sum(axis=1);num=counts[:,ix]@y[ix]
        group_draws.append(np.divide(num,den,out=np.full(len(counts),np.nan),where=den>0))
    contrasts=[]
    ratio_draws=np.divide(group_draws[2],group_draws[0],out=np.full(len(counts),np.inf),where=group_draws[0]>0)
    ratio_draws[(group_draws[0]==0)&(group_draws[2]==0)]=np.nan
    for metric,estimate,draw in [
        ('risk_difference_high_minus_low',group_rows[2]['observed']-group_rows[0]['observed'],group_draws[2]-group_draws[0]),
        ('risk_ratio_high_over_low',group_rows[2]['observed']/group_rows[0]['observed'] if group_rows[0]['observed'] else np.nan,
         ratio_draws)]:
        if metric.startswith('risk_ratio'):
            estimable=draw[~np.isnan(draw)]
            lo,hi=np.quantile(estimable,[.025,.975]);valid=len(estimable)
        else:
            lo,hi,valid=interval(draw)
        contrasts.append(dict(metric=metric,estimate=estimate,lower=lo,upper=hi,valid_bootstrap=valid,
            infinite_bootstrap=int(np.isinf(draw).sum()),requested_bootstrap=len(counts),
            interpretation='Descriptive recorded-outcome contrast; unequal observation windows; not a causal effect'))
    save(group_rows,'tables/supplement/histgb_score_groups.csv');save(contrasts,'tables/supplement/histgb_group_contrasts.csv')

    subgroups=[]
    for variable,cut,labels in [('gender',1,['Female','Male']),('age',65,['Age <65','Age >=65']),
                               ('bmi',25,['BMI <25','BMI >=25']),('hypertension',0,['No hypertension','Hypertension']),
                               ('diabetes',0,['No diabetes','Diabetes'])]:
        mask=ext[variable].eq(cut).to_numpy() if variable in ['gender','hypertension','diabetes'] else ext[variable].lt(cut).to_numpy()
        for j,ix in enumerate([mask,~mask]):
            yy=y[ix];pp=prob['hist_gradient_boosting'][ix];nn=len(yy)
            sample_counts=generate_counts(nn,CFG['subgroup_bootstrap_replicates'],rng)
            est=bootstrap_metrics(yy,pp,np.ones((1,nn),int));bb=bootstrap_metrics(yy,pp,sample_counts)
            for metric in ['auc','brier']:
                lo,hi,valid=interval(bb[metric])
                subgroups.append(dict(variable=variable,group=labels[j],n=nn,events=int(yy.sum()),metric=metric,
                    estimate=float(est[metric][0]),lower=lo,upper=hi,valid_bootstrap=valid))
    save(subgroups,'tables/supplement/histgb_subgroups.csv')
    baseline=[]
    fields=CFG['features']+['Type','death','fu_months']
    for variable in fields:
        categorical=variable in CFG['categorical']+['Type','death']
        levels=([1,2] if variable=='gender' else [1]) if categorical else [None]
        for level in levels:
            row=dict(variable=variable,level=level,development_n=len(dev),external_n=n)
            for cohort,d in [('development',dev),('external',ext)]:
                s=d[variable];row[cohort+'_missing']=int(s.isna().sum())
                if categorical:
                    ee=int(s.eq(level).sum());row[cohort]=f'{ee}/{len(s)} ({100*ee/len(s):.1f}%)'
                else:
                    q=s.quantile([.25,.5,.75]);row[cohort]=f'{q.loc[.5]:.2f} [{q.loc[.25]:.2f}, {q.loc[.75]:.2f}]'
            baseline.append(row)
    save(baseline,'tables/supplement/baseline.csv')
    current=pd.DataFrame(performance)
    save([dict(cohort='Development',step='Supplied eligible cohort',n=161,events=47),
          dict(cohort='External',step='Excluded: PE/VTE before index enrolment',n=19,events=np.nan),
          dict(cohort='External',step='Final eligible cohort',n=550,events=101)],'cohort_flow.csv')
    assert sha(extpath)==input_hash
    audit=dict(status='passed',created_utc=datetime.now(timezone.utc).isoformat(),
        script_sha256=sha(__file__),charter_sha256=sha(ROOT/'config/evaluation_charter.json'),
        source_sha256={devpath.name:sha(devpath),extpath.name:sha(extpath)},models=model_audit,
        n=n,events=events,model_fit_performed=False,model_reselection=False,external_recalibration=False,
        supplied_predictions_not_used_as_features=True,analysis_population='Final eligible participants only',
        primary_target=CFG['primary_target'],exclusion_evidence=CFG['exclusion_reason'],
        bootstrap='2000 shared participant resamples; 500 calibration and1000 subgroup; conditional on fitted models',
        interval_limits='Excludes development, prior inspection and exclusion-adjudication uncertainty; exploratory comparisons',
        patient_prediction_file=str(prediction_file.relative_to(ROOT)))
    (ROOT/'audit/external_evaluation.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(current.loc[current.metric.isin(['auc','brier','calibration_intercept','calibration_slope']),
          ['model','metric','estimate','lower','upper']].to_string(index=False),flush=True)
    print(pd.DataFrame(group_rows).to_string(index=False),flush=True)

if __name__=='__main__': main()
