"""Create reproducible aggregate displays for the eligibility-corrected validation.

Models, external probabilities and analysis estimates are read without fitting or
selection. The rendering order is the original development ranking. Aggregate
coordinates omit patient identifiers and exact ROC probability thresholds.
"""
from pathlib import Path
import hashlib
import html
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve, precision_recall_curve
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
BLUE, ORANGE, GREEN, PURPLE, VIOLET = '#0072B2', '#D55E00', '#009E73', '#CC79A7', '#8064A2'
DARK, GREY, GRID = '#172F3B', '#637580', '#DDE6EA'
LABELS = {
    'hist_gradient_boosting': 'HistGB', 'ridge': 'AUC-tuned ridge',
    'lightgbm': 'LightGBM', 'bagged_mlp': 'Bagged neural network',
    'svm_rbf': 'Calibrated RBF SVM', 'locked_primary': 'Original primary ridge',
    'compact_primary': 'Compact ridge', 'elastic_net': 'Elastic-net logistic',
    'random_forest': 'Random forest', 'xgboost': 'XGBoost', 'extra_trees': 'Extra trees',
    'catboost': 'CatBoost', 'mlp': 'Neural network', 'spline_logistic': 'Spline logistic',
    'stacking': 'Stacking', 'adaptive_inner_auc_selection': 'Adaptive inner-CV selection',
    'original_logloss_procedure': 'Original log-loss procedure'}
AJ_GROUP = {'Low':'Lower score', 'Intermediate':'Middle score', 'High':'Higher score'}
VARIABLES = {'age': 'Age, years', 'gender': 'Sex', 'bmi': 'Body mass index, kg/m²',
    'pulse': 'Pulse, beats/min', 'smoking': 'Smoking', 'alcohol': 'Alcohol use',
    'hypertension': 'Hypertension', 'hyperlipidemia': 'Hyperlipidaemia',
    'diabetes': 'Diabetes', 'chronic_lung_disease': 'Chronic lung disease',
    'wbc': 'White blood cell count, 10⁹/L', 'hemoglobin': 'Haemoglobin, g/L',
    'platelete': 'Platelet count, 10⁹/L', 'alb': 'Albumin, g/L', 'cre': 'Creatinine, µmol/L',
    'glucose': 'Glucose, mmol/L', 'triglyceride': 'Triglycerides, mmol/L',
    'total_cholesterol': 'Total cholesterol, mmol/L', 'hdl': 'HDL cholesterol, mmol/L',
    'ldl': 'LDL cholesterol, mmol/L', 'Type': 'Recorded recurrent VTE',
    'death': 'Death during observed follow-up', 'fu_months': 'Observed endpoint time, months'}


def style():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
        'axes.titlesize': 9, 'axes.titleweight': 'bold', 'axes.labelsize': 8,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.edgecolor': '#8B9DA5', 'axes.labelcolor': DARK, 'text.color': DARK,
        'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5,
        'grid.color': GRID, 'grid.linewidth': .6, 'legend.frameon': False,
        'legend.fontsize': 7.2, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'figure.facecolor': 'white', 'savefig.facecolor': 'white'})


def label(key):
    return LABELS.get(key, key.replace('_', ' ').capitalize())


def metric(frame, model, key):
    rows = frame.loc[frame.model.eq(model) & frame.metric.eq(key)]
    if len(rows) != 1:
        raise ValueError(f'Expected one result for {model}/{key}, received {len(rows)}')
    return rows.iloc[0]


def ci(row, digits=3, scale=1):
    if not np.isfinite(row.estimate):
        return 'Not estimable'
    result = f'{row.estimate*scale:.{digits}f}'
    if np.isfinite(row.get('lower', np.nan) + row.get('upper', np.nan)):
        result += f' ({row.lower*scale:.{digits}f}, {row.upper*scale:.{digits}f})'
    return result


def title(ax, letter, text):
    ax.set_title(f'{letter}  {text}', loc='left', pad=10)


def point(ax, x, y, lo, hi, color=BLUE, marker='o', ms=4):
    ax.errorbar(x, y, xerr=[[max(0, x-lo)], [max(0, hi-x)]], fmt=marker,
                color=color, capsize=2.5, ms=ms, lw=1.25)


class Publication:
    def __init__(self):
        self.cfg = json.loads((ROOT/'config/evaluation_charter.json').read_text(encoding='utf-8-sig'))
        self.top5 = self.cfg['top5_models']
        assert self.top5[0] == self.cfg['preferred_family'] == 'hist_gradient_boosting'
        self.colors = dict(zip(self.top5, [BLUE, ORANGE, GREEN, PURPLE, VIOLET]))
        self.colors.update(locked_primary=DARK, compact_primary=GREY)
        self.inputs, self.outputs, self.table_outputs = {}, [], []
        self.tables = ROOT/'tables/supplement'
        self.figdata = ROOT/'figure_data'
        self.figdata.mkdir(exist_ok=True)
        self.performance = self.read('tables/supplement/external_performance.csv')
        self.internal = self.read('tables/supplement/development_internal_summary.csv')
        self.repeats = self.read('tables/supplement/development_repeat_performance.csv')
        self.apparent = self.read('tables/supplement/development_apparent.csv')
        self.training = self.read('tables/supplement/development_training.csv')
        self.ranking = self.read('tables/supplement/development_ranking.csv').sort_values('rank')
        self.paired = self.read('tables/supplement/external_paired_comparison.csv')
        self.calibration = self.read('tables/supplement/external_calibration.csv')
        self.groups = self.read('tables/supplement/histgb_score_groups.csv')
        self.contrasts = self.read('tables/supplement/histgb_group_contrasts.csv')
        self.subgroups = self.read('tables/supplement/histgb_subgroups.csv')
        self.dca = self.read('tables/supplement/external_decision_curve.csv')
        self.baseline = self.read('tables/supplement/baseline.csv')
        self.pred = self.read('results/external_predictions_private.csv')
        self.dev_oof = self.read('results/development_oof_private.csv')
        self.dev_train = self.read('results/development_training_private.csv')
        self.time_auc = self.read('tables/supplement/time_auc_sensitivity.csv')
        self.aj = self.read('tables/supplement/aj_curves.csv')
        self.risk = self.read('tables/supplement/aj_at_risk.csv')
        self.aj_summary = self.read('tables/supplement/aj_horizon_summary.csv')
        self.time_diag = self.read('tables/supplement/time_diagnostics.csv')
        self.raw = {}
        for role in ['development', 'external']:
            path = (ROOT/self.cfg['data_directory']/self.cfg[role+'_file']).resolve()
            assert hashlib.sha256(path.read_bytes()).hexdigest() == self.cfg['raw_sha256'][path.name]
            self.raw[role] = pd.read_csv(path, sep='\t', float_precision='round_trip')
        assert len(self.pred) == len(self.raw['external']) == self.cfg['external_n']
        np.testing.assert_array_equal(self.pred.Type, self.raw['external'].Type)

    def read(self, rel):
        p = ROOT/rel
        self.inputs[rel] = hashlib.sha256(p.read_bytes()).hexdigest()
        return pd.read_csv(p, float_precision='round_trip', encoding='utf-8-sig')

    def export(self, stem, frame):
        if {'id', 'row_index', 'patient_id'}.intersection(frame.columns):
            raise ValueError('Figure source data must be aggregate')
        frame.to_csv(self.figdata/(stem+'.csv'), index=False, float_format='%.17g', encoding='utf-8-sig')

    def canvas(self, height=220):
        return plt.figure(figsize=(180/25.4, height/25.4))

    def finish(self, fig, stem, heading, note, tier='main'):
        # Full titles and interpretive notes accompany the figure in the legends.
        dest = ROOT/'figures'/tier
        dest.mkdir(exist_ok=True, parents=True)
        paths=[]
        for ext in ['pdf', 'svg', 'png']:
            p=dest/(stem+'.'+ext); fig.savefig(p, dpi=300)
            paths.append(str(p.relative_to(ROOT)))
        self.outputs.append(dict(stem=stem, tier=tier, paths=paths, width_mm=180,
                                 height_mm=round(fig.get_size_inches()[1]*25.4, 1),
                                 title=heading, legend_note=note, png_dpi=300))
        plt.close(fig)

    def box(self, ax, xy, wh, text, color=BLUE, fill='#F0F6F8', size=8):
        x,y=xy; w,h=wh
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.015',
                                   facecolor=fill, edgecolor=color, linewidth=1))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,linespacing=1.45)

    def arrow(self, ax, start, end, color=GREY):
        ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=10,color=color,lw=1))

    def figure1(self):
        fig=self.canvas(230)
        flow=fig.add_axes([.06,.555,.88,.34]);flow.axis('off');flow.set(xlim=(-.025,1.025),ylim=(-.025,1.025));title(flow,'A','First-PE analytical cohorts')
        self.box(flow,(.01,.55),(.43,.35),'Development\nFuwai Shenzhen Hospital\n161 participants · 47 recurrent VTE events',BLUE,size=8)
        self.box(flow,(.55,.55),(.44,.35),'External validation\nThree geographically separate hospitals\n550 participants · 101 recurrent VTE events',GREEN,size=8)
        flow.text(.015,.43,'Eligibility',fontweight='bold',fontsize=8)
        flow.text(.015,.36,'First PE · age ≥18 years\n≥3 months of oral anticoagulation\nNo active cancer or major provoking factor\nAnticoagulation subsequently discontinued',fontsize=7.6,va='top',linespacing=1.55)
        flow.text(.555,.43,'External hospitals',fontweight='bold',fontsize=8)
        flow.text(.555,.36,'Fuwai Beijing\nSecond Hospital of Shandong University\nChangzhou People’s Hospital',fontsize=7.6,va='top',linespacing=1.55)
        self.box(flow,(.01,.005),(.98,.12),'Prior PE/VTE before index enrolment: 19 excluded from external validation',GREY,'#F6F7F8',7.5)
        timeline=fig.add_axes([.06,.385,.88,.105]);timeline.axis('off');timeline.set(xlim=(-.025,1.025),ylim=(-.025,1.025));title(timeline,'B','Predictor timing and observation origin')
        for x,txt,col in [(.0,'Acute first PE\nRoutine predictors',BLUE),(.34,'≥3 months anticoagulation\nCessation = time zero',GREEN),(.68,'First recurrent VTE, death\nor last event-free contact',ORANGE)]:
            self.box(timeline,(x,.1),(.30,.60),txt,col,size=7.5)
        self.arrow(timeline,(.305,.4),(.335,.4));self.arrow(timeline,(.645,.4),(.675,.4))
        pipeline=fig.add_axes([.06,.135,.39,.17]);pipeline.axis('off');title(pipeline,'C','Locked development-to-validation path')
        pipeline.text(.03,.94,'13 model families',fontweight='bold',fontsize=9,va='top')
        pipeline.text(.03,.72,'3 repeats × 5 outer / 3 inner folds\nDevelopment-only top-five ranking\nHistGB designated before external testing\nFrozen models applied to the final cohort',fontsize=7.7,va='top',linespacing=1.7)
        pipeline.text(.03,.05,'External evaluation of fixed predictions',fontsize=7.5,color=BLUE,fontweight='bold')
        ecdf=fig.add_axes([.60,.135,.34,.17]);title(ecdf,'D','Observed endpoint times')
        rows=[]
        for role,col,lbl in [('development',BLUE,'Development'),('external',GREEN,'External')]:
            times=self.raw[role].fu_months.to_numpy(float)
            unique,count=np.unique(times,return_counts=True);cdf=np.cumsum(count)/len(times)
            ecdf.step(np.r_[0,unique],np.r_[0,cdf],where='post',color=col,lw=1.3,label=f'{lbl} (n={len(times)})')
            for x,v in zip(unique,cdf):rows.append(dict(cohort=lbl,month=x,ecdf=v,n=len(times)))
        ecdf.set(xlim=(0,60),ylim=(0,1),xticks=[0,12,24,36,48,60],xlabel='Months after anticoagulation cessation',ylabel='Cumulative fraction of endpoint times')
        ecdf.legend(loc='upper left',fontsize=7);ecdf.grid(axis='y')
        self.export('Figure_1_observed_time_ecdf',pd.DataFrame(rows))
        self.export('Figure_1_cohort_flow',self.read('cohort_flow.csv'))
        self.finish(fig,'Figure_1_study_design','Figure 1. Prospective cohorts and geographic external validation',
            'Panel D displays uncapped observation-endpoint times on a 0–60-month axis. The binary target is first recorded recurrent VTE over individual observation periods. Eligibility review applied the first-PE requirement to the full external cohort.')

    def figure2(self):
        fig=self.canvas(235)
        order=self.top5+['locked_primary']
        training_roc=fig.add_axes([.11,.665,.36,.245])
        external_roc=fig.add_axes([.61,.665,.34,.245])
        comparison=fig.add_axes([.30,.355,.22,.205])
        pr=fig.add_axes([.67,.355,.28,.205])
        diff=fig.add_axes([.30,.105,.42,.135])
        curves=[];rows=[]
        for m in order:
            col=self.colors[m];ls='--' if m=='locked_primary' else '-'
            training=metric(self.training,m,'auc');external=metric(self.performance,m,'auc')
            rows.append(dict(model=m,training_auc=training.estimate,external_auc=external.estimate,
                             external_lower=external.lower,external_upper=external.upper))
            for ax,frame,cohort in [(training_roc,self.dev_train,'training'),(external_roc,self.pred,'external')]:
                fpr,tpr,_=roc_curve(frame.Type.to_numpy(),frame[m].to_numpy())
                auc_value = training.estimate if cohort == 'training' else external.estimate
                ax.plot(fpr,tpr,color=col,lw=1.25,ls=ls,label=f'{label(m)}  {auc_value:.3f}')
                curves.extend(dict(model=m,cohort=cohort,curve='ROC',x=x,y=v) for x,v in zip(fpr,tpr))
            precision,recall,_=precision_recall_curve(self.pred.Type,self.pred[m])
            pr.step(recall,precision,where='post',color=col,lw=1.25,ls=ls)
            curves.extend(dict(model=m,cohort='external',curve='PR',x=x,y=v) for x,v in zip(recall,precision))
        for ax,letter,heading in [(training_roc,'A','Training ROC'),(external_roc,'B','External ROC')]:
            ax.plot([0,1],[0,1],':',color=GREY,lw=.8)
            ax.set(xlim=(0,1),ylim=(0,1),xlabel='1 − specificity',ylabel='Sensitivity')
            ax.grid(alpha=.45);title(ax,letter,heading)
            ax.legend(loc='lower right',fontsize=6.5,handlelength=1.7,
                      frameon=True,facecolor='white',edgecolor='none',framealpha=.9,
                      title='Model / AUROC',title_fontsize=6.5)
        for i,m in enumerate(order):
            col=self.colors[m];t=metric(self.training,m,'auc');r=metric(self.performance,m,'auc')
            comparison.plot(t.estimate,i-.13,marker='^',mfc='white',mec=col,ms=4.7,ls='')
            point(comparison,r.estimate,i+.13,r.lower,r.upper,col,ms=4)
        comparison.set(yticks=np.arange(len(order)),yticklabels=[label(m) for m in order],
                       ylim=(len(order)-.35,-.65),xlim=(.5,1),xticks=[.5,.75,1],xlabel='AUROC')
        title(comparison,'C','Discrimination');comparison.grid(axis='x')
        comparison.legend(handles=[Line2D([],[],marker='^',mfc='white',mec=GREY,color=GREY,ls='',label='Training'),
            Line2D([],[],marker='o',color=GREY,ls='-',label='External (95% CI)')],
            ncol=2,loc='upper center',bbox_to_anchor=(.5,-.22),fontsize=6.8,columnspacing=1.2)
        pr.axhline(self.pred.Type.mean(),color=GREY,ls=':',lw=.8)
        pr.set(xlim=(0,1),ylim=(0,1),xlabel='Recall',ylabel='Precision')
        title(pr,'D','External precision–recall');pr.grid(alpha=.45)
        for i,m in enumerate(self.top5):
            r=self.paired.loc[self.paired.model.eq(m)&self.paired.comparator.eq('locked_primary')&self.paired.metric.eq('auc')].iloc[0]
            point(diff,r.estimate,i,r.lower,r.upper,self.colors[m])
            diff.text(1.06,i,ci(r),transform=diff.get_yaxis_transform(),ha='left',va='center',fontsize=7.1)
        diff.axvline(0,color=GREY,ls=':',lw=.8)
        diff.set(yticks=np.arange(5),yticklabels=[label(m) for m in self.top5],ylim=(4.6,-.6),
                 xlabel='External AUROC difference versus original ridge',xlim=(-.08,.10),xticks=[-.05,0,.05,.10])
        diff.grid(axis='x');title(diff,'E','Paired external comparison')
        self.export('Figure_2_training_external_comparison',pd.DataFrame(rows))
        self.export('Figure_2_ROC_PR_coordinates',pd.DataFrame(curves))
        self.export('Figure_2_paired_comparison',self.paired)
        self.finish(fig,'Figure_2_locked_model_comparison','Figure 2. Training and external discrimination of the development-selected models',
            'Training AUROCs use predictions from final models fitted to all 161 development participants and evaluated in those same participants. Internal cross-validation results are in Figure S1. External predictions use unchanged fitted models. Order follows development-only model ranking. External intervals condition on frozen models; paired comparisons are exploratory and unadjusted for multiplicity.')

    def calibration_panel(self,ax,m,letter,show_stats=True):
        q=self.calibration.loc[self.calibration.model.eq(m)].sort_values('group')
        valid=q.dropna(subset=['mean_predicted','observed'])
        ax.plot([0,1],[0,1],':',color=GREY,lw=1)
        ax.errorbar(valid.mean_predicted,valid.observed,
            yerr=[np.maximum(0,valid.observed-valid.lower),np.maximum(0,valid.upper-valid.observed)],
            fmt='o-',color=self.colors[m],lw=1.3,ms=4,capsize=2.5)
        ax.set(xlim=(0,1),ylim=(0,1),xticks=[0,.25,.5,.75,1],yticks=[0,.25,.5,.75,1],xlabel='Mean predicted probability',ylabel='Recorded recurrence fraction')
        title(ax,letter,label(m)+' calibration');ax.grid(True)
        if show_stats:
            ax.text(.04,.97,f"Intercept {metric(self.performance,m,'calibration_intercept').estimate:.2f}\nSlope {metric(self.performance,m,'calibration_slope').estimate:.2f}\nO/E {metric(self.performance,m,'observed_expected').estimate:.2f}",transform=ax.transAxes,va='top',fontsize=7.4)
        return q

    def figure3(self):
        fig=self.canvas(220)
        ax=fig.add_axes([.11,.55,.38,.32]);q=self.calibration_panel(ax,'hist_gradient_boosting','A',show_stats=False)
        prevalence=fig.add_axes([.64,.60,.28,.24]);title(prevalence,'B','Probability level')
        rows=[metric(self.performance,'hist_gradient_boosting',k) for k in ['prevalence','mean_predicted']]
        for i,r in enumerate(rows):
            prevalence.errorbar(i,r.estimate,yerr=[[r.estimate-r.lower],[r.upper-r.estimate]],fmt='o',color=[GREEN,BLUE][i],ms=6,capsize=3)
            prevalence.text(i,r.upper+.035,f'{r.estimate*100:.1f}%',ha='center',fontweight='bold',fontsize=9,color=[GREEN,BLUE][i])
        prevalence.set(xlim=(-.5,1.5),ylim=(0,.5),xticks=[0,1],xticklabels=['Observed','Predicted'],ylabel='Probability / observed fraction');prevalence.grid(axis='y')
        forest=fig.add_axes([.30,.30,.43,.135]);title(forest,'C','Calibration diagnostics')
        for i,(key,ref) in enumerate([('calibration_intercept',0),('calibration_slope',1)]):
            r=metric(self.performance,'hist_gradient_boosting',key);point(forest,r.estimate,i,r.lower,r.upper,BLUE)
            forest.plot([ref,ref],[i-.28,i+.28],ls=':',color=GREY,lw=1)
            forest.text(1.05,i,ci(r,2),transform=forest.get_yaxis_transform(),ha='left',va='center',fontsize=7.4)
        forest.set(yticks=[0,1],yticklabels=['Calibration intercept','Calibration slope'],ylim=(1.6,-.65),xlim=(-1.3,1.5),xlabel='Estimate (95% CI)');forest.grid(axis='x')
        brier=fig.add_axes([.30,.115,.62,.095]);title(brier,'D','Overall probability error')
        for i,m in enumerate(['hist_gradient_boosting','locked_primary','compact_primary']):
            r=metric(self.performance,m,'brier');point(brier,r.estimate,i,r.lower,r.upper,self.colors[m]);brier.text(.98,i,ci(r),transform=brier.get_yaxis_transform(),ha='right',va='center',fontsize=7.3)
        brier.set(yticks=[0,1,2],yticklabels=['HistGB','Original ridge','Compact ridge'],ylim=(2.7,-.6),xlim=(.08,.24),xlabel='Brier score (95% CI)');brier.grid(axis='x')
        self.export('Figure_3_HistGB_calibration',q);self.export('Figure_3_probability_diagnostics',self.performance.loc[self.performance.model.isin(['hist_gradient_boosting','locked_primary','compact_primary'])])
        self.finish(fig,'Figure_3_histgb_probability_accuracy','Figure 3. HistGB external prediction performance and calibration',
            'Calibration groups use unchanged development OOF quintile boundaries; bars are Wilson 95% CIs. Probability-level and Brier intervals use participant bootstrap. Calibration diagnostics do not modify model predictions. Absolute probabilities describe unequal observed follow-up.')

    def aj_external(self,frame):
        return frame.loc[frame.cohort.str.lower().str.startswith('external')]

    def figure4(self):
        fig=self.canvas(245)
        proportions=fig.add_axes([.10,.68,.36,.17]);hist=fig.add_axes([.60,.68,.34,.17])
        cols=[GREEN,BLUE,ORANGE]
        for i,r in self.groups.sort_values('group').reset_index(drop=True).iterrows():
            proportions.errorbar(i,r.observed,yerr=[[r.observed-r.lower],[r.upper-r.observed]],fmt='o',color=cols[i],ms=6,capsize=3)
            proportions.text(i,r.upper+.035,f'{r.observed*100:.1f}%',ha='center',fontweight='bold',fontsize=8,color=cols[i])
        group_labels=[f"{AJ_GROUP[r.label]}\n{int(r.events)}/{int(r.n)}" for _,r in self.groups.sort_values('group').iterrows()]
        proportions.set(xticks=[0,1,2],xticklabels=group_labels,xlim=(-.5,2.5),ylim=(0,min(1,self.groups.upper.max()+.13)),ylabel='Recorded recurrence fraction')
        title(proportions,'A','Development-defined score groups');proportions.grid(axis='y')
        bins=np.linspace(0,1,21);histrows=[]
        for yy,c,lbl in [(0,GREY,'No recorded recurrence'),(1,ORANGE,'Recorded recurrence')]:
            scores=self.pred.loc[self.pred.Type.eq(yy),'hist_gradient_boosting'].to_numpy();counts,edges=np.histogram(scores,bins=bins)
            hist.stairs(counts/len(scores),edges,color=c,lw=1.4,label=lbl)
            histrows.extend(dict(outcome=yy,left=l,right=r,fraction=v/len(scores),n=len(scores)) for l,r,v in zip(edges[:-1],edges[1:],counts))
        for c in self.cfg['score_cuts']:hist.axvline(c,ls=':',color=BLUE,lw=.8)
        hist.set(xlim=(0,1),xlabel='HistGB predicted probability',ylabel='Fraction within outcome group');title(hist,'B','Score distributions');hist.legend(fontsize=7,loc='upper right')
        ajax=fig.add_axes([.22,.30,.70,.255]);title(ajax,'C','Time-aware competing-risk incidence')
        aj=self.aj_external(self.aj);risk=self.aj_external(self.risk)
        strata=['Lower score','Middle score','Higher score']
        for s,col in zip(strata,cols):
            q=aj.loc[aj.stratum.str.lower().eq(s.lower())].sort_values('month')
            if q.empty:raise ValueError(f'Missing AJ stratum {s}')
            ajax.step(q.month,q.cif_vte,where='post',color=col,lw=1.5,label=s)
            ajax.fill_between(q.month,q.lower,q.upper,step='post',color=col,alpha=.12,lw=0)
        ajax.set(xlim=(0,60),ylim=(0,min(1,max(.5,aj.loc[aj.stratum.isin(strata),'upper'].max()+.04))),xticks=[0,12,24,36,48,60],xlabel='Months after anticoagulation cessation',ylabel='Cumulative incidence of recurrent VTE')
        ajax.legend(ncol=3,loc='upper left');ajax.grid(axis='y')
        counts_ax=fig.add_axes([.22,.16,.70,.078]);counts_ax.axis('off')
        counts_ax.text(-.015,1.05,'Number at risk',transform=counts_ax.transAxes,fontsize=7.5,fontweight='bold',ha='left')
        for i,(s,c) in enumerate(zip(strata,cols)):
            counts_ax.text(-.05,.65-i*.32,s,transform=counts_ax.transAxes,ha='right',fontsize=7.5,color=c)
            qq=risk.loc[risk.stratum.str.lower().eq(s.lower())]
            for t in [0,12,24,36,48,60]:
                r=qq.loc[np.isclose(qq.month,t)]
                if len(r)!=1:raise ValueError(f'Missing at-risk count {s}/{t}')
                counts_ax.text(t/60,.65-i*.32,str(int(r.n_at_risk.iloc[0])),transform=counts_ax.transAxes,ha='center',fontsize=7.5,color=c)
        self.export('Figure_4_score_groups',self.groups);self.export('Figure_4_score_histogram',pd.DataFrame(histrows));self.export('Figure_4_AJ_curves',aj);self.export('Figure_4_AJ_at_risk',risk)
        self.finish(fig,'Figure_4_histgb_score_stratification','Figure 4. Recurrence stratification using unchanged HistGB scores',
            'Score cuts were frozen from development OOF tertiles. Panels A/B use all recorded outcomes. Panel C accounts for death and censoring to 60 months; only one VTE occurs by 60 months in the lower-score group. Sparse-event intervals do not establish zero risk or a safe stopping threshold.')

    def figure5(self):
        fig=self.canvas(205)
        fig.text(.055,.90,'A  External time-dependent discrimination',fontsize=9,fontweight='bold')
        q=self.aj_external(self.time_auc)
        q=q.loc[q.model.isin(self.top5)].copy()
        for j,horizon in enumerate([12,36,60]):
            ax=fig.add_axes([.31+j*.23,.56,.16,.28])
            for i,m in enumerate(self.top5):
                r=q.loc[q.model.eq(m)&q.horizon_months.eq(horizon)].iloc[0]
                point(ax,r.estimate,i,r.lower,r.upper,self.colors[m])
                ax.text(r.estimate,i-.27,f'{r.estimate:.3f}',ha='center',va='bottom',fontsize=6.7,color=self.colors[m])
            ax.set(yticks=np.arange(5),yticklabels=[label(m) for m in self.top5] if j==0 else ['']*5,
                   ylim=(4.55,-.78),xlim=(.5,1),xticks=[.5,.75,1],xlabel='AUROC (95% CI)')
            ax.set_title(f'{horizon} months',fontsize=8.5,pad=10);ax.grid(axis='x')
        support=fig.add_axes([.055,.16,.90,.27]);support.axis('off');title(support,'B','Events, risk sets and censoring-weighted information')
        d=self.aj_external(self.time_diag).copy().sort_values('horizon_months')
        cells=[[r.cohort,str(int(r.horizon_months)),str(int(r.vte_by_horizon)),str(int(r.death_by_horizon)),str(int(r.at_risk_at_horizon)),f'{r.effective_sample_size:.1f}'] for _,r in d.iterrows()]
        tab=support.table(cellText=cells,colLabels=['Cohort','Months','VTE events','Competing\ndeaths','Number\nat risk','IPCW\neffective n'],colWidths=[.18,.12,.16,.17,.17,.20],cellLoc='center',colLoc='center',bbox=[0,.03,1,.86])
        tab.auto_set_font_size(False);tab.set_fontsize(7.7)
        for (row,col),cell in tab.get_celld().items():
            cell.set_edgecolor(GRID);cell.set_linewidth(.6)
            if row==0:cell.set_facecolor('#EDF3F6');cell.set_text_props(fontweight='bold')
            elif row % 2 == 0:cell.set_facecolor('#F5F9F7')
        self.export('Figure_5_external_time_discrimination',q);self.export('Figure_5_time_support',d)
        self.finish(fig,'Figure_5_time_aware_validation','Figure 5. Time-aware evaluation through five years',
            'Cumulative/dynamic AUROC uses inverse-probability-of-censoring weights (IPCW) and frozen binary model scores. Risk sets are counted immediately before each horizon. Derived time endpoints are administratively censored at 60 months; source times are preserved.')

    def supplement1(self):
        fig=self.canvas(245)
        a=fig.add_axes([.30,.34,.37,.51]);b=fig.add_axes([.77,.34,.18,.51]);c=fig.add_axes([.30,.14,.65,.12])
        order=self.ranking.model.tolist();rows=[]
        for i,m in enumerate(order):
            r=metric(self.internal,m,'auc');app=metric(self.apparent,m,'auc');col=self.colors.get(m,GREY)
            point(a,r['mean'],i,r['min'],r['max'],col,ms=3.7);a.plot(app.estimate,i,'^',mfc='white',mec=col,ms=4)
            b.barh(i,app.estimate-r['mean'],height=.55,color=col)
            rows.append(dict(model=m,internal_mean=r['mean'],internal_min=r['min'],internal_max=r['max'],apparent=app.estimate,gap=app.estimate-r['mean']))
        a.set(yticks=np.arange(len(order)),yticklabels=[f'{i+1}. {label(m)}' for i,m in enumerate(order)],ylim=(len(order)-.4,-.7),xlim=(.4,1.02),xlabel='AUROC');title(a,'A','All candidate families');a.grid(axis='x')
        a.legend(handles=[Line2D([],[],marker='o',color=GREY,label='Internal mean / repeat range'),Line2D([],[],marker='^',mfc='white',color=GREY,ls='',label='Training')],loc='lower left',bbox_to_anchor=(-.03,1.06),fontsize=7)
        a.axhline(4.5,color=GREY,ls=':',lw=.7)
        b.set(yticks=[],ylim=a.get_ylim(),xlabel='Training − internal');title(b,'B','AUROC gap');b.grid(axis='x')
        procs=['adaptive_inner_auc_selection','original_logloss_procedure']
        for i,m in enumerate(procs):
            r=metric(self.internal,m,'auc');point(c,r['mean'],i,r['min'],r['max'],[ORANGE,BLUE][i]);c.text(.99,i,f"{r['mean']:.3f} [{r['min']:.3f}, {r['max']:.3f}]",transform=c.get_yaxis_transform(),ha='right',va='center',fontsize=7.8)
        c.set(yticks=[0,1],yticklabels=['Adaptive inner-CV selection','Original log-loss procedure'],ylim=(1.6,-.6),xlim=(.4,1.02),xlabel='Repeated nested OOF AUROC');title(c,'C','Related selection procedures');c.grid(axis='x')
        self.export('Figure_S1_development_all_models',pd.DataFrame(rows));self.export('Figure_S1_selection_procedures',self.internal.loc[self.internal.model.isin(procs)])
        self.finish(fig,'Figure_S1_development_comparison','Figure S1. Complete development search and internal validation',
            'Internal repeat ranges are not confidence intervals. Ranking families on the same OOF evaluations adds selection optimism. Panel C evaluates a related inner-CV selection rule, not an unbiased evaluation of the final OOF-ranking algorithm.',tier='supplement')

    def supplement2(self):
        fig=self.canvas(265);positions=[(.10,.69),(.60,.69),(.10,.43),(.60,.43),(.10,.17),(.60,.17)]
        for i,(m,(x,y)) in enumerate(zip(self.top5,positions)):
            ax=fig.add_axes([x,y,.34,.17]);q=self.calibration_panel(ax,m,chr(65+i),show_stats=False)
        ax=fig.add_axes([.60,.17,.34,.17]);title(ax,'F','Descriptive decision curves')
        for m in self.top5+['locked_primary','treat_all','treat_none']:
            q=self.dca.loc[self.dca.model.eq(m)];ax.plot(q.threshold,q.net_benefit,color=self.colors.get(m,GREY),ls='--' if m in ['treat_all','locked_primary'] else (':' if m=='treat_none' else '-'),lw=1.1,label=label(m))
        ax.set(xlim=(.01,.5),ylim=(-.10,.2),xlabel='Probability threshold',ylabel='Net benefit');ax.grid(axis='y')
        self.export('Figure_S2_all_calibration',self.calibration);self.export('Figure_S2_decision_curves',self.dca)
        self.finish(fig,'Figure_S2_calibration_decision_curves','Figure S2. Calibration of all locked models and descriptive utility',
            'Calibration groups use original development OOF quintiles. There is no shared binary risk horizon or validated anticoagulation trade-off; decision curves do not establish a treatment policy. Colours follow the main model comparison.',tier='supplement')

    def supplement3(self):
        fig=self.canvas(230);a=fig.add_axes([.22,.59,.70,.27]);riskax=fig.add_axes([.22,.47,.70,.065]);riskax.axis('off');b=fig.add_axes([.28,.16,.64,.20])
        riskax.text(0,1.24,'Number at risk',transform=riskax.transAxes,fontsize=7.5,fontweight='bold')
        for role,col in [('Development',BLUE),('External',GREEN)]:
            q=self.aj.loc[self.aj.cohort.str.lower().str.startswith(role.lower())&self.aj.stratum.str.lower().isin(['all','overall'])].sort_values('month')
            if q.empty:continue
            a.step(q.month,q.cif_vte,where='post',color=col,label=role,lw=1.4);a.fill_between(q.month,q.lower,q.upper,step='post',color=col,alpha=.12)
            rr=self.risk.loc[self.risk.cohort.str.lower().str.startswith(role.lower())&self.risk.stratum.str.lower().isin(['all','overall'])]
            row=0 if role=='Development' else 1
            riskax.text(-.05,.75-row*.65,role,ha='right',color=col,transform=riskax.transAxes,fontsize=7.5)
            for t in [0,12,24,36,48,60]:
                z=rr.loc[np.isclose(rr.month,t)]
                if len(z):riskax.text(t/60,.75-row*.65,str(int(z.n_at_risk.iloc[0])),ha='center',color=col,transform=riskax.transAxes,fontsize=7.5)
        a.set(xlim=(0,60),ylim=(0,1),xticks=[0,12,24,36,48,60],xlabel='Months after anticoagulation cessation',ylabel='Cumulative incidence of recurrent VTE');a.legend();a.grid(axis='y');title(a,'A','Overall competing-risk incidence')
        horizons=[12,36,60]
        for i,h in enumerate(horizons):
            for role,col,offset in [('Development',BLUE,-.14),('External',GREEN,.14)]:
                q=self.time_auc.loc[self.time_auc.cohort.str.lower().str.startswith(role.lower())&self.time_auc.model.eq('hist_gradient_boosting')&self.time_auc.horizon_months.eq(h)]
                if len(q)!=1:continue
                r=q.iloc[0];lo=r.get('repeat_minimum',np.nan) if role=='Development' else r.lower;hi=r.get('repeat_maximum',np.nan) if role=='Development' else r.upper
                point(b,r.estimate,i+offset,lo,hi,col,marker='s' if role=='Development' else 'o')
        b.set(yticks=range(3),yticklabels=['12 months','36 months','60 months'],ylim=(2.6,-.6),xlim=(.3,1),xlabel='Time-dependent HistGB score AUROC');title(b,'B','Internal and external time-dependent ranking');b.grid(axis='x')
        fig.legend(handles=[Line2D([],[],marker='s',color=BLUE,label='Development: mean / repeat range'),Line2D([],[],marker='o',color=GREEN,label='External: estimate / 95% CI')],loc='upper center',bbox_to_anchor=(.60,.445),fontsize=7)
        self.export('Figure_S3_time_auc',self.time_auc);self.export('Figure_S3_AJ_all',self.aj);self.export('Figure_S3_at_risk',self.risk)
        self.finish(fig,'Figure_S3_time_sensitivity','Figure S3. Time-aware sensitivity analyses through 60 months',
            'Original times are preserved; administrative censoring is applied to derived time endpoints. Development estimates average repeat-specific OOF AUROCs, with repeat ranges rather than CIs. External CIs condition on the locked models. Later estimates can be imprecise when numbers at risk are small.',tier='supplement')

    def supplement4(self):
        fig=self.canvas(220);axes=[fig.add_axes([.32,.16,.30,.69]),fig.add_axes([.73,.16,.22,.69])]
        for ax,key,letter in zip(axes,['auc','brier'],['A','B']):
            q=self.subgroups.loc[self.subgroups.metric.eq(key)].reset_index(drop=True)
            overall=metric(self.performance,'hist_gradient_boosting',key)
            ax.axvline(overall.estimate,color=GREY,lw=1,ls=':')
            labels=[]
            for i,r in q.iterrows():
                point(ax,r.estimate,i,r.lower,r.upper,BLUE)
                labels.append(f"{r.group.replace('>=','≥')}\n{int(r.events)}/{int(r.n)} events/participants")
            ax.set(yticks=np.arange(len(q)),yticklabels=labels if key=='auc' else ['']*len(q),ylim=(len(q)-.35,-.65),xlabel=('AUROC' if key=='auc' else 'Brier score')+' (95% CI)')
            if key=='auc':ax.set_xlim(.4,1.02)
            ax.grid(axis='x');title(ax,letter,'Discrimination' if key=='auc' else 'Probability error')
        self.export('Figure_S4_subgroup_performance',self.subgroups)
        self.finish(fig,'Figure_S4_subgroup_performance','Figure S4. Exploratory HistGB performance in clinical subgroups',
            'Groups are not independently refitted. The diabetes subgroup contains only eight events; two of 1,000 AUC bootstrap samples lack outcome variation. Wide or overlapping CIs do not establish equivalent performance or lack of heterogeneity. Dotted lines mark overall external estimates.',tier='supplement')

    def html_table(self,stem,frame,heading,note):
        directory=ROOT/'tables/main';directory.mkdir(exist_ok=True,parents=True)
        frame.to_csv(directory/(stem+'.csv'),index=False,encoding='utf-8-sig')
        css='body{font-family:Arial,sans-serif;color:#172f3b;margin:36px;max-width:1300px}h1{font-size:21px}table{border-collapse:collapse;width:100%;font-size:13px}th{background:#edf3f6;border-top:2px solid #264c5d;border-bottom:1px solid #264c5d;text-align:left}td,th{padding:9px 10px;border-bottom:1px solid #dde6ea;vertical-align:top}tbody tr:nth-child(even){background:#f8fafb}p{font-size:13px;line-height:1.5}caption{display:none}'
        (directory/(stem+'.html')).write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>'+html.escape(heading)+'</title><style>'+css+'</style><h1>'+html.escape(heading)+'</h1>'+frame.to_html(index=False,escape=True,border=0)+'<p>'+html.escape(note)+'</p></html>',encoding='utf-8')
        self.table_outputs.append(dict(stem=stem,rows=len(frame),columns=list(frame.columns),title=heading,note=note))

    def main_tables(self):
        rows=[]
        for _,r in self.baseline.iterrows():
            if r.variable=='fu_months':
                continue
            name=VARIABLES.get(r.variable,r.variable)
            if r.variable=='gender':name='Female' if r.level==1 else 'Male'
            rows.append({'Characteristic':name,'Development (n=161)':r.development,'External validation (n=550)':r.external})
        self.html_table('Table_1_cohort_characteristics',pd.DataFrame(rows),'Table 1. Characteristics of the development and eligible external validation cohorts',
            'Continuous variables: median [interquartile range]; categorical variables: count/denominator (%). Sex coding: 1=female, 2=male. All shown fields are complete. Laboratory variables are presented in SI units on their recorded numerical scales. Observation time is to first recurrence, death without recurrence, or last confirmed event-free contact. Death includes deaths after recurrence. Binary recurrence fractions have unequal observation windows.')
        rows=[]
        for m in self.top5+['locked_primary','compact_primary']:
            rows.append({'Model':label(m),'Training AUC':f"{metric(self.training,m,'auc').estimate:.3f}",
                'External AUC (95% CI)':ci(metric(self.performance,m,'auc')),
                'Brier score (95% CI)':ci(metric(self.performance,m,'brier')),
                'Calibration intercept (95% CI)':ci(metric(self.performance,m,'calibration_intercept'),2),
                'Calibration slope (95% CI)':ci(metric(self.performance,m,'calibration_slope'),2),
                'Observed/expected (95% CI)':ci(metric(self.performance,m,'observed_expected'),2)})
        self.html_table('Table_2_locked_model_performance',pd.DataFrame(rows),'Table 2. Performance of the five locked models and original ridge comparators',
            'External n=550, recorded recurrent VTE n=101 (18.36%). Models retain development rank. Training AUC is calculated using final-model predictions in the same 161 participants used for fitting; it measures fit to the training data and is not an internal-validation estimate. Repeated nested cross-validation results are in Figure S1 and Table S1. HistGB was selected using development data. The original primary ridge was selected by log loss and differs from the AUC-tuned ridge. External 95% intervals use 2,000 participant bootstrap draws; calibration coefficients use 500. Ideal calibration intercept=0, slope=1 and observed/expected=1. No external recalibration. Comparisons are exploratory and unadjusted for multiplicity.')
        rows=[]
        for _,r in self.groups.sort_values('group').iterrows():
            s=self.aj_summary.loc[self.aj_summary.cohort.str.lower().str.startswith('external')&self.aj_summary.stratum.eq(AJ_GROUP[r.label])&self.aj_summary.horizon_months.eq(60)]
            risk=self.aj_external(self.risk);risk=risk.loc[risk.stratum.eq(AJ_GROUP[r.label])&risk.month.eq(60)]
            if len(s)!=1:raise ValueError('Expected AJ summary for each external group at 60 months')
            a=s.iloc[0]
            estimate=a.get('estimate',a.get('cif_vte',np.nan))
            interval_text=f'{estimate*100:.1f} ({a.lower*100:.1f}, {a.upper*100:.1f})'
            bounds=['≤ '+f"{self.cfg['score_cuts'][0]:.3f}",f"({self.cfg['score_cuts'][0]:.3f}, {self.cfg['score_cuts'][1]:.3f}]",'> '+f"{self.cfg['score_cuts'][1]:.3f}"]
            rows.append({'HistGB score group':AJ_GROUP[r.label],'Probability-score interval':bounds[int(r.group)-1],
                'Participants':int(r.n),'Recorded VTE events':int(r.events),
                'Recorded fraction, % (95% CI)':f'{r.observed*100:.1f} ({r.lower*100:.1f}, {r.upper*100:.1f})',
                'Mean predicted probability, %':f'{r.mean_predicted*100:.1f}',
                '60-month VTE incidence, % (95% CI)':interval_text,
                'At risk at 60 months':int(risk.n_at_risk.iloc[0])})
        self.html_table('Table_3_histgb_score_stratification',pd.DataFrame(rows),'Table 3. External recurrence stratification using development-defined HistGB score groups',
            'Cut points are tertiles of each development participant’s mean probability across three nested OOF repeats, fixed before this external reassessment. Displayed boundaries are rounded to three decimals; assignments use full precision. Recorded fractions use all observed binary labels and Wilson intervals. The 60-month cumulative incidence uses recurrence timing, death as a competing event and administrative censoring, with bootstrap intervals; it is not the calibration target of the binary probabilities. The lower-score group has only one event by 60 months and its percentile interval may be unstable. Counts at risk are immediately before the stated month.')
        (ROOT/'tables/main/table_metadata.json').write_text(json.dumps(self.table_outputs,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

    def register_shap_displays(self):
        for stem,heading in [('Figure_S5_HistGB_SHAP','SHAP explanations of the fixed HistGB model')]:
            paths=[ROOT/'figures/supplement'/(stem+'.'+ext) for ext in ['pdf','svg','png']]
            if not all(p.exists() for p in paths):
                raise FileNotFoundError('Run explain_histgb.py before rendering the complete display package.')
            with Image.open(paths[-1]) as im:
                dpi=im.info.get('dpi',(0,0))
                if any(abs(v-300)>.1 for v in dpi):raise ValueError('SHAP PNG must be exported at 300 dpi.')
                height_mm=round(im.height/dpi[1]*25.4,1)
            self.outputs.append(dict(stem=stem,tier='supplement',paths=[p.relative_to(ROOT).as_posix() for p in paths],
                                     title=heading,width_mm=180,height_mm=height_mm,png_dpi=300,
                                     rendering_script='code/explain_histgb.py'))

    def run(self):
        for fn in [self.figure1,self.figure2,self.figure3,self.figure4,self.figure5,
                   self.supplement1,self.supplement2,self.supplement3,self.supplement4]:fn()
        self.register_shap_displays()
        self.main_tables()
        record=dict(status='generated_pending_visual_review',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=self.inputs,figures=self.outputs,tables=self.table_outputs,model_fitting_performed=False,external_selection_performed=False)
        (ROOT/'audit/figure_table_rendering.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
        print(f'Rendered {len(self.outputs)} composite figures and {len(self.table_outputs)} main tables.')


if __name__=='__main__':
    style()
    Publication().run()
