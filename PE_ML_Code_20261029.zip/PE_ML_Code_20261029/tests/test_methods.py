"""Analytic boundary cases and independent checks of the submitted methods.

These fixtures contain no study participants and do not replace a complete
reproduction from the authorized original development and external data.
Run: python -m unittest discover -s tests -v
"""
from pathlib import Path
import ast
import json
import sys
import unittest

import numpy as np
from scipy.special import expit, logit
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.ensemble import HistGradientBoostingClassifier

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from binary_metrics import bootstrap_metrics, calibration, wilson
from survival_metrics import aalen_johansen, horizon_weights, weighted_auc_ap, UnsupportedCensoringError
from sample_size_precision import minimum_n, interval_width, assessment


def extracted_function(path,name,namespace):
    # Importing reporting programs would read study configuration or optional
    # plotting libraries. Compile the exact numerical function without that I/O.
    tree=ast.parse(path.read_text())
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),namespace)
    return namespace[name]


class MethodsTests(unittest.TestCase):
    def test_precision_reference_and_minimality(self):
        self.assertEqual(minimum_n(.8,.18),511)
        for r in assessment():
            n=r['required_n'];a=r['assumed_auroc'];p=r['event_proportion']
            self.assertLessEqual(interval_width(n,a,p),.10)
            self.assertGreater(interval_width(n-1,a,p),.10)

    def test_weighted_binary_metrics_with_ties_and_absent_class(self):
        y=np.array([0,1,0,1,1]);p=np.array([.2,.2,.7,.8,.8])
        counts=np.array([[1,2,3,4,1],[1,0,2,0,0]])
        result=bootstrap_metrics(y,p,counts)
        self.assertAlmostEqual(result['auc'][0],roc_auc_score(y,p,sample_weight=counts[0]))
        self.assertAlmostEqual(result['average_precision'][0],average_precision_score(y,p,sample_weight=counts[0]))
        self.assertAlmostEqual(result['brier'][0],np.average((y-p)**2,weights=counts[0]))
        self.assertTrue(np.isnan(result['auc'][1]))
        self.assertTrue(np.isnan(result['average_precision'][1]))

    def test_calibration_offset_and_constant_prediction(self):
        intercept,slope,status=calibration([0,0,0,1],[.3]*4)
        self.assertAlmostEqual(intercept,float(logit(.25)-logit(.3)),places=9)
        self.assertTrue(np.isnan(slope))
        self.assertIn('constant',status)
        lo,hi=wilson(0,20)
        self.assertAlmostEqual(lo,0,places=12)
        self.assertGreater(hi,0)

    def test_aj_tied_competing_events(self):
        result=aalen_johansen([1,1,2,3],[1,2,0,1])
        self.assertAlmostEqual(result.at(1)['cif_vte'],.25)
        self.assertAlmostEqual(result.at(1)['cif_death'],.25)
        self.assertAlmostEqual(result.at(3)['cif_vte'],.75)
        np.testing.assert_allclose(result.event_free+result.cif_vte+result.cif_death,1)

    def test_ipcw_ties_and_horizon_censoring(self):
        w=horizon_weights([1,1,2,3],[1,0,2,0],1.5)
        np.testing.assert_allclose(w.weight,[1,0,1.5,1.5])
        at60=horizon_weights([1,2,60,60],[1,0,1,0],60)
        np.testing.assert_allclose(at60.weight,[1,0,1.5,1.5])
        self.assertTrue(at60.control[-1])
        self.assertAlmostEqual(at60.censoring.at(60,side='left'),2/3)
        w=horizon_weights([1,2,3],[2,1,0],2)
        self.assertTrue(w.control[0])

    def test_horizon_rejects_unsupported_tail(self):
        with self.assertRaises(UnsupportedCensoringError):
            horizon_weights([12,36,48.7],[1,0,0],60)

    def test_events_after_cap_are_censored_without_changing_source(self):
        import pandas as pd
        derive=extracted_function(ROOT/'code/evaluate_time_sensitivity.py','derive_endpoint',{'np':np})
        source=pd.DataFrame({'fu_months':[12.,60.,72.],'Type':[0,1,1],'death':[1,0,1]})
        before=source.copy(deep=True)
        rawtime,rawstatus,time,status=derive(source,60)
        np.testing.assert_array_equal(status,[2,1,0])
        np.testing.assert_array_equal(rawstatus,[2,1,1])
        np.testing.assert_array_equal(time,[12,60,60])
        self.assertTrue(source.equals(before))

    def test_weighted_auc_matches_pair_enumeration(self):
        y=np.array([0,1,0,1,1]);p=np.array([.2,.2,.7,.8,.8]);w=np.array([1.,2.,3.,4.,1.])
        numerator=sum(w[i]*w[j]*(float(p[i]>p[j])+.5*float(p[i]==p[j]))
                      for i in np.flatnonzero(y==1) for j in np.flatnonzero(y==0))
        expected=numerator/(w[y==1].sum()*w[y==0].sum())
        self.assertAlmostEqual(weighted_auc_ap(y,p,w)['auc'],expected)

    def test_exact_shap_reconstructs_and_matches_independent_traversal(self):
        from itertools import permutations
        rng=np.random.default_rng(31)
        x=rng.normal(size=(80,4));y=(x[:,0]+.5*x[:,1]>0).astype(int)
        model=HistGradientBoostingClassifier(max_leaf_nodes=3,max_iter=12,min_samples_leaf=8,
                    early_stopping=False,random_state=2).fit(x,y)
        background=x[:15];targets=x[15:22]
        exact=extracted_function(ROOT/'code/explain_histgb.py','exact_treewise_shap',{'np':np})
        namespace={'np':np,'permutations':permutations}
        extracted_function(ROOT/'code/verify_shap.py','traverse',namespace)
        independent=extracted_function(ROOT/'code/verify_shap.py','enumerate_permutations',namespace)
        values,base,_=exact(model,background,targets)
        independent_base=float(np.asarray(model._baseline_prediction).squeeze())
        independent_values=np.zeros_like(targets)
        for stage in model._predictors:
            b,v=independent(stage[0],background,targets)
            independent_base+=b;independent_values+=v
        np.testing.assert_allclose(values,independent_values,atol=1e-12,rtol=0)
        self.assertAlmostEqual(base,independent_base,places=12)
        np.testing.assert_allclose(base+values.sum(axis=1),model.decision_function(targets),atol=1e-12,rtol=0)

    def test_development_configuration_and_source_dependencies(self):
        cfg=json.loads((ROOT/'config/evaluation_charter.json').read_text())
        dev=json.loads((ROOT/'development_source/advanced_ml/config/experiment.json').read_text())
        self.assertEqual(cfg['features'],dev['features'])
        self.assertEqual(cfg['categorical'],dev['categorical'])
        self.assertEqual(cfg['log1p'],dev['log1p'])
        self.assertEqual(len(dev['families']),13)
        self.assertEqual(dev['repeat_seeds'],[20261012,20262012,20263012])
        self.assertEqual(set(dev['raw_sha256']),{cfg['development_file']})
        source=(ROOT/'development_source/advanced_ml/code/run_advanced_ml.py').read_text()
        self.assertNotIn('def external(',source)
        self.assertNotIn('EVALUATION_PATH',source)


if __name__=='__main__':unittest.main()
