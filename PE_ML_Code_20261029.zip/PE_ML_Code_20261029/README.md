# Recurrent VTE prediction after unprovoked pulmonary embolism

This release contains the analysis source and aggregate results accompanying a retrospective prediction-model analysis of prospectively enrolled multicentre cohorts. The development cohort comprises 161 participants with 47 recorded recurrences; geographic external evaluation comprises 550 participants with 101 recurrences. Development-cohort enrolment began in May 2020, and enrolment in the three external hospital cohorts began in January 2017. Recruitment was completed in September 2025, and follow-up continued through January 2026. Twenty acute-phase clinical and laboratory measurements form the predictor set. The fitted leading family is histogram gradient boosting (HistGB).

The primary binary target is recorded first recurrent VTE during each participant's observation period. The binary scores do not represent a common five-year recurrence probability. Complementary analyses evaluate discrimination and competing-risk incidence at 12, 36 and 60 months. Neither models nor score cut points are recalibrated using external data.

Eligibility was assessed using the same clinical criteria across cohorts, including exclusion of VTE before the qualifying PE. Conditional-family OOF rankings and the separate adaptive family-selection benchmark estimate different procedures.

## Contents

The standalone code archive omits `Manuscript/` and `figures/`; those files are supplied in the complete submission directory.

- `Manuscript/`: the English manuscript, supplementary methods/results, and supplementary tables.
- `Protocol_SAP/`: Research protocol and statistical analysis plan, both Version 3.0 dated 31 October 2025, for retrospective analysis of prospectively enrolled cohorts.
- `code/`: scientific computation, input validation, numerical verification and figure/table rendering.
- `development_source/`: the 13-family development-only experiment and shared learner constructors.
- `config/`: predictor definitions, grids, fixed parameters, original prediction checksums, probability cut points and SHAP settings.
- `tables/supplement/`: complete aggregate numerical results.
- `tables/supplement_display/`: the 18 panels of supplementary Tables S1–S10 as CSV and HTML.
- `figure_data/`: aggregate plotting coordinates.
- `figures/`: main and supplementary figure files.
- `tests/`: analytic boundary cases and independent numerical checks using synthetic fixtures.
- `requirements.txt` and `original_session_info.txt`: the recorded analysis environment.
- `METHODS_CODE_MAP.md`: mapping between the reported methods and their implementation.

## Environment

The original analysis used Python 3.12.10. Install the recorded scientific dependencies in an isolated Python 3.12 environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

For Windows, activate `.venv\Scripts\activate` instead. Native numerical libraries and operating systems can affect fitted objects and optimization. The reconstruction checks deliberately reject fitted development probabilities that differ from the original checksums; a successful synthetic test alone does not establish complete study reproduction.

## Authorized input data

Individual records, individual predictions, individual SHAP values, fold membership and fitted model objects are excluded from the shared release. Authorized data access follows the manuscript's data availability statement.

Place the original tab-separated input files in `data/`, or change only `data_directory` in `config/evaluation_charter.json` to an authorized directory. The historical filenames have the following fixed roles:

| Filename | Role | Participants | Recurrences | SHA-256 |
| --- | --- | ---: | ---: | --- |
| data_test.txt | Development | 161 | 47 | a790fbc3e21782ba4089d947cc7b54d639345333871b5dc992d8ef51aa50d62a |
| data_train.txt | External evaluation | 550 | 101 | 0f838a014dd9bac743b5086e91a47e13d1e2f58074a1c40dad43c0517e2db835 |

Required fields are the 20 entries in `features`, plus `id`, `Type`, `death` and `fu_months`. `id` is a local record key excluded from predictors; `Type` is recorded first recurrent VTE (0/1); `death` records death during follow-up (0/1). Recurrence takes precedence when both indicators are one. `fu_months` records elapsed time from anticoagulation cessation to recurrence, otherwise death before recurrence or last confirmed recurrence-free contact. `gender` uses 1=female and 2=male; the other categorical predictors use 0/1. Original column spelling, including `platelete`, is retained for reproducibility. Laboratory units are recorded in `laboratory_units` and Table 1; the authors confirmed use of SI units. Numerical laboratory scales must remain identical to the original input recording because preprocessing and fitted cut points depend on those scales. Existing `pred_*` columns are excluded from predictor inputs.

Input checksums and expected cohort counts are mandatory. A changed source dataset requires its own documented analysis specification; do not disable checksums to pass a different version through this reproduction.

## Complete reproduction

```bash
python code/run_validation.py --full
```

This runs input validation, reproduces the repeated nested development experiment in a temporary workspace containing only development data, checks its OOF summaries and model lock, reconstructs seven fixed models against original development prediction checksums, and evaluates the authorized external input. It then calculates time-dependent results, exact empirical interventional SHAP values, independent numerical checks and scientific displays. The development experiment cannot read an external cohort. Its run-time charter guards the source and configuration used for reproduction.

With verified fitted objects and private development prediction outputs already present locally, the evaluation stages can instead be run with:

```bash
python code/run_validation.py --evaluate
```

Local execution creates `audit/`, `logs/`, `models/` and `results/` as needed. Files containing `private` are local research outputs and must remain outside an aggregate-only distribution.

## Reproduce aggregate supplementary tables

This path requires no patient-level data or fitted objects:

```bash
python code/sample_size_precision.py --output-dir tables/supplement
python code/render_supplementary_tables.py
```

The precision assessment implements the Newcombe AUROC approximation reproduced in Riley et al. (2021), equation 11, [doi:10.1002/sim.9025](https://doi.org/10.1002/sim.9025). It assesses the available external cohort; it does not set a recruitment target or establish development adequacy.

The supplementary table sequence is: S1, complete development comparison; S2, external performance; S3, calibration and descriptive decision curves; S4, paired comparisons; S5, score groups; S6, time-specific AUROC, censoring support and risk sets; S7, Aalen–Johansen incidence; S8, subgroups; S9, SHAP summaries; S10, external AUROC precision. Detailed optimizer logs are generated locally, while failure rules and concise failure counts remain in the supplementary methods/results. Figure S5 and Table S9 retain the SHAP results; a duplicate full-importance figure is omitted.

## Validation scope of this release

The October 2026 editorial revision retained original fitted-model specifications and aggregate estimates. The supplementary display export, the nine precision scenarios, and ten numerical/configuration tests were executed during preparation of this release. A complete re-run of model development and external evaluation was not performed during this editorial revision. The supplied aggregate results remain the source study outputs.

The authors confirmed that the original analysis-code writing, patient-data processing and image generation did not use generative AI. OpenAI Codex (OpenAI) assisted drafting and editing the research protocol and statistical analysis plan, language and formatting edits, comparison of reported methods with existing code, and editorial changes to source, documentation, release packaging and consistency checks during preparation of this revision. The manuscript acknowledgements disclose this assistance. Responsibility for reviewing and verifying the analyses and submitted material rests with the authors.
